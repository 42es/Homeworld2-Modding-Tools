# README #

### What is this repository for? ###

* Tools for 3dsMax work related to Homeworld Remastered.

See Thread below for more details.

### How do I get set up? ###

* Set your repository to  "C:\Users\NAME\AppData\Local\Autodesk\3dsMax\2015 - 64bit\ENU\scripts\startup\HomeworldRM" for best results (script on startup).

### Credits ###

* Script by @matththegeek
* UI by @CMDBob
* Additions by @EchoRed

### Thread ###

http://forums.gearboxsoftware.com/t/quick-and-dirty-max-script-for-weapon-templates/135992
