1. Copy IMFPsd.dll to c:\aw\maya4.0\bin\plug-ins\image
   The plugin *should* work with any recent version of Maya
   because I don't think the API has changed since mid-2000.
   (source is included)

2. [Optional] Run patchpsd.exe (source is included).
   This program will patch your copy of sharedui.dll to change
   the *.pix filespec to *.psd.  You can also do this yourself
   with a hex editor.  [This program only supports Maya 4.0]

The PSD support was written from scratch based on the Adobe 6.0
SDK document "File Formats".  Greyscale, color-indexed, and RGB
images should all be supported.  Whatever layers are enabled
when the file is saved will show up in the file.  Greyscale and
color-indexed files are expanded at load time to RGB.  All layers
after the base color layer are treated as mattes.

Standard disclaimers apply -- Neither myself nor my employer are
liable if this plugin trashes your machine.  No warranties are
expressed or implied as to its suitability for anything.  It's
been useful to me, hopefully it will be useful to you as well.

-Dave
 etherton@angelstudios.com
