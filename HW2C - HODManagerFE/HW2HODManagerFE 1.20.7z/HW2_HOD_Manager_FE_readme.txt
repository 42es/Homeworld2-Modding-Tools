-- HW2 HOD Manager FE v1.2
-- Created: 05/04/06 by Mikail
-- Last updated: 05/05/06
-- Homepage: 
-- http://www.geocities.com/Area51/Quadrant/3864/homeworld.htm
-- Discussion: 
-- http://forums.relicnews.com/showthread.php?t=92791
-- Download: 
-- http://www.geocities.com/Area51/Quadrant/3864/homeworld.htm


----------------------------------------------------------------


INTRODUCTION
This is a front-end program for the pipakin's command-line 
tool, HOD Manager (a.k.a. HardEd). It takes some of the pain 
out of editing multiple .hod files by allowing you to point-and-
click the files to edit.
Note: this program will only work with the command-line version 
of HardEd (e.g., 'HManager.exe'), not the graphical UI version!

USE AT YOUR OWN RISK!!! THIS PROGRAM WRITES/OVERWRITES FILES ON 
YOUR HARDDRIVE -- I TAKE NO RESPONSIBILITY FOR ANY DAMAGE 
INCURRED THROUGH ITS USE!

INSTALLATION
Extract the contents of this archive into a folder on your 
harddrive. To run the program, double-click on the file named 
'HW2_HardEd_FE.hta'.

Note: you must also install pipakin's hardpoint manager (a.k.a. HardEd) in order to edit any .hod files.
Note: this program requires that Windows Scripting Host v5.6 
also be installed.

INSTRUCTIONS
� Locate the program 'HManager.exe' on your harddrive by 
  clicking on the 'Browse' button.
� Enter the path to the directory containing your input files 
  into the text field below the label 'Input Folder'.
� Enter the path to the directory containing your output files 
  into the text field below the label 'Output Folder'.
� Specify whether you wish to edit harpoints or dockpaths in 
  the 'HardEd Mode' panel.
� The colored panels on the left (blue) indicate the .hod, 
  .hard or .dock files located in the input directory. The 
  colored panels on the right (yellow) indicate the .hod, .hard 
  or .dock files located in the output directory.
� In the 'Actions' panel you may select the action you wish to 
  perform. There are two primary actions: (1) extract a .hard 
  or .dock file from a source .hod file, or (2) combine a 
  source .hod file and a source .dock or .hard file in order to 
  create a brand new .hod file. You may also create dummy (zero-
  byte) .hard or .dock files in the output directory that you 
  can edit later.


------------------------------------------------------


CHANGES IN 1.2
� Added the option to extract/insert MRKR objects.
� Fixed a bug that kept the selected action from being read 
  properly.
� Fixed a bug that kept the selected file from being read 
  properly.
� Added break-points in loops to speed up iteration.
� Renamed the app again--this time to 'HOD Manager FE'.

CHANGES IN 1.1
� Discovered that the Dockpath Editor and Harpoint Editor are, 
  in fact, the same utility! Updated the app to reflect this.
� Changed the name of the app from 'Dockpath Editor FE' to 
  'HardEd FE'.
� A dummy file is no longer created when you hit the 'Cancel' 
  button when prompted for a file name.

CHANGES IN 1.01
� Added the option to create dummy files in the output 
  directories.
� The command-line is now properly quoted (in case paths 
  contain any spaces).

CHANGES IN 1.0
� Initial release.


------------------------------------------------------


TO DO
� Currently, there's no way to edit the files from within the 
  program. If I can get a hold of pipakin's source, then I'll 
  update the output of HardEd to be a bit cleaner and add 
  editing facility to this program.
