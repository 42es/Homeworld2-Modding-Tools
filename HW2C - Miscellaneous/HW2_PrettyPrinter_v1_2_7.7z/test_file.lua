-- This file is for stress-testing the pretty printer.

-- test natural logarithms
local test_var1 = endingine + 10
local test_var2 = -100e+20
local test_var3 = 5.0E-10
local test_var4 = e + 5
local test_var5 = player01e + 2

-- test keywords
thisvariablehasthefollowingwordsinit_functionendorandnotforifwhilereturndountilrepeat = 2
functionvar = nil; endvar = nil; ifvar = nil; elseifvar = nil; whilevar = nil; untilvar = nil; andvar = nil; orvar = nil; notvar = nil; repeatvar = nil; returnvar = nil; breakvar = nil; localvar = nil; globalvar = nil;
varfunction = nil; varend = nil; varif = nil; varelseif = nil; varwhile = nil; varuntil = nil; varand = nil; varor = nil; varnot = nil; varrepeat = nil; varreturn = nil; varbreak = nil; varlocal = nil; varglobal = nil;

--test tables
temptable =
{
	1,2,3,4,-5,"six",name_1="string_1",{7.1,7.2,7.3,},getlength,function() print("Nine") end,twelve=-12,{},
	-- comment
}

temptable[10] = 10
temptable.eleven = "eleven"
temptable["twelve"] = 12
temptable[ 4 ] = 4
dothisfunction({1,1,1,})

-- test comments
-- comment
-- comment
-- comment
-- comment

argtable =
{
	temptable,
	alpha,
	beta,
}

if 1 == 1 then print(       "1 = 1"         ) end

dofiles = function()
print("printing")
end

local functionsdostuff__ = function
	()
	do
	end
end

dofiles()
functionsdostuff__	()

function test_loop()
    for i = (1), (9), (2) do
        print(i^ - 2)
    end
    for i = 1, 9 do
        print(i)
    end
	for i, iCount in argtable do
		print(i)
	end
    local i = 0
    repeat
        if i == 100 and 0.04000 == 100 then
            return 1
        end
        print(i)
        i = i + 1
    until i == 5
    local i = 0
    while (i < 7) do
        if (i == 0.0000) and (-400.0 == 200.050) then
            break
        elseif ((2 ==                  2) and (4 == 5)) then
		print(i)
		return
	else
		print(i)
		i = -1 + .1 + i + 1
        end
    end
    if this and that == those then
        thisandthat = this + that
    end
    while (them not they ~= we) then
    end
    if {1,2,3,} == {1,2,3,} then
        print("equalorequalorequalorequal")
	return
    else
        print("not equal")
	return
	"bladibla"
    end
    do
        print(i .. " eyes")
	return (2)
    end
end

function return_two_values(arg)
    if (arg == 1) then
        return 1, 2
    else
        return
        {1, 2,}
    end
end

clone = function(self)
	print(type(self))
end

print(test_loop())
--print(return_two_values(2))
--clone()

--------------------------------------------------------------------------------
-- Inserts an item into a table. Useful where the 'tinsert' function is normally unavailable.
function
	tinsert
		(
			tTable
				,
					Arg1
						,
							Arg2
								)
								if
							(
						Arg2
					)
				then
			local
		TempTable
	=
{
}
	for
		i
			=
				Arg1
					,
						getn
							(
								tTable
									)
								do
							TempTable
						[
					i
				+
			1
		]
	=
tTable
[
	i
		]
			end
				for
					i
						=
							Arg1
								,
									getn
										(
											tTable
												)
													do
												tTable
											[
										i
									+
								1
							]
						=
					TempTable
				[
			i
		+
	1
]
end
tTable
		[
			Arg1
				]
					=
						Arg2
					else
				tTable
			[
		getn
	(
tTable
	)
		+
			1
				]
					=
						Arg1
							end
						end