Tournament System v1.3.0 by Mikail
Created: 03/11/07
Updated: 01/15/11
Homepage: http://isometricland.com
Discussion:
http://forums.relicnews.com/showthread.php?140504 (mockup1)
http://forums.relicnews.com/showthread.php?255492 (mockup2)


================================================================================


INTRODUCTION
Inside are two proofs-of-concept for interactive maps of a particular type of 
multiplayer tournament I devised.

MOCKUP 1
The first mockup just consists of an SVG image that needs to be updated 
manually, and HTML file to display the image. The SVG image does not display 
properly in Firefox. You'll have to install Internet Explorer and the Adobe SVG 
Plugin, or convert the image to another format using InkScape.

In the first mockup there are two teams (colored yellow and cyan). Each team 
initially controls one half of the galaxy map. Each team takes turns capturing 
(or re-capturing) sectors that lie along the path to the enemy's home sector 
(a circle with a black border). The object of the game is to capture the 
opposing team's home sector. Occupied sectors become lost when they are cut off 
and isolated from the home sector. The dotted lines indicate the directions one 
can move when going from sector to sector.

MOCKUP 2
The second mockup contains a number of GGB files as well as smaller source 
images. Note that the .GGB files belong to a free program called GeoGebra. 
GeoGebra supports SVG (and even PNG) output, but the export script is a bit 
wonky. You may have to make further modifications in another program.

In this concept, turns are simultaneously-executed. You get one move per turn. 
There are no diagonal moves. Multiple players may occupy a single tile. If 
enemies occupy the same tile, combat using HW2 ensues. Players may die in 
combat, or if their homeworld is captured. Land on a tile with an icon and 
something special occurs. Refer to the discussion link for further details and 
info.


================================================================================


CHANGE LOG

1.3.0
• Added the source files for my second tournament concept.

1.2.0
• Added the HTML file used to display the SVG image.

1.1.0
• Can't remember.

1.0.0
• Initial release.
