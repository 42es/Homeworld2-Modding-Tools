ThoughtDump v1.23
Created by Thought (http://hw2.tproc.org)
Updated by Mikail, 11/04
Last updated:  01/01/06


================================================================================


INSTALLATION
Extract this archive into your "...\Homeworld2\Data\Scripts\" directory.

INTRODUCTION
Parses the globals table and prints its contents to "HW2.log".
Can, however, be used to parse (e.g. pretty-print) any table in some cases.

INSTRUCTIONS
Use the "dofilepath()" function to read/call the script, or just copy its contents to another file.
Output will be printed to "HW2.log".


================================================================================


CHANGE LOG
v1.0
* Original version released by Thought.

v1.1
* I made it so that the script can be read/called externally (so long as the 
  globals() function is within its scope), instead of merely being a gamerule.
* Trimmed the code a bit.

v1.2
* Output is formatted differently, now.
* Added the "verbose" switch (enabled by default).

v1.21
* All table indices are now printed.
* The tag numbers of userdata values are now printed in double-quotes after their indices.

v1.22
* The script now writes its output to a global string variable named "__Output", which is later printed.

v1.23
* Reverted to prior version (v1.21), as the new code was buggy.
