// HW2 .Arciv Compiler v1.00
// Created: 03/10/07 by Mikail
// Last updated: 03/20/07
// Homepage: http://www.geocities.com/Area51/Quadrant/3864/homeworld.htm

var MssgDebug = false
var MssgVerbose = true

var AppVersion = '1.00'
var AppInfo = 'HW2 .Arciv Decompiler v' + AppVersion + ' by Mikail'+ '\n'
var AppError = ''+
'Run the program using the following command-line:'+ '\n\n'+
'	cscript [script file] [CFLuaDC path] [.arciv file] [[destination folder]]'+ '\n\n'+
'where:\n'+
'	[script file] is the full path to "HW2_ArcivDecompiler.js".'+ '\n\n'+
'	[CFLuaDC path] is the full path to "CFLuaDC.exe".'+ '\n\n'+
'	[.arciv file] is the full path to the .arciv file you generated using '+ '\n'+
'	ModPackager.'+ '\n\n'+
'	[[destination folder]] is the path to the folder where the compiled '+ '\n'+
'	files should be generated. Use the "-a" switch, instead, if you want '+ '\n'+
'	the files generated in the same directory as the .arciv file. Or, use'+ '\n'+
'	"-o" if you want to overwrite your source files. If ommitted entirely, '+ '\n'+
'	a new file will be created with the same name and in the same directory '+ '\n'+
'	as the original file, but with an additional ".cfluadc" extension.'+ '\n'

// only continue if the script is run via Windows Scripting Host
if (typeof(WScript) != 'undefined')
{
	// set up file objects
	var ProgArgs = WScript.Arguments
	var fso = new ActiveXObject('Scripting.FileSystemObject')
	var WshShell = new ActiveXObject('WScript.Shell')
	var TOCRootPath

	// if the script is run without arguments, print help text to the screen; else, continue.
	if (ProgArgs.length == 0)
	{
		WScript.Echo(AppInfo)
		WScript.Echo(AppError)
	}
	else
	{
		// parse the command-line arguments
		var LuaCPath = ProgArgs(0)
		var SRCFilePath = ProgArgs(1)
		var SRCRootPath = SRCFilePath.substring(0, SRCFilePath.lastIndexOf('\\') + 1)
		if (SRCRootPath == '')
		{
			SRCRootPath = WshShell.CurrentDirectory + '\\'
		}
		var WRTRootPath
		if (ProgArgs.length > 2)
		{
			WRTRootPath = ProgArgs(2)
			if ((WRTRootPath.charAt(WRTRootPath.length - 1) != '\\') && (WRTRootPath != '-o') && (WRTRootPath != '-a'))
			{
				WRTRootPath += '\\'
			}
		}

		// read the input file and store its contents as a string
		var TempObject = fso.OpenTextFile(SRCFilePath, 1)
		var CodeString = TempObject.ReadAll()
		TempObject.Close()
	
		// convert the source file to JS code
		var CodeString = ConvertTable(CodeString)
		eval(CodeString)

		// write a copy of the converted table
		if (MssgDebug == true)
		{
			var WritObject = fso.OpenTextFile(SRCFilePath + '.debug1', 2, 1, 0)
			WritObject.Write(CodeString)
			WritObject.Close()
		}

		// iterate through the converted table and search for paths
		for (i in Archive.TOCList)
		{
			TOCRootPath = Archive.TOCList[i].TOCHeader.RootPath
			for (j in Archive.TOCList[i].RootFolder)
			{
				var TempLevel = 'Archive.TOCList[' + i + '].RootFolder.' + j
				var TempTable = Archive.TOCList[i].RootFolder[j]
				if (j == 'Folders')
				{
					IterateFolders(TempTable, TempLevel)
				}
				else if (j == 'Files')
				{
					IterateFiles(TempTable, TempLevel)
				}
			}
		}
	}
}

function IterateFolders(SubTable, Level)
{
	var i, j
	for (i in SubTable)
	{
		for (j in SubTable[i])
		{
			var NewLevel = Level + '[' + i + '].' + j
			var TempTable = SubTable[i][j]
			if (j == 'Folders')
			{
				IterateFolders(TempTable, NewLevel)
			}
			else if (j == 'Files')
			{
				IterateFiles(TempTable, NewLevel)
			}
		}
	}
}

function IterateFiles(SubTable, Level)
{
	for (i in SubTable)
	{
		for (j in SubTable[i])
		{
			var NewLevel = Level + '[' + i + '].' + j
			var TempTable = SubTable[i][j]
			if (j == 'Path')
			{
				// generate the proper input and output paths based on which command-line switches were used
				var TOCFilePath = TempTable
				var WRTFilePath = ''
				if (WRTRootPath == '-o')
				{
					WRTFilePath = TOCFilePath
				}
				else if (WRTRootPath == '-a')
				{
					WRTFilePath = TOCFilePath.replace(TOCRootPath, SRCRootPath)
				}
				else if (WRTRootPath == null)
				{
					WRTFilePath = TOCFilePath + '.cfluadc'
				}
				else
				{
					WRTFilePath = TOCFilePath.replace(TOCRootPath, WRTRootPath)
				}

				// create the destination folder if it doesn't already exist (but only if the file being compiled also exists)
				var WRTFolderPath = WRTFilePath.substring(0, WRTFilePath.lastIndexOf('\\') + 1)
				if (fso.FileExists(TOCFilePath) == 1)
				{
					CreateFolderTree(WRTFolderPath)
				}

				// assemble the command string, print it to the screen, and run it
				var CommandString = '"' + LuaCPath + '" "' + TOCFilePath + '" -o:"' + WRTFilePath + '"'
				if (MssgVerbose == true) WScript.Echo(CommandString + '\n')
				WshShell.Run(CommandString, 2, 1)
			}
		}
	}
}

function CreateFolderTree(TempString)
{
	var TempIndex = 0
	var TempString2 = ''
	var TempLength = TempString.length
	while (TempString2.length < TempLength)
	{
		TempIndex += TempString.substring(TempIndex, TempLength).indexOf('\\') + 1
		TempString2 = TempString.substring(0, TempIndex)
//		PrintMessage('TempIndex = ' + TempIndex + ', TempString2 = ' + TempString2)
		if (fso.FolderExists(TempString2) == 0)
		{
			fso.CreateFolder(TempString2)
		}
	}
}

// convert a Lua table to a JScript object initializer
function ConvertTable(TempString)
{
	TempString = TempString.replace(/\\/mg, '\\\\')
	TempString = TempString.replace(/\[\[/mg, '\"')
	TempString = TempString.replace(/\]\]/mg, '\"')
	TempString = TempString.replace(/\]/mg, '')
	TempString = TempString.replace(/\[/mg, '')
	TempString = TempString.replace(/\-\-/mg, '\/\/')
	TempString = TempString.replace(/\=/mg, '\:')
	TempString = TempString.replace(/Archive : /mg, 'Archive = ')

	TempRegexp = /\,(\s*)\}/mg
	TempTable = TempString.match(TempRegexp)
	while (TempTable != null)
	{
		TempString = TempString.replace(TempRegexp, '$1\}')
		TempTable = TempString.match(TempRegexp)
	}

	return TempString
}
