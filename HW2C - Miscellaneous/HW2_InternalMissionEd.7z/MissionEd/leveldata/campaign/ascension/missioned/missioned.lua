--===========================================================================
-- Little utility to easily save camera points (for those who don't have Maya)
-- Sun Tzu
-- Edited to act like a Mission Editor by EhraniNavy

--=========================== EXTERNAL FILES ================================
-- !!WARNING!!: put the full path to the Homeworld 2 data on your computer in the path.lua file
-- alternatively you can use the HW2_Path function by TamerLane to set the path (if you are using MS Windows)

dofilepath("data:scripts/scar/restrict.lua")
dofilepath("data:scripts/scar/scar_util.lua")
dofilepath("data:leveldata/campaign/path.lua")
ATI_LoadTemplates("data:LevelData\\campaign\\ATI.lua")

--=========================== INIT RULE ======================================

function OnInit()
	Rule_Add("Rule_CameraSetup")
end

function ResetKeys()
	UI_BindKeyEvent(F2KEY, "SetCameraFocal")
	UI_BindKeyEvent(F1KEY, "SetCameraOrigin")
	UI_BindKeyEvent(F4KEY, "ClearCameraInfo")
	UI_BindKeyEvent(F3KEY, "ExtrapolateCameraPoint")
	UI_BindKeyEvent(F5KEY, "SaveCameraPoint")
	UI_BindKeyEvent(ONEKEY, "Rule_Fighters")
	UI_BindKeyEvent(TWOKEY, "Rule_Vettes")
	UI_BindKeyEvent(THREEKEY, "Rule_Frigates")
	UI_BindKeyEvent(FOURKEY, "Rule_Caps")
	UI_BindKeyEvent(CKEY, "Cancel")
	Home()
end

function Home()
	Subtitle_Add(Actor_LocationCard, "Press 1 for available fighters. Press 2 for available for available corvettes.", 12)
end

function Cancel()
	Home()
	ResetKeys()
end

function Rule_CameraSetup()
	Home()
	b_Changed = 0
	gi_cameraIndex = 1
	gi_ScoutIndex = 1
	gi_InterceptorIndex = 1
	gi_BomberIndex = 1
    gi_GunshipIndex = 1
	gi_PulsarIndex = 1
    gi_MinelayerIndex = 1
	gi_AssaultIndex = 1
	gi_TorpedoIndex = 1
	gi_IonIndex = 1
	gi_MarineIndex = 1
	gi_DefenseIndex = 1
	gt_focal = {0,0,0}
	gt_origin = {0,0,0}
	gs_message = ""
	UI_BindKeyEvent(F2KEY, "SetCameraFocal")
	UI_BindKeyEvent(F1KEY, "SetCameraOrigin")
	UI_BindKeyEvent(F4KEY, "ClearCameraInfo")
	UI_BindKeyEvent(F3KEY, "ExtrapolateCameraPoint")
	UI_BindKeyEvent(F5KEY, "SaveCameraPoint")
	UI_BindKeyEvent(ONEKEY, "Rule_Fighters")
	UI_BindKeyEvent(TWOKEY, "Rule_Vettes")
	UI_BindKeyEvent(THREEKEY, "Rule_Frigates")
	UI_BindKeyEvent(FOURKEY, "Rule_Caps")
	UI_BindKeyEvent(CKEY, "Cancel")
	Volume_AddSphere("vol_Sat1", {0, 0, 0}, 30)
	Volume_AddSphere("vol_Sat2", {10000, 0, 0}, 30)
	Volume_AddSphere("vol_Sat3", {0, 10000, 0}, 30)
	Volume_AddSphere("vol_Sat4", {0, 0, 10000}, 30)
	Camera_UsePanning(1)
	for i = 1, 4 do
		SobGroup_Create("sg_Sat"..i)
		SobGroup_SpawnNewShipInSobGroup(-1, "hgn_probe", "satellite", "sg_Sat"..i, "vol_Sat"..i)
	end
	Rule_Add("Rule_CameraGPS")
	Rule_Add("Rule_DisplayInfo")
	Rule_Remove("Rule_CameraSetup")
end

--================= UTILITY: CAMERA GPS COORDINATES =======================
-- Requires the prior setting of HW2Path

function Rule_CameraGPS()
	lf_d1 = Camera_GetDistanceToSobGroup("sg_Sat1")
	lf_d2 = Camera_GetDistanceToSobGroup("sg_Sat2")
	lf_d3 = Camera_GetDistanceToSobGroup("sg_Sat3")
	lf_d4 = Camera_GetDistanceToSobGroup("sg_Sat4")
	gi_x = floor(5000-(lf_d2*lf_d2 - lf_d1*lf_d1)/20000)
	gi_y = floor(5000-(lf_d3*lf_d3 - lf_d1*lf_d1)/20000)
	gi_z = floor(5000-(lf_d4*lf_d4 - lf_d1*lf_d1)/20000)
end

function SetCameraFocal()
	gt_focal[1] = gi_x
	gt_focal[2] = gi_y
	gt_focal[3] = gi_z
end

function SetCameraOrigin()
	gt_origin[1] = gi_x
	gt_origin[2] = gi_y
	gt_origin[3] = gi_z
	b_changed = 1
end

function ExtrapolateCameraPoint()
	local lt_temp = {}
	for i = 1, 3 do
		lt_temp[i] = gt_focal[i] + (gt_focal[i] - gt_origin[i])
		gt_origin[i] = gt_focal[i]
		gt_focal[i] = lt_temp[i]
	end
end

function ClearCameraInfo()
	for i = 1, 3 do
		gt_focal[i] = 0
		gt_origin[i] = 0
	end
end

function SaveCameraPoint()
	local li_saveClearance = 1
	gs_CameraSaveString = ""
	for i = 1, 3 do
		if gt_focal[i] == 0 then
			li_saveClearance = 0
		end
		if gt_origin[i] == 0 then
			li_saveClearance = 0
		end
	end
	gs_CameraSaveString = "    addCamera(\"cam_Point"..gi_cameraIndex.."\", { "..gt_focal[1]..", "..gt_focal[2]..", "..gt_focal[3]..", }, { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",})\n"
	if li_saveClearance == 1 then
		file = HW2Path.."data/leveldata/campaign/camera.txt"
		appendto(file)
		write(gs_CameraSaveString)
		writeto()
		gi_cameraIndex = gi_cameraIndex + 1
		ClearCameraInfo()
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
end


--================================ ADDITION BY EHRANINAVY: ADDING SHIPS ==================

--================================FIGHTER CLASS VESSELS==============================

function Rule_Fighters()
	gs_message = "Fighters Selected"
	Subtitle_Add(Actor_LocationCard, "Fighters selected. Press 1 to add an interceptor, 2 to add a scout and 3 to add a bomber.", 12)
        UI_BindKeyEvent(ONEKEY, "Interceptor")
	UI_BindKeyEvent(TWOKEY, "Scout")
	UI_BindKeyEvent(THREEKEY, "Bomber")
end
function Interceptor()
setCameraFocus()
gs_message = "Interceptor Selected"
local li_saveClearance = 1
	gs_InterceptorSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_InterceptorSaveString = "    addSquadron(\"Interceptor"..gi_InterceptorIndex.."\", \"Interceptor\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Interceptor"..gi_InterceptorIndex)
		Volume_AddSphere("vol_Interceptor"..gi_InterceptorIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
      		SobGroup_SpawnNewShipInSobGroup(0, "hgn_Interceptor", "Interceptor"..gi_InterceptorIndex, "Interceptor"..gi_InterceptorIndex, "vol_Interceptor"..gi_InterceptorIndex)
		SobGroup_AbilityActivate("Interceptor"..gi_InterceptorIndex, AB_Move, 0)
		gi_InterceptorIndex = gi_InterceptorIndex + 1
	else
		gs_InterceptorSaveString = "    addSquadron(\"Interceptor"..gi_InterceptorIndex.."\", \"Vgr_Interceptor\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Interceptor"..gi_InterceptorIndex)
		Volume_AddSphere("vol_Interceptor"..gi_InterceptorIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
		SobGroup_SpawnNewShipInSobGroup(0, "vgr_Interceptor", "Interceptor"..gi_InterceptorIndex, "Interceptor"..gi_InterceptorIndex, "vol_Interceptor"..gi_InterceptorIndex)
		SobGroup_AbilityActivate("Interceptor"..gi_InterceptorIndex, AB_Move, 0)
		gi_InterceptorIndex = gi_InterceptorIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_InterceptorSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end	
	Rule_Remove("Rule_Fighters")
	ResetKeys()
end
function Scout()
	setCameraFocus()
	local li_saveClearance = 1
	gs_ScoutSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_ScoutSaveString = "    addSquadron(\"Scout"..gi_ScoutIndex.."\", \"Hgn_Scout\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Scout"..gi_ScoutIndex)
		Volume_AddSphere("vol_Scout"..gi_ScoutIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
      		SobGroup_SpawnNewShipInSobGroup(0, "hgn_Scout", "Scout"..gi_ScoutIndex, "Scout"..gi_ScoutIndex, "vol_Scout"..gi_ScoutIndex)
		SobGroup_AbilityActivate("Scout"..gi_ScoutIndex, AB_Move, 0)
		gi_ScoutIndex = gi_ScoutIndex + 1
	else
		gs_ScoutSaveString = "    addSquadron(\"Scout"..gi_ScoutIndex.."\", \"Vgr_Scout\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Scout"..gi_ScoutIndex)
		Volume_AddSphere("vol_Scout"..gi_ScoutIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
		SobGroup_SpawnNewShipInSobGroup(0, "vgr_Scout", "Scout"..gi_ScoutIndex, "Scout"..gi_ScoutIndex, "vol_Scout"..gi_ScoutIndex)
		SobGroup_AbilityActivate("Scout"..gi_ScoutIndex, AB_Move, 0)
		gi_ScoutIndex = gi_ScoutIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_ScoutSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Fighters")
	ResetKeys()
end
function Bomber()
	setCameraFocus()
	local li_saveClearance = 1
	gs_BomberSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_BomberSaveString = "    addSquadron(\"Bomber"..gi_BomberIndex.."\", \"Hgn_Bomber\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Bomber"..gi_BomberIndex)
		Volume_AddSphere("vol_Bomber"..gi_BomberIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
      		SobGroup_SpawnNewShipInSobGroup(0, "hgn_Bomber", "Bomber"..gi_BomberIndex, "Bomber"..gi_BomberIndex, "vol_Bomber"..gi_BomberIndex)
		SobGroup_AbilityActivate("Bomber"..gi_BomberIndex, AB_Move, 0)
		gi_BomberIndex = gi_BomberIndex + 1
	else
		gs_BomberSaveString = "    addSquadron(\"Bomber"..gi_BomberIndex.."\", \"Vgr_Bomber\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Bomber"..gi_BomberIndex)
		Volume_AddSphere("vol_Bomber"..gi_BomberIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
		SobGroup_SpawnNewShipInSobGroup(0, "vgr_Bomber", "Bomber"..gi_BomberIndex, "Bomber"..gi_BomberIndex, "vol_Bomber"..gi_BomberIndex)
		SobGroup_AbilityActivate("Bomber"..gi_BomberIndex, AB_Move, 0)
		gi_BomberIndex = gi_BomberIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_BomberSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Fighters")
	ResetKeys()
end

--==============================CORVETTE CLASS VESSELS====================================
function Rule_Vettes()
	gs_message = "Corvettes Selected"
	Subtitle_Add(Actor_LocationCard, "Corvettes selected. Press 1 to add a Gunship, 2 to add a Pulsar Gunship and 3 to add a Minelayer.", 12)
    UI_BindKeyEvent(ONEKEY, "Gunship")
	UI_BindKeyEvent(TWOKEY, "Pulsar")
	UI_BindKeyEvent(THREEKEY, "Minelayer")
end
function Gunship()
	setCameraFocus()
	local li_saveClearance = 1
	gs_GunshipSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_GunshipSaveString = "    addSquadron(\"Gunship"..gi_GunshipIndex.."\", \"Hgn_assaultcorvette\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Gunship"..gi_GunshipIndex)
		Volume_AddSphere("vol_Gunship"..gi_GunshipIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
      		SobGroup_SpawnNewShipInSobGroup(0, "hgn_assaultcorvette", "Gunship"..gi_GunshipIndex, "Gunship"..gi_GunshipIndex, "vol_Gunship"..gi_GunshipIndex)
		SobGroup_AbilityActivate("Gunship"..gi_GunshipIndex, AB_Move, 0)
		gi_GunshipIndex = gi_GunshipIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_GunshipSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Vettes")
	ResetKeys()
end
function Pulsar()
	setCameraFocus()
	local li_saveClearance = 1
	gs_PulsarSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_PulsarSaveString = "    addSquadron(\"Pulsar"..gi_PulsarIndex.."\", \"Hgn_pulsarcorvette\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Pulsar"..gi_PulsarIndex)
		Volume_AddSphere("vol_Pulsar"..gi_PulsarIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
      		SobGroup_SpawnNewShipInSobGroup(0, "hgn_pulsarcorvette", "Pulsar"..gi_PulsarIndex, "Pulsar"..gi_PulsarIndex, "vol_Pulsar"..gi_PulsarIndex)
		SobGroup_AbilityActivate("Pulsar"..gi_PulsarIndex, AB_Move, 0)
		gi_PulsarIndex = gi_PulsarIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_PulsarSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Vettes")
	ResetKeys()
end
function Minelayer()
	setCameraFocus()
	local li_saveClearance = 1
	gs_MinelayerSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_MinelayerSaveString = "    addSquadron(\"Minelayer"..gi_MinelayerIndex.."\", \"Hgn_Minelayer\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Minelayer"..gi_MinelayerIndex)
		Volume_AddSphere("vol_Minelayer"..gi_MinelayerIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
      		SobGroup_SpawnNewShipInSobGroup(0, "hgn_Minelayer", "Minelayer"..gi_MinelayerIndex, "Minelayer"..gi_MinelayerIndex, "vol_Minelayer"..gi_MinelayerIndex)
		SobGroup_AbilityActivate("Minelayer"..gi_MinelayerIndex, AB_Move, 0)
		gi_MinelayerIndex = gi_MinelayerIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_MinelayerSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Vettes")
	ResetKeys()
end

--================================FRIGATE CLASS VESSELS===================================
function Rule_Frigates()
	gs_message = "Frigates Selected"
	Subtitle_Add(Actor_LocationCard, "Frigates selected. Press 1 to add a Flak Frigate, 2 to add a Torpedo Frigate, 3 to add an Ion Beam Frigate, 4 to add a Marine Frigate, and 5 to add a Defense Field Frigate.", 20)
	UI_BindKeyEvent(ONEKEY, "Assault")
	UI_BindKeyEvent(TWOKEY, "Torpedo")
	UI_BindKeyEvent(THREEKEY, "Ion")
	UI_BindKeyEvent(FOURKEY, "Marine")
	UI_BindKeyEvent(FIVEKEY, "DFF")
end
function Assault()
	setCameraFocus()
	local li_saveClearance = 1
	gs_AssaultSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_AssaultSaveString = "    addSquadron(\"Assault"..gi_AssaultIndex.."\", \"Hgn_assaultfrigate\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Assault"..gi_AssaultIndex)
		Volume_AddSphere("vol_Assault"..gi_AssaultIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
    	SobGroup_SpawnNewShipInSobGroup(0, "hgn_assaultfrigate", "Assault"..gi_AssaultIndex, "Assault"..gi_AssaultIndex, "vol_Assault"..gi_AssaultIndex)
		SobGroup_AbilityActivate("Assault"..gi_AssaultIndex, AB_Move, 0)
		gi_AssaultIndex = gi_AssaultIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_AssaultSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Frigates")
	ResetKeys()
end
function Torpedo()
	setCameraFocus()
	local li_saveClearance = 1
	gs_TorpedoSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_TorpedoSaveString = "    addSquadron(\"Torpedo"..gi_TorpedoIndex.."\", \"Hgn_torpedofrigate\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Torpedo"..gi_TorpedoIndex)
		Volume_AddSphere("vol_Torpedo"..gi_TorpedoIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
    	SobGroup_SpawnNewShipInSobGroup(0, "hgn_topredofrigate", "Torpedo"..gi_TorpedoIndex, "Torpedo"..gi_TorpedoIndex, "vol_Torpedo"..gi_TorpedoIndex)
		SobGroup_AbilityActivate("Torpedo"..gi_TorpedoIndex, AB_Move, 0)
		gi_TorpedotIndex = gi_TorpedoIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_TorpedoSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Frigates")
	ResetKeys()
end
function Ion()
	setCameraFocus()
	local li_saveClearance = 1
	gs_IonSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_IonSaveString = "    addSquadron(\"Ion"..gi_IonIndex.."\", \"Hgn_ionfrigate\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Ion"..gi_IonIndex)
		Volume_AddSphere("vol_Ion"..gi_IonIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
    	SobGroup_SpawnNewShipInSobGroup(0, "hgn_ionfrigate", "Ion"..gi_IonIndex, "Ion"..gi_IonIndex, "vol_Ion"..gi_IonIndex)
		SobGroup_AbilityActivate("Ion"..gi_IonIndex, AB_Move, 0)
		gi_IonIndex = gi_IonIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_IonSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Frigates")
	ResetKeys()
end
function Marine()
	setCameraFocus()
	local li_saveClearance = 1
	gs_MarineSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_MarineSaveString = "    addSquadron(\"Marine"..gi_MarineIndex.."\", \"Hgn_Marinefrigate\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Marine"..gi_MarineIndex)
		Volume_AddSphere("vol_Marine"..gi_MarineIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
    	SobGroup_SpawnNewShipInSobGroup(0, "hgn_Marinefrigate", "Marine"..gi_MarineIndex, "Marine"..gi_MarineIndex, "vol_Marine"..gi_MarineIndex)
		SobGroup_AbilityActivate("Marine"..gi_MarineIndex, AB_Move, 0)
		gi_MarineIndex = gi_MarineIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_MarineSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Frigates")
	ResetKeys()
end
function DFF()
	setCameraFocus()
	local li_saveClearance = 1
	gs_DFFSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_DFFSaveString = "    addSquadron(\"defensefield"..gi_DFFIndex.."\", \"Hgn_carrier\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("defensefield"..gi_DFFIndex)
		Volume_AddSphere("vol_defensefield"..gi_DFFIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
    	SobGroup_SpawnNewShipInSobGroup(0, "hgn_carrier", "defensefield"..gi_DFFIndex, "defensefield"..gi_DFFIndex, "vol_defensefield"..gi_DFFIndex)
		SobGroup_AbilityActivate("defensefield"..gi_DFFIndex, AB_Move, 0)
		gi_DFFIndex = gi_DFFIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_DFFSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Frigates")
	ResetKeys()
end
--================================CAPITAL CLASS VESSELS===================================
function Rule_Caps()
	gs_message = "Capital Ships Selected"
	Subtitle_Add(Actor_LocationCard, "Capital Ships selected. Press 1 to add a Carrier, 2 to add a Destroyer, 3 to add a Shipyard and 4 to add a Battlecruiser.", 16)
    UI_BindKeyEvent(ONEKEY, "Carrier")
	UI_BindKeyEvent(TWOKEY, "Destroyer")
	UI_BindKeyEvent(THREEKEY, "Shipyard")
	UI_BindKeyEvent(FOURKEY, "Battlecruiser")
end
function Carrier()
	setCameraFocus()
	local li_saveClearance = 1
	gs_CarrierSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_CarrierSaveString = "    addSquadron(\"Carrier"..gi_CarrierIndex.."\", \"Hgn_carrier\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Carrier"..gi_CarrierIndex)
		Volume_AddSphere("vol_carrier"..gi_CarrierIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
    	SobGroup_SpawnNewShipInSobGroup(0, "hgn_carrier", "Carrier"..gi_CarrierIndex, "Carrier"..gi_CarrierIndex, "vol_carrier"..gi_CarrierIndex)
		SobGroup_AbilityActivate("Carrier"..gi_CarrierIndex, AB_Move, 0)
		gi_CarrierIndex = gi_CarrierIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_CarrierSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Caps")
	ResetKeys()
end
function Destroyer()
	setCameraFocus()
	local li_saveClearance = 1
	gs_DestroyerSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_DestroyerSaveString = "    addSquadron(\"destroyer"..gi_destroyerIndex.."\", \"Hgn_destroyer\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("destroyer"..gi_destroyerIndex)
		Volume_AddSphere("vol_destroyer"..gi_destroyerIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
    	SobGroup_SpawnNewShipInSobGroup(0, "hgn_destroyer", "destroyer"..gi_destroyerIndex, "destroyer"..gi_destroyerIndex, "vol_destroyer"..gi_destroyerIndex)
		SobGroup_AbilityActivate("destroyer"..gi_destroyerIndex, AB_Move, 0)
		gi_destroyerIndex = gi_destroyerIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_DestroyerSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Caps")
	ResetKeys()
	end
function Shipyard
	setCameraFocus()
	local li_saveClearance = 1
	gs_ShipyardSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_ShipyardSaveString = "    addSquadron(\"shipyard"..gi_shipyardIndex.."\", \"Hgn_shipyard\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("shipyard"..gi_shipyardIndex)
		Volume_AddSphere("vol_shipyard"..gi_shipyardIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
    	SobGroup_SpawnNewShipInSobGroup(0, "hgn_shipyard", "shipyard"..gi_shipyardIndex, "shipyard"..gi_shipyardIndex, "vol_shipyard"..gi_shipyardIndex)
		SobGroup_AbilityActivate("shipyard"..gi_shipyardIndex, AB_Move, 0)
		gi_shipyardIndex = gi_shipyardIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_ShipyardSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Caps")
	ResetKeys()
end
function Battlecrusier()
	setCameraFocus()
	local li_saveClearance = 1
	gs_BattlecruiserSaveString = ""
	if (b_Changed==0) then
		li_saveClearance = 0
	end
	gi_PlayerRace = Player_GetRace(0)
	if gi_PlayerRace == 1 then
		gs_BattlecruiserSaveString = "    addSquadron(\"Battlecruiser"..gi_BattlecruiserIndex.."\", \"Hgn_Battlecruiser\", { "..gt_origin[1]..", "..gt_origin[2]..", "..gt_origin[3]..",}, {0, 0, 0}, 0, 0})\n"
		SobGroup_Create("Battlecruiser"..gi_BattlecruiserIndex)
		Volume_AddSphere("vol_Battlecruiser"..gi_BattlecruiserIndex, {gt_origin[1], gt_origin[2], gt_origin[3]}, 30)
    	SobGroup_SpawnNewShipInSobGroup(0, "hgn_Battlecruiser", "Battlecruiser"..gi_BattlecruiserIndex, "Battlecruiser"..gi_BattlecruiserIndex, "vol_Battlecruiser"..gi_BattlecruiserIndex)
		SobGroup_AbilityActivate("Battlecruiser"..gi_BattlecruiserIndex, AB_Move, 0)
		gi_BattlecruiserIndex = gi_BattlecruiserIndex + 1
	end
	if li_saveClearance == 1 then
		file = "c:\\program files\\sierra\\homeworld2\\data\\camera.txt"
		appendto(file)
		write(gs_BattlecruiserSaveString)
		writeto()
		ClearCameraInfo()
		b_Changed = 0
		gs_message = "point saved"
	else
		gs_message = "unable to save - data missing"
	end
	Rule_Remove("Rule_Caps")
	ResetKeys()
end
--================================PLATFORM VESSELS========================================
function Rule_Platforms()
	gs_message = "Platforms Selected"
	Subtitle_Add(Actor_LocationCard, "Platforms selected. Press 1 to add a Gun Platform, 2 to add an Ion Platform, 3 to add an Ion Beam Frigate, 4 to add a Marine Frigate, and 5 to add a Defense Field Frigate.", 20)
	UI_BindKeyEvent(ONEKEY, "Assault")
	UI_BindKeyEvent(TWOKEY, "Torpedo")
	UI_BindKeyEvent(THREEKEY, "Ion")
	UI_BindKeyEvent(FOURKEY, "Marine")
	UI_BindKeyEvent(FIVEKEY, "DFF")
end
--======================= UTILITY: DISPLAYS TEXT ON SCREEN ==============
-- Requires prior loading of the CameraGPS ATI template

-- sets the number of text lines to be displayed 
function Rule_DisplayInfo()
	DisplayText(30)
end

function DisplayText(block)
	--local TextList = {"", "", "Origin", "x", "y", "z", "1: Fighters", "2: Corvettes", "3: Frigates", "4: Capital", "5: Non Combat", "6: Cameras", "7: Asteriods", "8: Pebbles", "9: Megatliths", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""}
	local TextList = {"", "", "Origin", "x", "y", "z", "Focus", "x", "y", "z", "", "F1: origin", "F2: focus", "F3: extrapolate", "F4: clear", "F5: save", "", "", "", "", "", "", "", "", ""}
	local TitleRect = {}
	for i = 1, 16 do
		TitleRect[i] = {0, (0.79-i*0.02), 0.10, 0.3}
		TitleRect[i+16] = {0, (0.79-i*0.02), 0.25, 0.3}
	end
	TextList[1] = "Cam_Point"..gi_cameraIndex
	--TextList[2] =  NumberShip()
	TextList[20] = tostring(gt_origin[1])
	TextList[21] = tostring(gt_origin[2])
	TextList[22] = tostring(gt_origin[3])
	TextList[24] = tostring(gt_focal[1])
	TextList[25] = tostring(gt_focal[2])
	TextList[26] = tostring(gt_focal[3])
	TextList[11] = gs_message
	ATI_Clear()
	if block > 0 then
		for i = 1, block, 1 do
			ATI_CreateParameters(1)
			ATI_AddString(0, TextList[i])
			ATI_Display2D("CameraGPS", TitleRect[i], 0)
		end
	end
end


