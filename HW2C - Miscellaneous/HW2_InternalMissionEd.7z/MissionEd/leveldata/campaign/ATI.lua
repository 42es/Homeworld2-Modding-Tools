SCAR_ATITemplates =
{
    CameraGPS =
    {
        {
            stringParam = 0,
            text =
            {
                colour = {1,1,1,1},
    	        dropshadow = 0,
                renderFlags = {"justifyLeft"},
                LODs =
                {
                    1, "SPSubtitleFont",
                }
            },
            placement2D =
            {
                factorX = -0.05,
                factorY = -1,
                minATIArea = 0,
                maxATIArea = 1,
                visibility = {},
            },
        },
     },
}

