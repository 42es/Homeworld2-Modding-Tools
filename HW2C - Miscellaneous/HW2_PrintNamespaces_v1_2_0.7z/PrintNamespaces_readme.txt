PrintNamespaces 1.2
Created: 11/15/04 by Mikail
Last updated: 07/02/05
http://www.geocities.com/Area51/Quadrant/3864/homeworld.htm

CHANGES IN 1.2
* Moved all the code inside the "PrintLibraries()" function.

CHANGES IN 1.1
* Renamed the file from "PrintLibraries" to "PrintNamespaces".
* Added a few mre possible (but unconfirmed) namespaces to check.

INSTALLATION
Extract this archive into your "...\Homeworld2\Data\Scripts\" directory.

INTRODUCTION
This script prints a table to "HW2.log" listing the known libraries that are registered to the originating file.
You can use this in case "ThoughtDump.lua" doesn't work. You might get lucky.

INSTRUCTIONS
Use the "dofilepath()" function to read/call "PrintNamespaces.lua"..


