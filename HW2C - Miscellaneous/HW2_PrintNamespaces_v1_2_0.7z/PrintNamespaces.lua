-- PrintNamespaces v1.2
-- Created: 11/15/04 by Mikail
-- Last updated: 07/02/05

function PrintNamespaces()
	-- duplicate entries have been commented-out
	NameSpacesTable =
	{
		-- UI
	--	_LIBReg_debugrender = _LIBReg_debugrender,
	--	_LIBReg_luaappmainui = _LIBReg_luaappmainui,
	--	_LIBReg_luaappmisc = _LIBReg_luaappmisc,
	--	_LIBReg_luagameio = _LIBReg_luagameio,
	--	_LIBReg_LuaMenuSupport = _LIBReg_LuaMenuSupport,
	--	_LIBReg_luauserinterface = _LIBReg_luauserinterface,
	
		-- Gamerule
		_LIBReg_luaATI = _LIBReg_luaATI,
		_LIBReg_luacamera = _LIBReg_luacamera,
		_LIBReg_luacampaign = _LIBReg_luacampaign,
		_LIBReg_luacpu = _LIBReg_luacpu,
		_LIBReg_luafx = _LIBReg_luafx,
		_LIBReg_luagamesettings = _LIBReg_luagamesettings,
		_LIBReg_luahyperspace = _LIBReg_luahyperspace,
		_LIBReg_lualight = _LIBReg_lualight,
		_LIBReg_LuaMenuSupport = _LIBReg_LuaMenuSupport,
		_LIBReg_luanis = _LIBReg_luanis,
		_LIBReg_luaobjectives = _LIBReg_luaobjectives,
		_LIBReg_luaping = _LIBReg_luaping,
		_LIBReg_luaplayer = _LIBReg_luaplayer,
		_LIBReg_luasensor = _LIBReg_luasensor,
		_LIBReg_luashadow = _LIBReg_luashadow,
		_LIBReg_luasound = _LIBReg_luasound,
		_LIBReg_luasubtitle = _LIBReg_luasubtitle,
		_LIBReg_luateamactions = _LIBReg_luateamactions,
		_LIBReg_luateamquery = _LIBReg_luateamquery,
		_LIBReg_luauniverse = _LIBReg_luauniverse,
		_LIBReg_luauserinterface = _LIBReg_luauserinterface,
		_LIBReg_statlogging = _LIBReg_statlogging,
	
		-- Autoexec
		_LIBReg_debugrender = _LIBReg_debugrender,
		_LIBReg_luaappmainui = _LIBReg_luaappmainui,
		_LIBReg_luaappmisc = _LIBReg_luaappmisc,
	--	_LIBReg_luacamera = _LIBReg_luacamera,
		_LIBReg_luagameio = _LIBReg_luagameio,
		_LIBReg_luagamemainui = _LIBReg_luagamemainui,
		_LIBReg_luagamemisc = _LIBReg_luagamemisc,
	--	_LIBReg_luagamesettings = _LIBReg_luagamesettings,
	--	_LIBReg_LuaMenuSupport = _LIBReg_LuaMenuSupport,
		_LIBReg_luaplayer_console = _LIBReg_luaplayer_console,
		_LIBReg_luarender = _LIBReg_luarender,
	--	_LIBReg_luauniverse = _LIBReg_luauniverse,
	--	_LIBReg_luauserinterface = _LIBReg_luauserinterface,
	--	_LIBReg_statlogging = _LIBReg_statlogging,
	
		-- AI
	--	_LIBReg_statlogging = _LIBReg_statlogging,
	
		-- Level
		_LIBReg_lualoadlevel = _LIBReg_lualoadlevel,
		_LIBReg_luafog = _LIBReg_luafog,
	
		-- Unsure
		_LIBReg_luashipdebug = _LIBReg_luashipdebug,
		_LIBReg_luanisdebug = _LIBReg_luanisdebug,
		_LIBReg_Scar = _LIBReg_Scar,
		_LIBReg_Scar = _LIBReg_Scar,
		_LIBReg_ScarEventSystem = _LIBReg_ScarEventSystem,
		_LIBReg_MadState = _LIBReg_MadState,
		_LIBReg_LuaRuleSystem = _LIBReg_LuaRuleSystem,
		_LIBReg_LuaRule = _LIBReg_LuaRule,
		_LIBReg_luatrace = _LIBReg_luatrace,
		_LIBReg_GameLua = _LIBReg_GameLua,
		_LIBReg_nisdebug = _LIBReg_nisdebug,
		_LIBReg_shipdebug = _LIBReg_shipdebug,
	}
	print("NameSpaces =\n{")
	for i, v in NameSpacesTable do
		if (v) then
			print("	" .. i .. " = " .. v .. ",")
		else
			print("	" .. i .. " = nil,")
		end
	end
	print("}")
end

PrintNamespaces()