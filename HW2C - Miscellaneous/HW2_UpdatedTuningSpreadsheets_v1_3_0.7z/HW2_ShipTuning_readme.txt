HW2 Updated Tuning Spreadsheets v1.3
Created: ??/??/?? by Mikail
Last updated: 04/16/06
Original version by Relic Entertainment.
Homepage: http://www.geocities.com/Area51/Quadrant/3864/homeworld.htm


INSTRUCTIONS
Add the HW2_ROOT environmental variable to your OS startup scripts.
To create a new ship, simply insert/copy a new column to the "ShipData" sheet and add/change the desired values.
To add a new race, unhide the "Validation" sheet and insert a new race name and prefix into the table [note: make sure the race names are in alphabetical order].
Ship names must begin with the race name, followed by a space, in order to export properly.
Race names may not have any spaces in them. All other spaces are deleted, automatically.


CHANGE LOG
v1.3
* Added all the tuning spreadsheets -- not just "ShipTuning.xls".

v1.21
* Added descriptions for some of the Ship Hold ability stuff.
* Removed some blank rows.

v1.2
* Added additional comments found at Karos Graveyard.
* Ship files are now exported properly.
* Comments have been reformatted/resized to display better.
* Reorganized some of the categories.
* Removed the ship list from the "Validation" sheet.

v1.1
* Re-added some comments I inadvertantly deleted.

v1.0
* Reformatted the cells to be more ergonomic.
* Reversed the grouping order.
* Moved the "Prefix" and "Extension" cells to the "Validation" sheet.
* Edited the macros to not look for the "LastShip" cell.
