#!BPY
"""
Name: 'HW2 Mesh Colorizer'
Blender: 249
Group: 'Object'
Tooltip: 'Changes greyscale material colors to hued colors'
"""

__author__ = "'Sagyxil' Stott"
__email__ = ['Sagyxil, sagyxilwoodshadow:hotmail*com']
__version__ = "1.0"

__bpydoc__ = """\
This script will add color to all materials used by all meshes in a scene.

Usage:
This script will colorize all black, grey or white colored meshes, to make it easier to distinguish what material a face is assigned.
Note that this will NOT affect in-game appearence (presuming you are using this for modifying Homeworld 2 meshes).
"""
#
# Script copyright (C) Matthew R Stott 2009
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****
# --------------------------------------------------------------------------

import Blender
from Blender import *

import colorsys
from colorsys import *

def setupMaterials(meshObjectList):
	meshCount = len(meshObjectList)
	nMesh = 0
	nColorTotal = 0
	for obj in meshObjectList:
		mesh = obj.getData()
		matList = mesh.materials
		nMaterial = len(matList)
		if nMaterial > 0:
			fAngle = 1.00/nMaterial
			fVal = 0.50/meshCount
			nDex = 0
		else:
			nMesh += 1
			continue
		
		for mater in matList:
			r,g,b = mater.getRGBCol()
			if r==g==b:
				color = colorsys.hsv_to_rgb(fAngle*nDex,1.0,1.0-fVal*nMesh)
			else:
				continue
			try:		mater.setRGBCol( color )
			except TypeError: continue
			# Add a diffuse and glow texture to this material.
			texDiffuse = Texture.New('Mat'+str(nColorTotal)+'_$diffuse')
			texGlow = Texture.New('Mat'+str(nColorTotal)+'_$glow')
			texDiffuse.setType('Image')
			texGlow.setType('Image')
			texDiffuse.flags = texGlow.flags = 8
			mater.setTexture(0, texDiffuse)
			mater.setTexture(1, texGlow)
			mTex = mater.getTextures()
			mTex[0].mapto = 1 # COL
			mTex[1].mapto = 2048 # AMB
			mTex[0].texco = mTex[1].texco = 16 # UV
			nColorTotal += 1
			nDex+=1
		nMesh += 1

scn = Scene.GetCurrent()

if __name__ == "__main__":
	meshList = []
	for obj in scn.objects:
		print obj , obj.getType()
		if obj.getType() == 'Mesh':
			meshList.append(obj)
	print "Checking meshes:",meshList
	setupMaterials(meshList)
	Blender.Window.RedrawAll()