# Imports a *.hsc script
# Creates Empties and changes the empties shape, for NavLights (SPHERE) and Hierarchy points (Varying shapes)
# Creates paths for Dockpoints
# Performs parenting of appropriate things

#!BPY
"""
Name: 'HOD Script (*.hsc)...'
Blender: 249
Group: 'Object'
Tooltip: 'Import a HOD script (*.hsc) file'
"""

__author__ = "'Sagyxil' Stott"
__email__ = ['Sagyxil, sagyxilwoodshadow:hotmail*com']
__version__ = "1.15"

__bpydoc__ = """\
This script is an importer for the HSC file format; produced by the CFHod program.

Usage:
This script will import the following as the following blender objects:
Joint hierarchy - Empties of varying shapes
Navlight - Lamp and empty
Marker - Plain-axes empty
Dockpaths - 3-D Curve
If the option marked "Make Groups" is selected, then the new objects will be grouped accordingly.
Note: All joint/hierarchy/marker names will be shortened to less than 21 characters long.
"""
# CHANGELOG 
# 8/3/09: the options "NavLights", "Reference Curve" and "Keyframes" now actually do something, fixed the menu; it works now. Made joint and dock sub-option buttons disappear when the Joint or Dock buttons are disabled.
# 8/4/09: Added a new option: Rotate X90, which will translate HOD UP to Blender's UP
# 8/5/09: Fixed a minor misnaming problem in the menu; and a few problems with the way joints were rotated.
# 8/6/09: Added option to import all *.obj files and *.tga files in the same directory as the HOD script.
# 8/15/09:	Dockpath keyframes will now be set by their maxSpeed and distance between nodes.
#					NavLights are now animated. 
# 				Made the mesh colorizer a separate script, for some reason it won't work within this script.
# ***** BEGIN GPL LICENSE BLOCK *****
#
# Script copyright (C) Matthew R Stott 2009
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****
# --------------------------------------------------------------------------

import Blender
from Blender import *
from Blender import Mathutils
from Blender.Mathutils import * # for position vector and rotation euler
# import bpy
# import BPyMessages

# PYTHON libraries
try: 
	import re
	from re import *
except:		re = None

try:
	import math
	from math import radians,pi
except: math = None

try:
	from decimal import * # for dealing with the scientific notation
except:	decimal = None

import os.path
from os.path import *

import import_obj
from import_obj import load_obj, load_obj_ui

# Data Classes
class Joint():
	def __init__(self,fullname,name,parent,loc,rot,axis,sca,DoF,shape,size):
		self.fullname = fullname			# string
		self.name = name							# string
		self.parent = parent					# string
		self.loc = loc								# Vector; loc.x, loc.y, loc.z
		self.rot = rot								# Euler; rot.x, rot.y, rot.z
		self.axis = axis							# Euler; axis.x, axis.y, axis.z
		self.sca = sca								# Vector; sca.x, sca.y, sca.z
		self.DoF = DoF								# int
		self.shape = shape						# integer, range[1-7]
		self.size = size							# float
	
class DockPath():
	def __init__(self,name,parent,isExit,isLatchPath,dockFamilies,useDockAnimation,linkedPaths,points):
		self.name = name
		self.parent = parent
		self.isExit = isExit
		self.isLatchPath = isLatchPath
		self.dockFamilies = dockFamilies
		self.useDockAnimation = useDockAnimation
		self.linkedPaths = linkedPaths
		self.points = points
	
class pathPoint():
	def __init__(	self,interIn,interOut,loc,rot,\
								useRotation,\
								pointTolerance,\
								dropFocus,\
								maxSpeed,\
								checkRotation, forceCloseBehavior, playerInControl, queueOrigin, useClipPlane, advanceQueue):
		self.interIn = interIn
		self.interOut = interOut
		self.loc = loc
		self.rot = rot
		self.useRotation = useRotation
		self.pointTolerance = pointTolerance
		self.dropFocus = dropFocus
		self.maxSpeed = maxSpeed
		self.checkRotation = checkRotation
		self.forceCloseBehavior = forceCloseBehavior
		self.playerInControl = playerInControl
		self.queueOrigin = queueOrigin
		self.useClipPlane = useClipPlane
		self.advanceQueue = advanceQueue
	
class index:    # Contains index inf	o.
	def __init__(self, gen, color, matTex):
		self.gen = gen
		self.color = color
		self.tex = matTex

	# reset all indices
	def resetAll():
		self.gen = 0
		self.color = 0
		self.matTex = 0
		
	# Increment all indices
	def incAll():
		self.gen = self.gen+1
		self.color = self.color+1
		self.matTex = self.matTex+1

class counter:
	def __init__(self, materials,joints,markers,paths,skipped):
		self.materials = materials
		self.joints = joints
		self.markers = markers
		self.paths = paths	
		self.skipped = skipped

# class patterns:
	# def __init__(self,navlights,joints,markers,dock_add,dock_setkeyframe):
		# self.navlights = navlights
		# self.joints = joints
		# self.markers = markers
		# self.dock_add = dock_add
		# self.dock_setkeyframe = dock_setkeyframe
# Create a global name for the current scene
scn = Blender.Scene.GetCurrent()

# Create the global joint known as Root
try:
	root = Object.Get('Root')
	Root = Joint('Root','Root','',Vector(0.0,0.0,0.0),Euler(math.radians(-90.0),0.0,0.0),Euler(0.0,0.0,0.0),Vector(1.0,1.0,1.0),7,3,root.size)
except:
	root = scn.objects.new('Empty', 'Root')
	root.emptyShape = 3
	root.drawSize = 0.010
	root.size = 100.0, 100.0, 100.0
	root.setEuler(0,0,0)
	
	Root = Joint('Root','Root','',Vector(0.0,0.0,0.0),Euler(math.radians(-90.0),0.0,0.0),Euler(0.0,0.0,0.0),Vector(1.0,1.0,1.0),7,3,root.size)
	
Blender.Window.Redraw()
d90d = -90.0
XRot = Matrix((1,0,0),(0,0,-1),(0,1,0))# RotationMatrix(d90d, 3, 'x')

patterns = {}
patterns['navlights'] = r'''
		"(?P<name>.*)",
		[\s]?(?P<section>[0-9]*),
		[\s]?(?P<size>[0-9.]*),
		[\s]?(?P<phase>[0-9.]*),
		[\s]?(?P<freq>[0-9.]*),
		[\s]?"(?P<style>.*)",
		[\s]?(?P<red>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<green>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<blue>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<alpha>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<distance>[0-9.]*),
		[\s]?(?P<bVisible>[01]),
		[\s]?(?P<bLight>[01])
		'''
patterns['joints'] = r'''
		"(?P<name>.*)",
		[\s]?"(?P<parent>.*)",
		[\s]?(?P<locX>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<locY>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<locZ>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<rotX>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<rotY>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<rotZ>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<scaX>[-]?[0-9.]+),
		[\s]?(?P<scaY>[-]?[0-9.]+),
		[\s]?(?P<scaZ>[-]?[0-9.]+),
		[\s]?(?P<axisX>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<axisY>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<axisZ>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<DoFX>[01]),
		[\s]?(?P<DoFY>[01]),
		[\s]?(?P<DoFZ>[01])
		'''
patterns['markers'] = r'''
		"(?P<name>.*)",
		[\s]?"(?P<parent>.*)",
		[\s]?(?P<unknown1>[01]),
		[\s]?(?P<unknown2>[01]),
		[\s](?P<locX>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<locY>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<locZ>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<rotX>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<rotY>[-]?[0-9.]+[E0-9-]*),
		[\s]?(?P<rotZ>[-]?[0-9.]+[E0-9-]*)
		'''
patterns['dock_add'] = r'''
			"(?P<name>.*)",
			[\s]?"(?P<parent>.*)",
			[\s]?(?P<isExit>[01]),
			[\s]?(?P<isLatchPath>[01]),
			[\s]?"(?P<dockfamilies>.*)",
			[\s]?(?P<useDockAnimation>[01]),
			[\s]?"(?P<linkedPaths>.*)",
			[\s]?(?P<numNodes>[0-9]+)'''
patterns['dock_setkeyframe'] = r'''
			[\s]*(?P<pathIndex>[0-9]*),
			[\s]*(?P<keyIndex>[0-9]*),
			[\s]*(?P<locX>[-]?[0-9.]+[E0-9-]*),
			[\s]*(?P<locY>[-]?[0-9.]+[E0-9-]*),
			[\s]*(?P<locZ>[-]?[0-9.]+[E0-9-]*),
			[\s]*(?P<rotX>[-]?[0-9.]+[E0-9-]*),
			[\s]*(?P<rotY>[-]?[0-9.]+[E0-9-]*),
			[\s]*(?P<rotZ>[-]?[0-9.]+[E0-9-]*),
			[\s]*(?P<useRotation>[01]),
			[\s]*(?P<pointTolerance>[-]?[0-9.]+[E0-9-]*),
			[\s]*(?P<dropFocus>[01]),
			[\s]*(?P<maxSpeed>[-]?[0-9.]+[E0-9-]*),
			[\s]*(?P<checkRotation>[01]),
			[\s]*(?P<forceCloseBehavior>[01]{1}),
			[\s]*(?P<playerCtrl>[01]),
			[\s]*(?P<queueOrigin>[01]),
			[\s]*(?P<useClipPlane>[01]),
			[\s]*(?P<advanceQueue>[01])'''
# FUNCTIONS
def simplifyName(str):										# Keep joint names to fewer than 21 characters, since Blender names may not be longer than 21 characters.
	#/-------(1)---------\=/-(2)-\==/-(3)-\==/-(4)-\==/-(5)-\==/-(6)-\==/-(7)-\==/-(8)-\==/-(9)-\==/-(10)-\==
	#| PRIVATE FUNCTIONS | | ... |  | ... |  | ... |  | ... |  | ... |  | ... |  | ... |  | ... |  | ...  |
	def __cutIt__(str,name_to_replace):
		'''Abbreviates names'''
		pattern = r'''([A-Z][a-z][a-z])'''
		shortest_name = re.split(pattern, str)
		name = ''
		# remcompose name from parts
		for group in shortest_name:	name = name + group
		return name

	#/-(1)-\=/----------(2)-------------\==/-(3)-\==/-(4)-\==/-(5)-\==/-(6)-\==/-(7)-\==/-(8)-\==/-(9)-\==/-(10)-\==
	#| ... | | SHORTEN TYPE AND SUBTYPE |  | ... |  | ... |  | ... |  | ... |  | ... |  | ... |  | ... |  | ...  |
	replaceList = [\
								[r'([Ww]eapon)','WP'],				[r'([Cc]apture[Pp]oint)','CP'],				[r'([Rr]epair[Pp]oint)','RP'],\
								[r'([Hh]ard[Pp]oint)','HP'],\
								
								[r'([Gg]eneric)','Gen'], 					[r'([Pp]roduction)','Prd'],				[r'([Ss]ensors)','Sen'],\
								[r'([Ss]ystem)','Sys'],						[r'([_][Ee]ngine)','_Eng'],				[r'([Rr]esource)','Res'],\
								[r'([Tt]arget)','Trg'],\
								[r'([Ss]lave)','$SL'],\
								
								[r'([Pp]osition)','$P'],					[r'([Ll]atitude)','$La'],					[r'([Dd]irection)','$D'],\
								[r'([Mm]uzzle)','$M'],						[r'([Rr]est)','$R'], 							[r'(?:\d)([Ll]eft)','$Lf'],\
								[r'(?<=\d)([Hh]eading)', '$H'],		[r'(?:\d)([Uu]p)', '$U']\
								]
	newStr = str[:] # Make a copy of the string to create an abbreviated version
	for rep in replaceList:	newStr = re.sub(rep[0],rep[1],newStr)
	
	#/-(1)-\=/-(2)-\==/------(3)-----\==/-(4)-\==/-(5)-\==/-(6)-\==/-(7)-\==/-(8)-\==/-(9)-\==/-(10)-\==
	#| ... | | ... |  | ISOLATE NAME |  | ... |  | ... |  | ... |  | ... |  | ... |  | ... |  | ...  |
	pattern = r'''
		(?P<type>[A-Z]{2})?
		[_]?
		(?:(?P<isProduction>Prd) | 
			(?P<isSensor>Sen) | 
			(?P<isSystem>Sys) | 
			(?P<isGeneric>Gen)|
			(?P<isTarget>Trg) |
			(?P<isEngine>Eng) | 
			(?P<isResource>Res))?
		(?P<name>[A-Za-z0-9_]*)
		(?P<isSlave>\$SL[0-9]*)?
		[_]
		(?P<subtype>\$[a-zA-Z]*)'''
	match_obj = re.search(pattern, newStr, re.VERBOSE)
	try:		name = match_obj.group('name')
	except:	name = str
	
	#/-(1)-\=/-(2)-\==/-(3)-\==/-------------(4)---------------\==/-(5)-\==/-(6)-\==/-(7)-\==/-(8)-\==/-(9)-\==/-(10)-\==
	#| ... | | ... |  | ... |  | RETURN NEW NAME AND FULL NAME |  | ... |  | ... |  | ... |  | ... |  | ... |  | ...  |
	return newStr, name

def makeNavLight(line):										# Creates a lamp for a NavLight
	'''Creates a new lamp for a NavLight'''
	# NAVL_Add("NavLightBay2", 1, 300, 0, 0, "default", 0.6078432, 1, 1, 1, 300, 0, 0);
	# "Name", nSection, fSize, fPhase, fFrequency, sStyle, fR, fG, fB, fA, fLightEmitDistance, bIsVisible, bIsLightSource
	match_obj = re.search(patterns['navlights'], line, re.VERBOSE)
	# This could also be reversed, i.e. make the lamp first then the empty; parent the empty to the lamp set the size as the 
	# lamp's scale, and use the empty as a "helper."
	#bKeepLink = False	
	name = match_obj.group('name')
	nameLamp = 'LA' + name
	
	try:		parent = Object.Get(name)
	except:	
		parent = Object.Get('Root')
		print "....NavLightError: parent joint didn't exist, Root will be treated as parent."
	loc = parent.getLocation()
	#parent.setSize(float(match_obj.group('size')),flo  at(match_obj.group('size')),float(match_obj.group(  'size')))
	nav = Lamp.New('Lamp',nameLamp)
	
	nav.R = float(match_obj.group('red'))
	nav.G = float(match_obj.group('green'))
	nav.B = float(match_obj.group('blue'))
	
	nav.dist = float(match_obj.group('distance'))
	
	nav.setMode('Sphere')
	try: 		IpoLA = Ipo.Get('LA'+name)
	except:	IpoLA = Ipo.New('Lamp', 'LA'+name)
	nav.setIpo(IpoLA)
	#curveLt = IpoLA.addCurve('Energ'); curveLt.extend = IpoCurve.ExtendTypes.CYCLIC; curveLt.interpolation = IpoCurve.InterpTypes.CONST
	
	ob = scn.objects.new(nav)
	
	ob.sel = False
	ob.setLocation(loc)
	if parent.name != 'Root':
		ob.makeParent([parent])
		parent.restrictSelect = True
	size = 0.1*float(match_obj.group('size'))
	ob.setSize(size,size,size)
	
	ob.addProperty('Section',	int(match_obj.group('section')),	'INT')
	
	phase = float(match_obj.group('phase'))
	freq = float(match_obj.group('freq'))
	
	try:		IpoOB = Ipo.Get('OB'+name)
	except:	IpoOB = Ipo.New('Object', 'OB'+name)
	
	parent.setIpo(IpoOB)
	ob.setIpo(IpoOB)
	# ANIMATION
	try: 	
		curveLay = IpoOB.addCurve('Layer')
		curveLay.extend = IpoCurve.ExtendTypes.CYCLIC
		curveLay.interpolation = IpoCurve.InterpTypes.CONST
		
		fps = Blender.Scene.GetCurrent().getRenderingContext().fps
		
		kI = phase*fps
		curveLay.append((kI, 2))
		
		k1 = kI+fps*freq # freq = (k1-kI)/fps
		curveLay.append((k1, 1))
		
		kF = k1+fps*freq
		curveLay.append((kF, 2))
		# END ANIMATION
		
		ob.addProperty('Style',		match_obj.group('style'),				'STRING')
		
		ob.addProperty('Alpha',		float(match_obj.group('alpha')),	'FLOAT')
		
		ob.addProperty('isVisible',			int(match_obj.group('bVisible')),	'BOOL')
		ob.addProperty('isLightSource',	int(match_obj.group('bLight')),		'BOOL')
	
		try: 			parent.parent.makeParent([ob])
		except: 	root.makeParent([ob])
	except: pass
	#if not bKeepLink and parent.name != 'Root':	scn.objects.unlink(parent)
	return ob
	

def appendJointData(line,jointData):				# Generate info for joint from line.
	def __determineShape__(obj):									# return an integer representing the joint's purpose
		global IMPORT_HIER_SHAPE
		try:
			str = obj.GetName() # if argument was an object
		except:
			str = obj # if argument was simply a string
		#print "DetermineShape string:",str
		#print "Default was set as 4 (Single Arrow)"
		if IMPORT_HIER_SIZE:
			if str.endswith(r'$P') 		or str.endswith('Position'):				shape = 5
			elif str.startswith('CP') or str.startswith('CapturePoint'):	shape = 7
			elif str.startswith('RP') or str.startswith('RepairPoint'):		shape = 7
			elif str.endswith(r'$M')	or str.endswith('Muzzle'):					shape = 4
			elif str.lower().startswith('nav'):														shape = 6
			else:																													shape = 1
		else:			shape = 1
		# Empty shapes: ARROWS =  1, AXIS - 2, CIRCLE = 3, ARROW = 4, CUBE = 5, SPHERE = 6, CONE = 7
		return shape
	'''Creates data for a new joint from contents of <line>; then appends the result to <jointData>'''
	global IMPORT_ROTX90
	result = Joint('','','',Vector(0.0,0.0,0.0),Euler(0.0,0.0,0.0),Euler(0.0,0.0,0.0),Vector(1.0,1.0,1.0),0,4,0.0)
	match_obj = re.search(patterns['joints'], line, re.VERBOSE)
	
	result.name, result.fullname = simplifyName(match_obj.group('name'))
	if len(result.name) <= 21: result.fullname = ''
	result.loc = Vector(\
		Decimal.normalize(Decimal(match_obj.group('locX'))  ),\
		Decimal.normalize(Decimal(match_obj.group('locY'))  ),\
		Decimal.normalize(Decimal(match_obj.group('locZ'))  ))
	if IMPORT_ROTX90:
		#jointXRot = RotationMatrix(90.0, 3, 'x')
		d90d = -90.0
		result.loc = Vector(result.loc.x, -1*result.loc.z, result.loc.y)
		result.rot = Euler(result.rot.x, result.rot.z, result.rot.y)
		if result.name.find('EngineNozzle') != -1:
			result.rot = Euler(\
			math.radians(float(match_obj.group('rotX')))+math.radians(180),\
													math.radians(float(match_obj.group('rotZ'))),\
													math.radians(float(match_obj.group('rotY'))) )
	if result.name.endswith('$M'):	result.rot = Euler(math.radians(90.0),0.0,0.0)
	if result.name.find('EngineNozzle') != -1:
		result.rot = Euler(\
		math.radians(float(match_obj.group('rotX')))+math.radians(90),\
												math.radians(float(match_obj.group('rotY'))),\
												math.radians(float(match_obj.group('rotZ'))) )
	else:
		result.rot = Euler(\
			math.radians(float(match_obj.group('rotX'))),\
			math.radians(float(match_obj.group('rotZ'))),\
			math.radians(float(match_obj.group('rotY'))))
	result.axis = Euler(\
		math.radians(float(match_obj.group('axisX'))),\
		math.radians(float(match_obj.group('axisY'))),\
		math.radians(float(match_obj.group('axisZ'))))	
	result.sca = Vector(\
		float(match_obj.group('scaX')),\
		float(match_obj.group('scaY')),\
		float(match_obj.group('scaZ')))
	result.DoF = int(match_obj.group('DoFX')),int(match_obj.group('DoFY')),int(match_obj.group('DoFZ'))
	
	
	#print result.fullname,"===>",result.name
	result.parent = simplifyName(match_obj.group('parent'))[0]    # Get joint's parent
	result.shape = __determineShape__(result.name)
	result.size = 1.0			# The size will be set during the level sorting
	jointData.append(result)
	
def sortJoints(jointData, bSizeByLevel=True):	# Sort joints into levels; groups of joints that sit in the same child level.
	'''Sort joints into levels'''
	class levelData:
		def __init__(self,name,parent,size):
			self.name = name
			self.parent = parent
			self.size = size
	levelList = [] # this is the most basic hierarchy, the Root should be the sole occupant of level 0.
	root_list = levelData('Root','',root.size)
	levelList.append([root_list])
	Superfluous = ['$Lf','$U','$H','$D','$R']
	bSkip = False
	for joint in jointData:
		for suf in Superfluous:
			if suf in joint.name[len(joint.name)-4:]:
				bSkip = True
				break
		if bSkip == True:
			bSkip = False
			continue
		#print 'Leveling joint',joint.name
		lookFor = levelData(joint.name,joint.parent,1.0)
		# Level
		# |- List
		#		|- Joint name, joint parent, joint size
		for list in levelList:
			for entry in list:
				if entry.name == lookFor.parent:
					try: 							levelList[levelList.index(list)+1].append(lookFor)
					except: 					levelList.append([lookFor])
	
	levelCount = len(levelList)
	# this will set scale by level
	if bSizeByLevel:
		for level in levelList[1:]:
			index = levelList.index(level)
			# Size will be based on the level the joint is in, level 0 (Root) should be the basis for all sizes, 
			# level 0 will be 100% scale (so it is left alone)
			# level X will be Level_0scale*X*0.2/(len(levelList)-1), but clamped to at least 1.0
			modifier = index*0.2/levelCount
			scale = root.size[0]*modifier
			if scale < 1.0: scale = 1.0
			for entry in level:
				joint = getJoint(jointData, entry.name)
				joint.size = [scale,scale,scale]
	return levelList

def getJointChildren(childLevel,jointName): # Returns a list of the names of the joint's children
	'''Returns a list of the names of the joint's children, on an error this will return an empty list.'''
	result = []
	for entry in childLevel:
		# print "[",entry.name, entry.parent,"]"
		if entry.parent == jointName:
			result.append(entry.name)
	return result

def getJoint(jointData, Name):						# Retrieve a joint by name
	'''Returns the jointData corresponding to <Name>'''
	# iterate through <jointData> and return the match, else return None
	for joint in jointData:
		if joint.name == Name:
			return joint
	return None

def makeJoint(joint):											# Creates an empty for the joint called <name> in the hierarchy
	'''Creates the specified joint'''
	try: 
		ob = Object.Get(joint.name)
		if ob.type == 'Mesh':
			ob1 = ob
			ob = Scene.GetCurrent().objects.new('Empty')
			ob1.setName('ME'+ob1.name)
			ob.setName(joint.name)
			
			ob.makeParent([ob1])
	except:
		ob = Object.New('Empty', joint.name)
	
	if joint.fullname != '': ob.addProperty('fullName',joint.fullname,'STRING')
	ob.emptyShape = joint.shape
	return ob
	
def makeMarker(line):											# Creates a plain-axis shape empty object for the markers
	global IMPORT_ROTX90
	'''Creates an animation/FX marker'''
	match_obj = re.search(patterns['markers'], line, re.VERBOSE)
	name = match_obj.group('name')
	parent = Object.Get(match_obj.group('parent'))
	unknown1 = int(match_obj.group('unknown1'))
	unknown2 = int(match_obj.group('unknown2'))
	loc = Vector(\
		Decimal.normalize(Decimal(match_obj.group('locX'))  ),\
		Decimal.normalize(Decimal(match_obj.group('locY'))  ),\
		Decimal.normalize(Decimal(match_obj.group('locZ'))  ))
	if IMPORT_ROTX90:
		loc = XRot*loc
		rot = Euler(\
			math.radians( float( Decimal.normalize(Decimal(match_obj.group('rotX'))  )) - d90d ),\
			math.radians( float( Decimal.normalize(Decimal(match_obj.group('rotY'))  ) )),\
			math.radians( float( Decimal.normalize(Decimal(match_obj.group('rotZ'))  ) ) ))
	else:
		rot = Euler(\
			math.radians( float( Decimal.normalize(Decimal(match_obj.group('rotX'))  )) ),\
			math.radians( float( Decimal.normalize(Decimal(match_obj.group('rotY'))  ) )),\
			math.radians( float( Decimal.normalize(Decimal(match_obj.group('rotZ'))  ) ) ))

	#empty = scn.objects.new('Empty',name)
	try:		
		empty = Object.Get(name)
	except:	
		empty = Object.New('Empty',name)
	empty.emptyShape = 2
	#empty.size = [scale,scale,scale]
	empty.setLocation(parent.getLocation())
	parent.makeParent([empty])
	#print "Creating a marker...",name
		#print "Location is:",loc
	empty.setLocation(loc)
	empty.setEuler(rot)
	return empty
	
def make_pathData(dockLines):
	global IMPORT_ROTX90
	'''Returns a list of dockPath data entries'''
	pathData = []
	path = None
	
	# No need to recompile patterns repeatedly, once is e'nuf.
	add_pattern = re.compile(patterns['dock_add'], re.VERBOSE)
	keyframe_pattern = re.compile(patterns['dock_setkeyframe'], re.VERBOSE)

	for line in dockLines:
		add = add_pattern.search(line)
		keyframe = keyframe_pattern.search(line)
		if add:
			if path:	pathData.append(path) # Append completed path to pathData list
			# further refine linked path data and dockFamilies into individual entries
			sFamilies = add.group('dockfamilies')
			sLinks 		= add.group('linkedPaths')
			
			splitFamily = re.split( r'''(\w+)''', sFamilies )
			splitLink		= re.split(	r'''(\w+)''', sLinks )
			listFamily =	[entry for entry in splitFamily if entry != '' and entry.find(',') == -1]
			listLink = 		[entry for entry in splitLink 	if entry != '' and entry.find(',') == -1]
			
			path = DockPath(\
				add.group('name'),\
				add.group('parent'),\
				bool(int(add.group('isExit'))),\
				bool(int(add.group('isLatchPath'))),\
				listFamily,\
				bool(int(add.group('useDockAnimation'))),\
				listLink,\
				[] ) # node points.
		
		elif keyframe:
			point = pathPoint(
				int(keyframe.group('pathIndex')),\
				int(keyframe.group('keyIndex')),\
				Vector(0.0,0.0,0.0),\
				Euler(0.0,0.0,0.0),\
				bool(int(keyframe.group('useRotation'))),\
				float(keyframe.group('pointTolerance')),\
				bool(int(keyframe.group('dropFocus'))),\
				Decimal.normalize(Decimal(keyframe.group('maxSpeed'))),\
				bool(int(keyframe.group('checkRotation'))),\
				bool(int(keyframe.group('forceCloseBehavior'))),\
				bool(int(keyframe.group('playerCtrl'))),\
				bool(int(keyframe.group('queueOrigin'))),\
				bool(int(keyframe.group('useClipPlane'))),\
				bool(int(keyframe.group('advanceQueue'))))
			point.loc = Vector(\
					Decimal.normalize(  Decimal( keyframe.group('locX') )  ),\
					Decimal.normalize(  Decimal( keyframe.group('locY') )  ),\
					Decimal.normalize(  Decimal( keyframe.group('locZ') )  ) )
			point.rot = Euler(\
				(float( Decimal.normalize(Decimal(keyframe.group('rotX'))  )) + 180.0),\
				float( Decimal.normalize(Decimal(keyframe.group('rotY'))  ) ),\
				float( Decimal.normalize(Decimal(keyframe.group('rotZ'))  ) ))
			if IMPORT_ROTX90:
				point.loc = Vector(point.loc.x, -point.loc.z, point.loc.y)
				point.rot = Euler(point.rot.x, point.rot.z, point.rot.y)
			# else:
				# point.rot = Euler(\
					# float( Decimal.normalize(Decimal(keyframe.group('rotX'))) )/10,\
					# float( Decimal.normalize(Decimal(keyframe.group('rotY'))) )/10,\
					# float( Decimal.normalize(Decimal(keyframe.group('rotZ'))) )/10)
			path.points.append(point)
		else:
			print "Skipping a line: Couldn't parse:",line
			continue
	return pathData

def makeDockpath(path):
	'''Returns a list of all created Blender Objects (but not the Ipo)'''
	def __makeNode__(	ipo, keyInd, loc, rot): #, scale=1.0):		# Sets up data for the curves
		'''Adds a IPO nodes to the IPO curve.'''
		ipo[Ipo.OB_LOCX].append((keyInd, loc.x))
		ipo[Ipo.OB_LOCY].append((keyInd, loc.y))
		ipo[Ipo.OB_LOCZ].append((keyInd, loc.z))
		
		ipo[Ipo.OB_ROTX].append((keyInd, rot.x/10))
		ipo[Ipo.OB_ROTY].append((keyInd, rot.y/10))
		ipo[Ipo.OB_ROTZ].append((keyInd, rot.z/10))
		
			
	# def __modNode__( ipo, ind, keyframe, loc, rot):		
		# error = ''
		
		# bzX = BezTriple.New([keyframe, newPoint.loc.x,0.0])
		# bzX.handleTypes = [BezTriple.HandleTypes.AUTO,BezTriple.HandleTypes.AUTO]
		# bzY = BezTriple.New([keyframe, newPoint.loc.y,0.0])
		# bzY.handleTypes = [BezTriple.HandleTypes.AUTO,BezTriple.HandleTypes.AUTO]
		# bzZ = BezTriple.New([keyframe, newPoint.loc.z,0.0])
		# bzZ.handleTypes = [BezTriple.HandleTypes.AUTO,BezTriple.HandleTypes.AUTO]
		
		# bzRX = BezTriple.New([keyframe, newPoint.rot.x,0.0])
		# bzRX.handleTypes = [BezTriple.HandleTypes.AUTO,BezTriple.HandleTypes.AUTO]
		# bzRY = BezTriple.New([keyframe, newPoint.rot.y,0.0])
		# bzRY.handleTypes = [BezTriple.HandleTypes.AUTO,BezTriple.HandleTypes.AUTO]
		# bzRZ = BezTriple.New([keyframe, newPoint.rot.z,0.0])
		# bzRZ.handleTypes = [BezTriple.HandleTypes.AUTO,BezTriple.HandleTypes.AUTO]
		
		# ipo[Ipo.OB_LOCX].bezierPoints[ind].vec = bzX
		# # except: error += 'LocX'
		# try: ipo[Ipo.OB_LOCY].bezierPoints[ind].vec = bzY
		# except: error += ', LocY'
		# try: ipo[Ipo.OB_LOCZ].bezierPoints[ind].vec = bzZ
		# except: error += ', LocZ'
		
		# try: ipo[Ipo.OB_ROTX].bezierPoints[ind].vec = bzRX
		# except: error += ', RotX'
		# try: ipo[Ipo.OB_ROTY].bezierPoints[ind].vec = bzRY
		# except: error += ', RotY'
		# try: ipo[Ipo.OB_ROTZ].bezierPoints[ind].vec = bzRZ
		# except: error += ', RotZ'
		# if error != '':
			# print "ERROR changing knot values for Ipo",ipo.name,"for the following Ipo curves:",error
		
	def __makePointToleranceSphere__(keyInd, point):
		# Create an empty to contain the variables for this keyframe
		name = path.name + "_key" + str(keyInd)
		try:	ptEmpty = Object.Get(name)
		except: ptEmpty = scn.objects.new('Empty', name)
		
		ptEmpty.setLocation(point.loc)
		if point.pointTolerance > 0:
			# print point.rot.x, point.rot.y, point.rot.z
			euler = Euler(math.radians(point.rot.x), math.radians(point.rot.y), math.radians(point.rot.z))
			ptEmpty.setEuler(euler)
			ptEmpty.size = point.pointTolerance, point.pointTolerance, point.pointTolerance
			ptEmpty.emptyShape = 6 # Sphere
		else:
			euler = Euler(math.radians(point.rot.x-90), math.radians(point.rot.y), math.radians(point.rot.z))
			ptEmpty.setEuler(euler)
			ptEmpty.size = 1.0, 1.0, 1.0
			ptEmpty.emptyShape = 3 # Circle
		
		
		ptEmpty.addProperty("UseRot", 						point.useRotation,				"BOOL")
		ptEmpty.addProperty("MaxSpeed", 					point.maxSpeed,						"FLOAT")
		ptEmpty.addProperty("DropFocus", 					point.dropFocus,					"BOOL")
		ptEmpty.addProperty("checkRotation", 			point.checkRotation,			"BOOL")
		ptEmpty.addProperty("forceCloseBehavior", point.forceCloseBehavior,	"BOOL")
		ptEmpty.addProperty("playerInControl", 		point.playerInControl,		"BOOL")
		ptEmpty.addProperty("queueOrigin", 				point.queueOrigin,				"BOOL")
		ptEmpty.addProperty("useClipPlane", 			point.useClipPlane,				"BOOL")
		ptEmpty.addProperty("advanceQueue", 			point.advanceQueue,				"BOOL")
		return ptEmpty
	
	def __makeReferenceCurve__(points):
		name = path.name+'REFCURVE'
		try:
			cu = Object.Get(name)
			curve = cu
			ob = cu.getData()
			try: scn.objects.link(cu)
			except: pass
			n = 0
			for point in points:
				ob.setControlPoint(0, n, BezTriple.New([point.loc]).vec)
				# except:	cu.append(BezTriple.New(point.loc))
				n += 1
		except:
			ob = Curve.New(name)
			curve = scn.objects.new(ob)
			bz = BezTriple.New(points[0].loc)
			cu = ob.appendNurb(bz)
			for point in points[1:]:
				cu.append(BezTriple.New(point.loc))
		return curve
	#/------(1)------\=/-(2)-\==/-(3)-\==/-(4)-\==/-(5)-\
	#| DUMMY GENESIS | | ... |  | ... |  | ... |  | ... |
	# Create dummy ship that will follow the Ipo curve and contain the general dockpath flags
	global grpDOCK, IMPORT_DOCK_KEYFRAMES, IMPORT_DOCK_REFCURVE
	try: empty = Object.Get(path.name)
	except:  
		empty = scn.objects.new('Empty')
		empty.setName(path.name)
	empty.emptyShape = 7
	empty.setEuler(Euler(math.radians(90.0),0,0))
	empty.size = root.drawSize*100.0, root.drawSize*100.0, root.drawSize*100.0
	empty.drawSize = 10.0
	if IMPORT_MAKEGROUPS:	grpDOCK.objects.link(empty)
	
	# Enable dupliframes
	if IMPORT_DOCK_KEYFRAMES:		empty.enableDupFrames = True
	# Create a new Ipo object to animate the dummy ship.
	try: 		ipo = Ipo.Get(path.name)
	except: ipo = Ipo.New('Object',path.name)
	
	# Set the new Ipo as the empty's Ipo
	empty.setIpo(ipo)
	
	#/-(1)-\==/-----------(2)-------------\==/-(3)-\==/-(4)-\==/-(5)-\
	#| ... |  | PATH VARIABLES ASSIGNMENT |  | ... |  | ... |  | ... |
	empty.addProperty("isExit", 					path.isExit,					"BOOL")
	empty.addProperty("isLatchPath",			path.isLatchPath,			"BOOL")
	
	n = 1
	for entry in path.dockFamilies:
		empty.addProperty("dockFamily"+str(n), entry, 'STRING')
		n += 1
	
	empty.addProperty("useDockAnimation", path.useDockAnimation,"BOOL")
	
	n = 1
	for entry in path.linkedPaths:
		empty.addProperty('linkedPath'+str(n), entry, 'STRING')
		n += 1
	# empty.addProperty("linkedPaths", 			path.linkedPaths,			"STRING")
	
	#/-(1)-\==/-(2)-\==/--------(3)--------\==/-(4)-\==/-(5)-\
	#| ... |  | ... |  | IPO CURVE GENESIS |  | ... |  | ... |
	# Delete any existing curves
	try: 								ipo[Blender.Ipo.OB_LOCX] = None
	except ValueError:	pass
	try: 								ipo[Blender.Ipo.OB_LOCY] = None
	except ValueError:	pass
	try: 								ipo[Blender.Ipo.OB_LOCZ] = None
	except ValueError:	pass
	try: 								ipo[Blender.Ipo.OB_ROTX] = None
	except ValueError:	pass
	try: 								ipo[Blender.Ipo.OB_ROTY] = None
	except ValueError:	pass
	try: 								ipo[Blender.Ipo.OB_ROTZ] = None
	except ValueError:	pass
	
	
	# Add fresh new ones now
	curvesToAdd = ['LocX', 'LocY', 'LocZ', 'RotX', 'RotY', 'RotZ']
	for c in curvesToAdd:		ipo.addCurve(c)
	
	#/-(1)-\==/-(2)-\==/-(3)-\==/--------(4)----------\==/-(5)-\
	#| ... |  | ... |  | ... |  | ADD REFERENCE CURVE |  | ... |
	if IMPORT_DOCK_REFCURVE:
		curve = __makeReferenceCurve__(path.points)
		pathGroup = [curve, empty]
	else:			pathGroup = [empty]
	#/-(1)-\==/-(2)-\==/-(3)-\==/-(4)-\==/-------------(5)-------------\
	#| ... |  | ... |  | ... |  | ... |  | ADD POINT TOLERANCE SPHERES |
	kf_index = 0
	fps =  Blender.Scene.GetCurrent().getRenderingContext().fps
	if fps == 0:	fps = 25
	
	prevLoc = None
	prevRot = None
	n = 0
	kf_index = 0
	for point in path.points:
		# Calculate distance between two nodes
		if prevLoc:
			dist = Vector(point.loc.x-prevLoc.x, point.loc.z-prevLoc.z, point.loc.y-prevLoc.y).length
			# Calculate the time it will take to arrive at the node at the given max speed
			if point.maxSpeed > 0: min_time = math.ceil(float(fps) * float(dist)/float(point.maxSpeed)) # time (sec) to arrive here at maxSpeed
			else:									 min_time = math.ceil(float(fps) * float(dist)/float(150))
		else: 
			min_time = 1 # This is about 1/25th of a second.
		kf_index = kf_index+min_time
		# if point.useRot:
			# rotToUse = point.rot
		# else:
			# rotToUse = preRot
		
		#prevRot = Vector(point.rot.x, point.rot.y, point.rot.z)
		__makeNode__(ipo, kf_index, point.loc, point.rot)
		sphere = __makePointToleranceSphere__(path.points.index(point)+1, point)
		pathGroup.append(sphere)
		n += 1
		prevLoc = Vector(point.loc.x, point.loc.y, point.rot.z)
	#print "pathGroup",pathGroup
	return pathGroup
	
def load_obj_ui(filepath):										# Sets up the pop-up block display
	if True:
		global	IMPORT_HIER, IMPORT_HIER_NAVL, IMPORT_HIER_SHAPE, IMPORT_HIER_SIZE, IMPORT_MRKR,\
						IMPORT_DOCK, IMPORT_DOCK_REFCURVE, IMPORT_DOCK_KEYFRAMES, IMPORT_MAKEGROUPS, IMPORT_ROTX90,\
						IMPORT_OBJTGA, IMPORT_OBJ, IMPORT_OBJ_MENU, IMPORT_TEX, IMPORT_TEX_TYPE
		
		IMPORT_COLOR_MESH_MAT = Blender.Draw.Create(1)
		IMPORT_ROTX90 = Blender.Draw.Create(1)
		
		IMPORT_HIER = Blender.Draw.Create(1)
		IMPORT_HIER_NAVL = Blender.Draw.Create(1)
		IMPORT_HIER_SHAPE = Blender.Draw.Create(1)
		IMPORT_HIER_SIZE = Blender.Draw.Create(1)
		
		IMPORT_MRKR = Blender.Draw.Create(1)
		
		IMPORT_DOCK = Blender.Draw.Create(1)
		IMPORT_DOCK_REFCURVE = Blender.Draw.Create(0)
		IMPORT_DOCK_KEYFRAMES = Blender.Draw.Create(0)
		
		IMPORT_MAKEGROUPS = Blender.Draw.Create(1)
		
		IMPORT_OBJ = Blender.Draw.Create(1)
		IMPORT_OBJ_MENU = Blender.Draw.Create(0)
		IMPORT_TEX = Blender.Draw.Create(1)
		IMPORT_TEX_TYPE = Blender.Draw.Create(2)
		
		EVENT_NONE = 0
		EVENT_DRAW = 1
		EVENT_EXIT = 2
		EVENT_IMPORT = 3
		
		GLOBALS = {}
		GLOBALS['EVENT'] = EVENT_DRAW
		GLOBALS['MOUSE'] = [i/2 for i in Window.GetScreenSize()]
		
		def obj_ui_set_event(e,v):
			GLOBALS['EVENT'] = e
			
		def obj_ui():
			global	IMPORT_HIER, IMPORT_HIER_NAVL, IMPORT_HIER_SHAPE, IMPORT_HIER_SIZE, IMPORT_MRKR,\
							IMPORT_DOCK, IMPORT_DOCK_REFCURVE, IMPORT_DOCK_KEYFRAMES, IMPORT_MAKEGROUPS, IMPORT_ROTX90,\
							IMPORT_OBJ, IMPORT_OBJ_MENU, IMPORT_TEX, IMPORT_TEX_TYPE
			
			ui_x, ui_y = GLOBALS['MOUSE']
			
			# Calculate center
			ui_x -= 130
			ui_y -= 175
			
			Draw.Label('Import Options...', ui_x+8, ui_y+240, 322, 20)
			Draw.BeginAlign()
			IMPORT_ROTX90 =	Draw.Toggle('Rotate X90', 					EVENT_NONE, ui_x+5, ui_y+220, 165, 20, IMPORT_ROTX90.val, "Make Joint's UP match up with Blender's UP")
			IMPORT_MAKEGROUPS =	Draw.Toggle('Make Groups', 			EVENT_NONE, ui_x+180, ui_y+220, 165, 20, IMPORT_MAKEGROUPS.val, 'Organize all imported objects into Groups.')
			Draw.EndAlign()
			
			if import_obj:
				Draw.BeginAlign()
				IMPORT_OBJ = Draw.Toggle('Import Meshes', 		EVENT_DRAW, 	ui_x+5, 		ui_y+190, 165, 20, IMPORT_OBJ.val, 'Import Wavefront (*.obj) files')
				if IMPORT_OBJ.val:
					IMPORT_OBJ_MENU =	Draw.Toggle('Show OBJ menu',	EVENT_DRAW,		ui_x+170, ui_y+190, 165, 20, IMPORT_OBJ_MENU.val, 'Show OBJ import menu')
				Draw.EndAlign()
			else:
				glColor3f(1,0.1,0)
				glRasterPos2i(ui_x+5, ui_y+192)
				Draw.Text("----N/A----")
				Draw.PushButton('Import Meshes', 		EVENT_NONE, 	ui_x+5, 		ui_y+190, 165, 20, 'Couldn\'t find "import_hsc.py".')
			Draw.BeginAlign()
			IMPORT_TEX =	Draw.Toggle('Import Images', 		EVENT_DRAW, 	ui_x+5, 	ui_y+170, 165, 20, IMPORT_TEX.val, 'Import Targa (*.tga) files')
			if IMPORT_TEX.val:
				IMPORT_TEX_TYPE =	Draw.Menu('Image Format%t|DDS%x1|TGA%x2|DDS and TGA%x3', 		EVENT_DRAW, 	ui_x+170, 	ui_y+170, 165, 20, IMPORT_TEX_TYPE.val, 'Select image format')
			Draw.EndAlign()
			
			Draw.BeginAlign()
			IMPORT_HIER = Draw.Toggle('Joint Hierarchy', 	EVENT_DRAW, ui_x+5, 	ui_y+130, 330, 20, IMPORT_HIER.val, 'Import joint hierarchy')
			if IMPORT_HIER.val:
				IMPORT_HIER_NAVL = Draw.Toggle('NavLights', 				EVENT_DRAW, ui_x+5, 	ui_y+110, 110, 20, IMPORT_HIER_NAVL.val, 'Import NavLights as Lamps')
				IMPORT_HIER_SHAPE =	Draw.Toggle('Rel. Shape',				EVENT_DRAW, ui_x+115, ui_y+110, 110, 20, IMPORT_HIER_SHAPE.val, 'Use shapes to differentiate between different joint types.')
				IMPORT_HIER_SIZE =	Draw.Toggle('Rel. Size',				EVENT_DRAW, ui_x+225, ui_y+110, 110, 20, IMPORT_HIER_SIZE.val, 'Make joint scaling relative to the Root (makes it easier to see them at a distance).')
			else:	IMPORT_HIER_NAVL.val = IMPORT_HIER_SHAPE.val = IMPORT_HIER_SIZE.val = 0
			Draw.EndAlign()
			
			IMPORT_MRKR =	Draw.Toggle('Marker',						EVENT_NONE,	ui_x+5, 	ui_y+80,	330, 20, IMPORT_MRKR.val, 'Import markers',obj_ui_set_event)
			IMPORT_DOCK =	Draw.Toggle('Dockpaths', 				EVENT_DRAW, ui_x+5, 	ui_y+50, 	330, 20, IMPORT_DOCK.val, 'Import dockpaths')
			
			if IMPORT_DOCK.val:
				Draw.BeginAlign()
				IMPORT_DOCK_REFCURVE =	Draw.Toggle('Reference Curve',	EVENT_DRAW, ui_x+5, 	ui_y+30, 165, 20, IMPORT_DOCK_REFCURVE.val, "Make a reference curve for each path; this path doesn\'t actually affect anything, it's just there as a reference.")
				IMPORT_DOCK_KEYFRAMES =	Draw.Toggle('Show Keyframes',		EVENT_DRAW, ui_x+170, ui_y+30, 165, 20, IMPORT_DOCK_KEYFRAMES.val, 'Show ghosted keyframes for each path.')
				Draw.EndAlign()
			else: IMPORT_DOCK_REFCURVE.val = IMPORT_DOCK_KEYFRAMES.val = 0
			
			Draw.PushButton('Cancel', EVENT_EXIT, ui_x+25, ui_y+5, 120, 20, '', obj_ui_set_event)
			Draw.PushButton('Import', EVENT_IMPORT, ui_x+185, ui_y+5, 120, 20, '', obj_ui_set_event)
			
		while GLOBALS['EVENT'] not in (EVENT_EXIT, EVENT_IMPORT):
			if GLOBALS['EVENT'] == Draw.ESCKEY:
				Draw.Exit()
				return
			try:	Draw.UIBlock(obj_ui, 0)
			except: break
		if GLOBALS['EVENT'] != EVENT_IMPORT:
			return
		IMPORT_COLOR_MESH_MAT = IMPORT_COLOR_MESH_MAT.val
		IMPORT_MAKEGROUPS	= IMPORT_MAKEGROUPS.val
		IMPORT_ROTX90 = IMPORT_ROTX90.val
		
		IMPORT_HIER = IMPORT_HIER.val
		IMPORT_HIER_NAVL = IMPORT_HIER_NAVL.val
		IMPORT_HIER_SHAPE = IMPORT_HIER_SHAPE.val
		IMPORT_HIER_SIZE = IMPORT_HIER_SIZE.val
		
		IMPORT_MRKR = IMPORT_MRKR.val
		
		IMPORT_DOCK = IMPORT_DOCK.val
		IMPORT_DOCK_REFCURVE = IMPORT_DOCK_REFCURVE.val
		IMPORT_DOCK_KEYFRAMES = IMPORT_DOCK_KEYFRAMES.val
		
		IMPORT_OBJ = IMPORT_OBJ.val
		IMPORT_OBJ_MENU = IMPORT_OBJ_MENU.val
		IMPORT_TEX = IMPORT_TEX.val
		IMPORT_TEX_TYPE = IMPORT_TEX_TYPE.val
		
		Blender.Window.WaitCursor(1)
		load_hsc(filepath)
		Blender.Window.WaitCursor(0)
	
def load_hsc(sHSC):
	def __addImages__(imageFileList):
		for image in imageFileList:	
			tex = os.path.join(pathDir, image)
			try:		image = Image.Get(tex)
			except:	image = Image.Load(tex)
	global	IMPORT_HIER, IMPORT_HIER_NAVL, IMPORT_HIER_SHAPE, IMPORT_HIER_SIZE,\
					IMPORT_MRKR,\
					IMPORT_DOCK, IMPORT_DOCK_REFCURVE, IMPORT_DOCK_KEYFRAMES,\
					IMPORT_MAKEGROUPS,\
					IMPORT_COLOR_MESH_MAT,\
					IMPORT_OBJTGA, IMPORT_OBJ, IMPORT_OBJ_MENU, IMPORT_TEX, IMPORT_TEX_TYPE,\
					IMPORT_ROTX90,\
					grpHIER, grpWEAP, grpHARD, grpCP, grpRP, grpNAVL,\
					grpMRKR, grpDOCK
	with open(sHSC) as fHSC:
		pathDir = os.path.dirname(sHSC)
		# Create some counter variables for the iterator's (the <for> and <while> loops) carry-over information
		nodex = cu_n = 0
		
		pathData = [] # Setup a bin for dockpath data
		jointData = []
		counter.materials = counter.joints = counter.markers = counter.paths = counter.skipped = 0
		meshes = []
		images = []
			
		for f in os.listdir(pathDir):
			if		IMPORT_TEX_TYPE == 1 and f.lower().endswith('.dds'):						images.append(f)
			elif	IMPORT_TEX_TYPE == 2 and f.lower().endswith('.tga'):						images.append(f)
			elif	IMPORT_TEX_TYPE == 3 and f.lower().endswith(('.dds','.tga')):		images.append(f)
			if IMPORT_OBJ and f.lower().endswith('.obj'):													meshes.append(f)
		if IMPORT_TEX:	__addImages__(images)
		if IMPORT_OBJ:
			if IMPORT_OBJ_MENU:
				for obj in meshes:
					meshFile = os.path.join(pathDir,obj)
					try: 		import_obj.load_obj_ui(meshFile)
					except: print 'There was an error while loading the file',meshFile
			else:
				for obj in meshes:
					meshFile = os.path.join(pathDir,obj)
					try: 								temp = Object.Get(obj[:obj.lower().find('.obj')])
					except ValueError:	import_obj.load_obj(meshFile, 0.0, False, False, False, False, False, False, IMPORT_ROTX90, False, False)
		# Correct Root if Rotate_X90 is True
		if IMPORT_ROTX90:	root.setEuler(0.0,0.0,0.0); Blender.Window.RedrawAll()
		if IMPORT_MAKEGROUPS == True:									# Organizational grouping objects
			try: 		grpHIER = Group.Get('Hierarchy')
			except: grpHIER = Group.New('Hierarchy')
			
			try: 		grpWEAP = Group.Get('Weapons')
			except: grpWEAP = Group.New('Weapons')
			try: 		grpHARD = Group.Get('Hardpoints')
			except: grpHARD = Group.New('Hardpoints')
			try: 		grpCP = Group.Get('Capture Pts')
			except: grpCP = Group.New('Capture Pts')
			try: 		grpRP = Group.Get('Repair Pts')
			except: grpRP = Group.New('Repair Pts')
			
			try: 		grpNAVL = Group.Get('NavLights')
			except: grpNAVL = Group.New('NavLights')
			try: 		grpMRKR = Group.Get('Markers')
			except: grpMRKR = Group.New('Markers')
			try: 		grpDOCK = Group.Get('Dockpaths')
			except: grpDOCK = Group.New('Dockpaths')
		

		# These will contain the lines (from fHSC) for a given category
		HIER = []
		NAVL = []
		MRKR = []
		DOCK = []
		
		time = sys.time()
		
		for line in fHSC:			# Sort lines according to contents
			# if line == '/n':
				# counter.skipped += 1
				# continue
			if line.find("""//""") != -1:								# Skip over comment lines
				continue
			# Sort lines from file;
			if line.find('HIER') != -1:		HIER.append(line)
			elif line.find('NAVL') != -1: NAVL.append(line)
			elif line.find('MRKR') != -1:	MRKR.append(line)
			elif line.find('DOCK') != -1:	DOCK.append(line)

		# Now that the lines have been sorted....we can start making stuff:
		# JOINTS
		if IMPORT_HIER != 0:
			for line in HIER:
				appendJointData(line,jointData)
				counter.joints += 1
			
			levelList = sortJoints(jointData,IMPORT_HIER_SIZE)
			# Time to start making joints.
			nList = len(levelList)-1
			l = nList
			while l > 0:
				List = levelList[l]
				for entry in List:
					joint = getJoint(jointData, entry.name)
					empty = makeJoint(joint)
					
					children = []
					try:		children = getJointChildren(levelList[l+1], empty.name)
					except 	IndexError:	pass
					if len(children) > 0:
						c = []
						for child in children:
							try:		c.append(Object.Get(child))
							except:	pass
						if len(c) > 0:
							try:		empty.makeParent(c)
							except:	pass #print "There was an error setting the parent for",empty.name
					loc = joint.loc
					euler = joint.rot
					empty.setLocation(loc)
					empty.setEuler(euler)
					
					try:		scn.objects.link(empty)
					except RuntimeError: pass
					
					if IMPORT_MAKEGROUPS == True: 
						grpHIER.objects.link(empty)
						if 'WP' in empty.name[0:3]: grpWEAP.objects.link(empty)
						elif 'CP' in empty.name[0:3]: grpCP.objects.link(empty)
						elif 'RP' in empty.name[0:3]: grpRP.objects.link(empty)
						elif 'HP' in empty.name[0:3]: grpHARD.objects.link(empty)
				l -= 1
			ob = []
			if len(levelList) > 1:
				for entry in levelList[1]:
					try:
						ob.append(Object.Get(entry.name))
					except ValueError:
						ob.append(Object.Get('ME'+entry.name))
				try: root.makeParent(ob)
				except RuntimeError:
					print ob
			if IMPORT_HIER_NAVL:
				for line in NAVL: 			# NAVLIGHTS
					#print line
					ob = makeNavLight(line)
					try:	scn.link(ob)
					except:	pass
					if IMPORT_MAKEGROUPS == True:	grpNAVL.objects.link(ob)
				
		# MARKERS
		if IMPORT_MRKR != 0:
			for line in MRKR:
				empty = makeMarker(line)
				sca = Root.size[0]*0.05
				empty.size = sca,sca,sca
				try:		scn.link(empty)
				except:	pass
				counter.markers += 1
				if IMPORT_MAKEGROUPS == True:	# Add to organizational group
					grpMRKR.objects.link(empty)
					
		# DOCKPATHS
		if IMPORT_DOCK != 0:	
			# Create dockpath database
			pathData = make_pathData(DOCK)# Create a new group to contain all the upcoming empties
			
			for path in pathData:
				#	Create Organizational group
				try: 		grp = Group.Get(path.name)
				except: grp = Group.New(path.name)
				
				pathObjList = makeDockpath(path)
				counter.paths += 1
				root.makeParent(pathObjList)
				if IMPORT_MAKEGROUPS:
					for obj in pathObjList:
						grp.objects.link(obj)
					
		print "Processed %i materials, %i joints, %i markers and %i dockpaths in %.2f seconds" %(counter.materials, len(jointData), counter.markers, counter.paths, sys.time()-time)
		# scn.update()
		# Make sure all objects are deselected
		for obj in scn.objects:
			obj.sel = False
if __name__ == '__main__':
	if radians and pi and re:	Blender.Window.FileSelector(load_obj_ui, 'Import HOD Script', '*.hsc')
	else:											Blender.Draw.PupMenu("Error%t|This script requires a full Python installation")
	