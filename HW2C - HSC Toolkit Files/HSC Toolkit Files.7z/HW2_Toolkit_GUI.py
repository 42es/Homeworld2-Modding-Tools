#!BPY
"""
Name: 'HOD Toolbox'
Blender: 249
Group: 'Object'
Tooltip: 'Toolbox for HW2 ship editing'
"""

__author__ = "'Sagyxil' Stott"
__email__ = ['Sagyxil, sagyxilwoodshadow:hotmail*com']
__version__ = "0.95"

__bpydoc__ = """\
This serves as the main editor for ships made in Blender

Usage:
This script will allow you to add joints, navLights, markers and
dockpaths for HW2-style ships; to be exported to script for
importing into CFHod.
"""

# If possible, set the "tabs" to 2 spaces for ideal viewing of this script.

# Still to do
# - Create a way to delete nodes in a dockpath (will have to redo the animation though...)
# - Allow user to manipulate layout of toolbox - mainly, moving options around like in the button window.

import Blender
from Blender.BGL import *
from Blender import Draw, Mathutils, Window, Object, Lamp, Scene, sys
from Blender.Mathutils import *

import string
from string import Template

import math
from math import radians

import decimal
from decimal import *

import re
from re import *

try: 		import export_obj
except: export_obj = None

try:		import meshcolorizer
except:	meshcolorizer = None

try: 		import HSCImport
except SyntaxError: 
	print "There was a syntax error in HSCImport.py"
	print "Line:",		SyntaxError.lineno
	print "Offset:",	SyntaxError.offset
	print "text:",		SyntaxError.text
	HSCImport = None
except:
	print "Couldn't load HSCImport.py...continuing anyway..."
	HSCImport = None

try: 		import EXPORT_HSC
except:
	EXPORT_HSC = None
	print "Couldn't find EXPORT_HSC.PY...continuing anyway..."

try:	root = Object.Get('Root')
except:	
	# Blender.Draw.PupMenu("Note%t|No joint named 'Root' in scene! Creating...")
	root = Scene.GetCurrent().objects.new('Empty')
	root.emptyShape = 3
	root.size = 100.0,100.0,100.0
	root.drawSize = 0.01
	root.setEuler(0,0,0)
	root.setName('Root')
	
# import warnings # Didn't do sh-%U*)#-t

# print "Blatherinblatherskyt! And a turnip."

pyLIVE = [\
	'# LIVE Path Updater text\n',\
	'# AUTO Written by HOD Toolkit\n',\
	'# Currently only works on one node at a time.\n',\
	'import Blender\n',\
	'from Blender import *\n\n',\

	'sel = Object.GetSelected()\n',\
	'if sel:\n',\
	'	sel = sel[0]\n',\
	"	# NODES\n",\
	"	if sel.type == 'Empty' and '_key' in sel.name:\n",\
	"		break = sel.name.index('_key')+4\n",\
	'		index = int(sel.name[:break])-1\n',\
	'		basename = sel.name[:break-4]\n',\
	'		dummy = Object.Get(basename)\n',\
	'		try: REFcurve = Object.Get(basename+"REFCURVE")\n',\
	'		except: REFcurve = None\n\n',\
	
	'		ipo = dummy.getIpo()\n',\
	'		keyframe = ipo[Ipo.OB_LOCX].bezierPoints[index].pt[0]\n',\
	'		LX, LY, LZ = ipo[Ipo.OB_LOCX], ipo[Ipo.OB_LOCY], ipo[Ipo.OB_LOCZ]\n',\
	'		LX.bezierPoints[index].pt = keyframe, sel.loc.x; LX.recalc();\n',\
	'		LY.bezierPoints[index].pt = keyframe, sel.loc.y; LY.recalc();\n',\
	'		LZ.bezierPoints[index].pt = keyframe, sel.loc.z; LZ.recalc();\n',\
	'		RX, RY, RZ = ipo[Ipo.OB_ROTX], ipo[Ipo.OB_ROTY], ipo[Ipo.OB_ROTZ]\n',\
	'		RX.bezierPoints[index].pt = keyframe, 0.1*math.degrees(sel.rot.x); RX.recalc();\n',\
	'		RY.bezierPoints[index].pt = keyframe, 0.1*math.degrees(sel.rot.y); RY.recalc();\n',\
	'		RZ.bezierPoints[index].pt = keyframe, 0.1*math.degrees(sel.rot.z); RZ.recalc();\n\n',\
	
	'		if REFCURVE:\n',\
	'			curve = REFcurve[0]\n',\
	'			bz = BezTriple.New([sel.loc.x,sel.loc.y,sel.loc.z])\n',\
	'			bz.handleTypes = [BezTriple.HandleTypes.AUTO, BezTriple.HandleTypes.AUTO]\n',\
	'			curve[index] = bz\n',\
	"	# REFCURVE\n",\
	"	elif sel.type == 'Curve':\n",\
	"		sel = sel[0]\n",\
	"		break = sel.name.lower().index('refcurve')\n",\
	"		basename = sel.name[:break]\n",\
	"		indices = []\n",\
	"		for point in sel[0]:\n",\
	"			if point.selects:\n",\
	"				indices.append(sel[0].index(point))\n\n",\
	
	'		nodes = [Object.Get(basename+"_key"+str(index)) for index in indices]\n',\
	'		n = 0\n',\
	'		for node in nodes:\n',\
	'			index = indices[n]\n',\
	'			pt = sel[index].vec[1]\n',\
	'			node.loc = BezTriple.New([ pt[0], pt[1], pt[2] ])\n\n',\
	
	'		ipo = Object.Get(basename)\n',\
	'		\n',\
	"		"
	]
pyPOSTEDIT = [\
	'# LIVE Path Updater text\n',\
	'# AUTO Written by HOD Toolkit\n',\
	'# Currently only works on one node at a time.\n',\
	'import Blender\n',\
	'from Blender import *\n',\

	'sel = Object.GetSelected()\n',\
	'if sel:\n',\
	'	if Window.EditMode():\n',\
	'		sel = sel[0]\n',\
	"		if sel.type == 'Empty' and '_key' in sel.name:\n",\
	"			break = sel.name.index('_key')+4\n",\
	'			index = int(sel.name[:break])-1\n',\
	'			basename = sel.name[:break-4]\n',\
	'			dummy = Object.Get(basename)\n',\
	'			try: REFcurve = Object.Get(basename+"REFCURVE")\n',\
	'			except: REFcurve = None\n\n',\
	'			ipo = dummy.getIpo()\n',\
	'			keyframe = ipo[Ipo.OB_LOCX].bezierPoints[index].pt[0]\n',\
	'			LX, LY, LZ = ipo[Ipo.OB_LOCX], ipo[Ipo.OB_LOCY], ipo[Ipo.OB_LOCZ]\n',\
	'			LX.bezierPoints[index].pt = keyframe, sel.loc.x; LX.recalc();\n',\
	'			LY.bezierPoints[index].pt = keyframe, sel.loc.y; LY.recalc();\n',\
	'			LZ.bezierPoints[index].pt = keyframe, sel.loc.z; LZ.recalc();\n',\
	'			RX, RY, RZ = ipo[Ipo.OB_ROTX], ipo[Ipo.OB_ROTY], ipo[Ipo.OB_ROTZ]\n',\
	'			RX.bezierPoints[index].pt = keyframe, 0.1*math.degrees(sel.rot.x); RX.recalc();\n',\
	'			RY.bezierPoints[index].pt = keyframe, 0.1*math.degrees(sel.rot.y); RY.recalc();\n',\
	'			RZ.bezierPoints[index].pt = keyframe, 0.1*math.degrees(sel.rot.z); RZ.recalc();\n\n',\
	'			if REFCURVE:\n',\
	'				curve = REFcurve[0]\n',\
	'				bz = BezTriple.New([sel.loc.x,sel.loc.y,sel.loc.z])\n',\
	'				bz.handleTypes = [BezTriple.HandleTypes.AUTO, BezTriple.HandleTypes.AUTO]\n',\
	'				curve[index] = bz\n',\
	"		elif sel.type == 'Curve':\n",\
	"			sel = sel[0]\n",\
	"			break = sel.name.lower().index('refcurve')\n",\
	"			basename = sel.name[:break]\n",\
	"			indices = []\n",\
	"			for point in sel[0]:\n",\
	"				if point.selects:\n",\
	"					indices.append(sel[0].index(point))\n\n",\
	'			nodes = [Object.Get(basename+"_key"+str(index)) for index in indices]\n',\
	'			n = 0\n',\
	'			for node in nodes:\n',\
	'				index = indices[n]\n',\
	'				pt = sel[index].vec[1]\n',\
	'				node.loc = BezTriple.New([ pt[0], pt[1], pt[2] ])\n\n',\
	'			ipo = Object.Get(basename)'
	]
	
# Redraw wrappers
def redraw3D(): 			Blender.Window.Redraw(Blender.Window.Types.VIEW3D)
def redrawOOPS():			Blender.Window.Redraw(Blender.Window.Types.OOPS)
def redrawIPO():			Blender.Window.Redraw(Blender.Window.Types.IPO)
def redrawBUTS():			Blender.Window.Redraw(Blender.Window.Types.BUTS)
def redrawSCRIPTS():	Blender.Window.Redraw(Blender.Window.Types.SCRIPT)
DEBUG = []
if 'start' in DEBUG: print "Debugging Start>===================================================|"
class HSCDraw: # [ Not Implemented ]
	def JointMn(x=0, y=0, actObj=None):
		'''Joint menu'''
		pass
		
	def NavMn(x=0, y=0, actObj=None):
		'''NavLight menu'''
		pass

	def MarkerMn(x=0, y=0, actObj=None):
		'''Marker menu'''
		pass

	def DockMn(x=0, y=0, actObj=None):
		'''Dock menu'''
		pass
	
	def StatusDisplay(x=0, y=0, actObj=None):
		'''Info about current object'''
		pass
	class PopUp:
		def nameChangeConfirm():
			yn = Blender.Draw.PupMenu("Do you wish to change this object's name?%t|Yes%x1|No%x2")
			return yn
		
def getSafeProperty(obj, propertyName):
	if obj:
		try:		result = obj.getProperty(propertyName)
		except RuntimeError:	result = None
	else:
		result = None
		if 'getProp' in DEBUG: print obj,"wasn't a valid property holder..."
	return result

if True:				# list of Event numbers
	# EVENT CONSTANTS
	EVENT_NONE 		= 1000
	EVENT_DRAW 		= 1001
	EVENT_BUDGET	= 1002
	
	EVENT_JOINT 	= 1010
	EVENT_J_NAME 	= 1015

	EVENT_R_SIZE	= 500 # ROOT resize
	EVENT_R_XRAY 	= 510

	EVENT_HSC_IMPORT 	= 600
	EVENT_HSC_EXPORT 	= 610

	EVENT_MESH_COLOR 	= 700
	EVENT_MESH_EXPORT = 710

	EVENT_NAVL 		= 1020
	EVENT_N_NAME 	= 1021
	EVENT_N_PHASE = 1022
	EVENT_N_FREQ	= 1022
	EVENT_N_SIZE 	= 1023
	EVENT_N_COLOR = 1025
	EVENT_N_VIS 	= 1026
	EVENT_N_LIT 	= 1027

	EVENT_MRKR 		= 1030
	EVENT_M_NAME	= 1032

	EVENT_DOCK 			= 1040
	EVENT_D_NAME		= 1041
	EVENT_D_NODE		= 1042
	
	EVENT_D_UPDATE_FROMNODE 	= 1043
	
	
	EVENT_D_UPDATE_FROMCURVE 	= 1046
	EVENT_D_SHOWFRAMES 	= 1047
	EVENT_D_FRAMEOFFSET = 1048
	EVENT_D_UPDATE_FROMIPO		= 1049
	EVENT_D_UPDATEANIM	= 1050
	
	EVENT_GENERATE_GROUPS	= 2000
	
	
	EVENT_D_D_FLAGS = 3040
	EVENT_D_D_EXIT	= 3041
	EVENT_D_D_LATCH	= 3042
	EVENT_D_D_UDA		= 3043
	# EVENT_D_D_FAMILIES 						= 3044
	EVENT_D_D_LINKED	 						= 3045
	EVENT_D_D_LINKSELECTED2ACTIVE = 3046
	
	EVENT_D_D_FAMILY_ADD					= 44
	EVENT_D_D_FAMILY_UPDATE				= 5400 	# The index of the entry in question should be added to this value to determine which entry will be deleted.
	EVENT_D_D_FAMILY_UPDATE_RNG		= range(EVENT_D_D_FAMILY_UPDATE, EVENT_D_D_FAMILY_UPDATE+200)
	EVENT_D_D_FAMILY_DELETE				= 4400	# Again, the index of the entry in question should be added to this value to determine which entry will be deleted.
	EVENT_D_D_FAMILY_DELETE_RNG		= range(EVENT_D_D_FAMILY_DELETE, EVENT_D_D_FAMILY_DELETE+200) 	
	
	# None of these should have a value of 4401 to 4599 (that's about 200 possible lines, with 31 characters each, for dock family listings.)
	EVENT_D_SPHEREFLAGS = 4040
	EVENT_D_N_USEROT		= 4041
	EVENT_D_N_CHKROT		= 4042
	EVENT_D_N_FCB				= 4043
	EVENT_D_N_UCP				= 4044
	EVENT_D_N_PIC				= 4045
	EVENT_D_N_DROPFOCUS = 4046
	EVENT_D_N_ORIGIN		= 4047
	EVENT_D_N_ADVQ			=	4048
	EVENT_D_N_POINTTOL	= 4049
	EVENT_D_N_MAXSPEED	= 4050
	
	EVENT_D_D_LINK_ADD					= 64
	EVENT_D_D_LINK_UPDATE				= 7400		# The index of the entry in question should be added to this value to determine which entry will be deleted.
	EVENT_D_D_LINK_UPDATE_RNG		= range(EVENT_D_D_LINK_UPDATE, EVENT_D_D_LINK_UPDATE+200)
	EVENT_D_D_LINK_DELETE				= 6400
	EVENT_D_D_LINK_DELETE_RNG		= range(EVENT_D_D_LINK_DELETE, EVENT_D_D_LINK_DELETE+200)
		
	EVENT_D_UPDATE = [EVENT_NONE, EVENT_D_UPDATE_FROMNODE, EVENT_D_UPDATE_FROMCURVE, EVENT_D_UPDATE_FROMIPO]
	
def __LocBox__(x, y):
	# Simple GUI troubleshooting tool
	glColor3f(0,0,0)
	glRecti(x-1, 0, x+1, Window.GetAreaSize()[1])
	glColor3f(1,1,1)
	glRecti(0, y-1, Window.GetAreaSize()[0], y+1)
def __HeightBox__(height, x=0, y=0):
	box_y = 0
	while box_y < height:
		glColor3f(1.0, 1.0, 1.0)
		if box_y % 2 == 0:	# Even y
			glRecti(x, box_y, x+1, box_y+1)
		else:								# Odd y
			glRecti(x-1, box_y, x, box_y+1)
		box_y += 1
def __getName__():
	# This doesn't require any arguments simply because it accesses the global variables associated with the name's creation.
	'''
	Determines the name based on selections in menu; returns a list of 3 strings:
	1 - HW2 Name     - name that will be used by the Homeworld 2 engine
	2 - Base Name    - this is the HW2 Name sans prefixes or suffixes
	3 - Blender Name - name of joint in Blender (abbreviated/truncated to 21 characters)
	'''
	def __abbrev__(str):
		Kccc	= r'''(?:(?P<K>[A-Z]) | (?P<c>[bcdfghjklmnpqrstvwxyz]) | (?P<n>[0-9]))'''
		abbrev = ''
		match = re.findall(Kccc,str, re.VERBOSE)
		
		abbrev = ''
		matches = 0
		
		if match:
			matches = len(match)
			for group in match:
				c1, c2, c3 = group
				if c1: abbrev = abbrev+c1
				if c2: abbrev = abbrev+c2
				if c3: abbrev = abbrev+c3
		if 'name' in DEBUG: 
			print "Found",matches,"matches"
			print "Yield=>",abbrev			
		
		return abbrev
		
	global JOINT_TYPE, JOINT_SUB, JOINT_NAME, JOINT_POS, JOINT_SLAVE, JOINT_SINDEX, JOINT_INDEX
	
	TYPE = ['Weapon', 'HardPoint', 'RepairPoint', 'CapturePoint', '']								;		TYPE_SHORT = ['WP', 'HP', 'RP', 'CP', ''];
	SUBTYPE = ['Generic', 'Production', 'Sensor', 'System', 'Engine', 'Resource']		;		SUBTYPE_SHORT = ['Gen', 'Prd', 'Sen', 'Sys', 'Eng', 'Res'];
	POSITION_SHORT = ['$P', '$L', '$M','']																					;		POSITION = ['Position', 'Latitude', 'Muzzle',''];
	
	#if not actObj: # No selection to decipher
	baseName = JOINT_NAME.val
	
	t0 = TYPE[JOINT_TYPE.val]
	t = TYPE_SHORT[JOINT_TYPE.val]
	
	s0 = SUBTYPE[JOINT_SUB.val]
	s = SUBTYPE_SHORT[JOINT_SUB.val]
	
	p0 = POSITION[JOINT_POS.val]
	p	= POSITION_SHORT[JOINT_POS.val]
	
	i = JOINT_INDEX.val
	
	if i < 0: i = ''
	
	sl = sl0 = ''
	
	
	# Set suffix for slave index 
	if JOINT_SINDEX.val > 0:
			sI = str(JOINT_SINDEX.val)
	else:	sI = ''
	# Set slave suffix
	if JOINT_SLAVE.val:
		sl = '$SL'+sI
		sl0 = 'Slave'+sI
	
	if JOINT_TYPE.val == 1: 			# HARDPOINT
		# Template
		temp = Template('$type$_1$subtype$index1$_2$position')
		# Set entries in nameSeq
		HW2Name = temp.substitute(type = t0,_1 = '_',subtype = s0,index1 = i,_2 = '_',position = p0)
		baseName = ''
		blendName =	temp.substitute(type = t,_1 = '_',subtype = s,index1 = i,_2 = '_',position = p)
		
	elif JOINT_TYPE.val in [2,3]: # CAPTURE/REPAIR POINT
		# Template
		temp = Template('$type$index1')
		# Set entries in nameSeq
		HW2Name = temp.substitute(type=t0, index1=i)
		baseName = ''
		blendName = temp.substitute(type=t, index1=i)
		
	elif JOINT_TYPE.val == 4: 		# CUSTOM
		# Template
		temp = Template('$name$index1$slave$_1$position')
		if p == '': s_1 = ''
		else:				s_1 = '_'
		# Set entries in nameSeq
		HW2Name = temp.substitute(	name=baseName,	index1=i,	slave=sl0,	_1=s_1, position=p0)
		qual = temp.substitute(			name='',				index1=i,	slave=sl,		_1=s_1,	position=p) # just joint Qualifiers
		# Check to see if sum of [the length of the qualifiers (joint type, joint position)] and [the length of the baseName] will be within 21 character limit
		lenQual = len(qual)
		if JOINT_SLAVE.val:	pass
		else:								lenQual += 3 # to allow name for slaves to match up
		available = 21-lenQual
		if len(baseName) > available:
			abbrev = __abbrev__(baseName)
			if len(abbrev) > available: abbrev = abbrev[:available-1]
		else:
			abbrev = baseName
			baseName = ''
		blendName = temp.substitute(	name=abbrev,		index1=i, slave=sl, 	_1=s_1, position=p)
	else:													# WEAPON
		temp = Template('$type$_1$index1$name$slave$_2$position')
		HW2Name =	temp.substitute(	type=t0,	_1='_',	name=baseName,	index1=i,	slave=sl0,	_2='_',	position=p0)
		qual =		temp.substitute(	type=t,		_1='_',	name='',				index1=i,	slave=sl,		_2='_',	position=p) # just joint Qualifiers
		# Determine if there is a need to abbreviate the baseName
		lenQual = len(qual)
		if JOINT_SLAVE.val:	pass
		else:								lenQual += 3 # to allow name for slaves to match up
		available = 21-lenQual
		if len(baseName) > available:
			abbrev = __abbrev__(baseName)
			if len(abbrev) > available: abbrev = abbrev[:available-1]
		else:
			abbrev = baseName
			baseName = ''
		blendName =	temp.substitute(	type=t,		_1='_', name=abbrev,		index1=i,	slave=sl,		_2='_', position=p)
	#print "nameSeq: ",blendName, HW2Name, baseName
	return [HW2Name, baseName, blendName]
	
def __breakName__(obj=None, name=''):				# [ Not Tested ]
	'''Break a name into component parts'''
	if obj:
		name = obj.name
		try: 		fullname = obj.getProperty('fullName').data
		except:	fullname = None
	else:			fullname = None
	if name.startswith('RP') or name.startswith('RepairPoint'): 		return 2, int(name[2:]),'', False, 0, -1, -1
	elif name.startswith('CP') or name.startswith('CapturePoint'): 	return 3, int(name[2:]),'', False, 0, -1, -1
	
	patternWP = r'''
		(?:WP
			[_]?
			(?P<index>[0-9]*?)
			[_]?
			(?P<name>[a-zA-Z]+[0-9]*[a-zA-Z]*)
			(?:
				(?P<slave>\$SL)
				(?P<slaDex>\d*)
			)?
			[_]?
			(?P<subtype> 
				\$
					(?: P | La | M )
			)
		)'''
	patternHP = r'''
		(?:HP
			[_]?
			(?P<index>[0-9]+)?
			[_]?
			(?P<subsys>Gen | Prd | Sen | Sys | Eng | Res)
			(?P<index2>[0-9]+)?
			[_]?
			(?P<subtype> \$(?: P | La | M ))
		)'''
	patternCUST = r'''
		(?:
			(?P<name>[a-zA-Z]*[0-9]*?[a-zA-Z]*)
			(?P<index>[0-9]+)?
			(?:
				(?P<slave>\$SL | Slave)
				(?P<slaDex>[0-9]+)?
			)?
			[_]?
			(?P<subtype> \$(?: P | La | M))
		)'''
	WP = re.search(patternWP, name, re.VERBOSE)
	HP = re.search(patternHP, name, re.VERBOSE)
	CUST = re.search(patternCUST, name, re.VERBOSE)
	
	SUBSYS = ['Gen', 'Prd', 'Sen', 'Sys', 'Eng', 'Res']
	SUBTYPE = ['$P', '$La', '$M']
	
	if WP:
		index = WP.group('index')
		if not index:	index = -1
		else:		index = int(index)
		
		if fullname: name = fullname
		else:
			name = WP.group('name')
			if not name:	name = ''
								
		subtype = WP.group('subtype')
		if not subtype:	subtype = -1
		else:						subtype = SUBTYPE.index(subtype)
		
		slave = WP.group('slave')
		if not slave:	slave = False
		else:					slave = True
		
		slaDex	= WP.group('slaDex')
		if not slaDex:	slaDex = 0
		else:						slaDex = int(slaDex)
		
		return 0, index, name, slave, slaDex, -1, subtype
		
	elif HP:
		index = HP.group('index')
		if not index: index = -1
		else:					index = int(index)
		
		index2 = HP.group('index2')
		if index2: index = int(index2)
		
		subsys = HP.group('subsys')
		if not subsys:	subsys = -1
		else:						subsys = SUBSYS.index(subsys)
		
		subtype = HP.group('subtype')
		if not subtype: subtype = -1
		else:						subtype = SUBTYPE.index(subtype)
		
		return 1, index, '', False, 0, subsys, subtype
		
	elif CUST:
		name 	= CUST.group('name')
		
		index = CUST.group('index')
		if not index:	index = -1
		else:					index = int(index)
		
		slave = CUST.group('slave')
		if not slave:	slave = False
		else:					slave = True
		
		slaDex = CUST.group('slaDex')
		if not slaDex:	slaDex = -1
		else:						slaDex = int(slaDex)
		
		subtype = CUST.group('subtype')
		if not subtype:	subtype = -1
		else:						subtype = SUBTYPE.index(subtype)
		return 4, index, name, slave, slaDex, -1, subtype
	elif name.lower().startswith('enginenozzle'):
		if name[12:] != '':	index = int(name[12:])
		else:								index = -1
		return 4, index, 'EngineNozzle', False, 0, -1, 3
	else:
		if obj:	name = obj.name
		print "Couldn't decipher the name",name
		return 4,-1,name, False, 0, -1, -1
		

def __getSubPathType(obj):
	DOCK_NODE, DOCK_CURVE, DOCK_DUMMY = 1, 2, 3
	sub = -1
	if obj:
		if obj.name.startswith('path'):
			if obj.name.find('_key') != -1:	sub = DOCK_NODE
			elif obj.type == 'Curve': 			sub = DOCK_CURV
			else: 													sub = DOCK_DUMMY
			return True, sub
	return False, sub
def ui_ev(evt, val):
	'''Handles keyboard/mouse input events'''
	sel = Object.GetSelected()
	if sel:		actObj = sel[0]
	else:			actObj = None
	global bDon_TReHide
	if val:
		if bDon_TReHide:	bDon_TReHide = False
	if 		Window.GetKeyQualifiers() == Window.Qual.SHIFT and evt == Draw.ESCKEY or\
				Window.GetKeyQualifiers() == Window.Qual.SHIFT and evt == Draw.QKEY:
		CANCELEXIT = Blender.Draw.PupMenu("Exit?%t|YES%x0|NO%x1")
		if not CANCELEXIT:
			if 'end' in DEBUG: print "|====================================================<Debugging End"
			Draw.Exit()
			return
		else:	pass
	elif	Window.GetKeyQualifiers() == Window.Qual.SHIFT and evt == Draw.JKEY and not bDon_TReHide:
		global SHOW_JOINT
		SHOW_JOINT.val = not SHOW_JOINT.val
		redrawSCRIPTS()
		bDon_TReHide = True
	elif	Window.GetKeyQualifiers() == Window.Qual.SHIFT and evt == Draw.MKEY and not bDon_TReHide:
		global SHOW_MRKR
		SHOW_MRKR.val = not SHOW_MRKR.val
		redrawSCRIPTS()
		bDon_TReHide = True
	elif	Window.GetKeyQualifiers() == Window.Qual.SHIFT and evt == Draw.NKEY and not bDon_TReHide:
		global SHOW_NAV
		SHOW_NAV.val = not SHOW_NAV.val
		redrawSCRIPTS()
		bDon_TReHide = True
	elif	Window.GetKeyQualifiers() == Window.Qual.SHIFT and evt == Draw.DKEY and not bDon_TReHide:
		global SHOW_DOCK
		SHOW_DOCK.val = not SHOW_DOCK.val
		redrawSCRIPTS()
		bDon_TReHide = True
	elif	Window.GetKeyQualifiers() == Window.Qual.ALT 	and evt == Draw.LEFTMOUSE and not val: # [ Not Done ]
		global MENU_LOC 
		MOUSE = Blender.Window.GetMouseCoords()
		MENU_LOC = MENU_LOC[0]-MOUSE[0], MENU_LOC[1]-MOUSE[1]
		redrawSCRIPTS()
		# print "Not implented yet..."
	
	elif	Window.GetKeyQualifiers() == Window.Qual.CTRL and evt == Draw.RKEY:
		redrawSCRIPTS()
	else:
		if bDon_TReHide and Window.GetKeyQualifiers() != Window.Qual.SHIFT:	bDon_TReHide = False
	global ROOT_SIZE
	if ROOT_SIZE.val != root.drawSize:
		root.drawSize = ROOT_SIZE.val
		redraw3D()
		redrawBUTS()
	global oldSel
	if actObj != oldSel:	
		redrawSCRIPTS()
		oldSel = actObj

def button_ev(evt, val=0):
	def newJoint(actObj=None):
		global ADD_JOINT, JOINT_TYPE, JOINT_POS, JOINT, JOINT_BLENDNAME, JOINT_BASENAME
		# Empty shapes: ARROWS =  1, AXIS - 2, CIRCLE = 3, ARROW = 4, CUBE = 5, SPHERE = 6, CONE = 7
		SELECTED = Object.GetSelected()
		SHAPE_DIR 		= [5, 5, 7, 7, 5]
		POSITION_MOD	= [0, -3, -1, 0]
		scn = Scene.GetCurrent()
		bExists = False
		try:
			empty = Object.Get(JOINT_BLENDNAME)
			try:	scn.objects.link(empty)
			except: pass
			bExists = True
		except:
			empty = scn.objects.new('Empty')
			#print "		Creating joint",JOINT,"as",JOINT_BLENDNAME
			
		if bExists:
			Blender.Draw.PupMenu("Joint Exists!%t|A joint with that name already exists!")
			return
			
		group = ['Weapons', 'Hardpoints', 'Capture Pts', 'Repair Pts', 'Hierarchy']
		try: 
			HIER = Blender.Group.Get(group[4])
			HIER.objects.link(empty)
		except: print "Hiearchy Group didn't exist"
		try: 
			grp = Blender.Group.Get(group[JOINT_TYPE.val])
			grp.objects.link(empty)
		except: print "BlenderGroup",group[JOINT_TYPE.val],"didn't exist"
		empty.setName(JOINT_BLENDNAME)
		empty.emptyShape = SHAPE_DIR[JOINT_TYPE.val]+POSITION_MOD[JOINT_POS.val]
		
		if len(SELECTED) > 0:
			SELECTED[0].makeParent([empty])
			empty.setLocation(Vector( Window.GetCursorPos() ))
		else:
			root.makeParent([empty])
			empty.setLocation(Vector( Window.GetCursorPos() ))
		#empty.setLocation(Vector( Blender.Window.GetCursorPos() ))
		empty.size = root.size[0]*0.02, root.size[0]*0.02, root.size[0]*0.02
		empty.drawSize = root.drawSize
		try: 
			grp = Blender.Group.Get("Hierarchy")
			grp.link(empty)
		except:
			pass
		if  JOINT_BASENAME: empty.addProperty('fullname', JOINT_BASENAME, 'STRING')
		redraw3D()
		redrawOOPS()
		
	def newNavLight(actObj=None):
		global NAV_NAME, NAV_COLOR, NAV_ALPHA, NAV_VIS, NAV_LIT
		NAME = NAV_NAME.val				
		if NAME[0:2] != 'LA':	NAME = 'LA'+NAME
		#print "Adding Navlight"
		try:
			nav = Object.Get(NAME)
			Blender.Draw.PupMenu('Error%t|NavLight exists already!')
		except:
			pos = Window.GetCursorPos()
			sel = Object.GetSelected()
			
			scn = Scene.GetCurrent()
			bSizerExists = bLampExists = False
			empty = scn.objects.new('Empty')
			
			empty.setName(NAME[2:])
			empty.emptyShape = 6
			empty.setSize(0.1,0.1,0.1)	# Size for navlights is actually 1/10 of the given value
			empty.restrictSelect = True
			
			lamp = scn.objects.new(Lamp.New('Lamp',NAME))
			# Blender.Window.WaitCursor(1)
			lamp.addProperty('Section',				0,		'INT')
			lamp.addProperty('Alpha',					1.0,	'FLOAT')
			lamp.addProperty('Phase',					0.0,	'FLOAT')
			lamp.addProperty('Freq',					0.0,	'FLOAT')
			lamp.addProperty('isVisible',			NAV_VIS.val,		'BOOL')
			lamp.addProperty('isLightSource',	NAV_LIT.val,		'BOOL')
			
			lamp.makeParent([empty])
			lamp.setLocation(pos)
			if sel:
				sel = sel[0]
				sel.makeParent([lamp])
			
			try:	
				grp = Blender.Group.Get('NavLights')
				grp.objects.link(lamp)
				grp.objects.link(empty)
			except:		pass
			redraw3D()
			redrawBUTS()
			redrawOOPS()
		
	def newMarker(actObj=None):
		global MRKR_NAME
		ob = Object.GetSelected()
		scn = Scene.GetCurrent()	
		try:	
			mrkr = Object.Get(MRKR_NAME.val)
			Blender.Draw.PupMenu('Error%t|Marker exists already')
		except:
			mrkr = scn.objects.new('Empty')
		
			mrkr.size = root.size[0]*0.20,root.size[0]*0.20,root.size[0]*0.20
			mrkr.emptyShape = 2
			mrkr.setName(MRKR_NAME.val)
			
			if ob == []:	root.makeParent([mrkr])
			else:					ob[0].makeParent([mrkr])
			pos = Window.GetCursorPos()
			mrkr.setLocation(pos)
			scn.objects.selected = [mrkr]
			scn.objects.active = mrkr
			try: 
				grp = Blender.Group.Get('Markers')
				grp.objects.link(mrkr)
			except:
				pass
			redraw3D()
			redrawBUTS()
			redrawOOPS()
		
	def newDock(actObj=None):
		global	DOCK_NAME, \
						DUMMY_EXIT, DUMMY_LATCH, DUMMY_FAMILIES, DUMMY_USEANIM,\
						NODE_USEROT, NODE_MAXSPEED, NODE_DROPFOCUS, NODE_CHKROT, NODE_FCB, NODE_PIC, NODE_ORIGIN, NODE_UCP, NODE_ADVQ, NODE_POINTTOL
		try:
			dummy = Object.Get(DOCK_NAME.val)
			Blender.Draw.PupMenu('Error%t|Path exists already!')
		except:
			scn = Scene.GetCurrent()
			
			dummy = Object.New('Empty', DOCK_NAME.val)
			dummy.emptyShape = 7
			root.makeParent([dummy])
			dummy.sel = True
			
			dummy.addProperty("isExit", 					DUMMY_EXIT.val,			"BOOL")
			dummy.addProperty("isLatchPath",			DUMMY_LATCH.val,		"BOOL")
			# dummy.addProperty("dockFamilies", 		DUMMY_FAMILIES.val,	"STRING")
			dummy.addProperty("useDockAnimation", DUMMY_UDA.val,	"BOOL")
			# dummy.addProperty("linkedPath1", 			DUMMY_LINKS.val,		"STRING")
			scn.objects.link(dummy)
			dummy.loc = Blender.Window.GetCursorPos()
			
			grp = Blender.Group.New(DOCK_NAME.val)
			grp.objects.link(dummy)
			try:
				ipo = Blender.Ipo.Get(DOCK_NAME.val)
				bIPOEXISTS = True
			except NameError:
				ipo = Blender.Ipo.New('Object', DOCK_NAME.val)
				bIPOEXISTS = False
			dummy.setIpo(ipo)
			
			IPOCurves = ['LocX','LocY','LocZ','RotX','RotY','RotZ']
			if bIPOEXISTS:
				# Clear out the existing data; should an ipo with the name in DOCK_NAME.val exist for some reason.
				try:	ipo[Blender.Ipo.OB_LOCX] = None
				except: pass
				try:	ipo[Blender.Ipo.OB_LOCY] = None
				except: pass
				try:	ipo[Blender.Ipo.OB_LOCZ] = None
				except: pass
				try:	ipo[Blender.Ipo.OB_ROTX] = None
				except: pass
				try:	ipo[Blender.Ipo.OB_ROTY] = None
				except: pass
				try:	ipo[Blender.Ipo.OB_ROTZ] = None
				except: pass
				
			# Adds the requisite IPO values
			for c in IPOCurves:
				try:		temp = ipo.addCurve(c)
				except: pass
			ipo[Blender.Ipo.OB_LOCX].append((1,dummy.loc[0]))
			ipo[Blender.Ipo.OB_LOCY].append((1,dummy.loc[1]))
			ipo[Blender.Ipo.OB_LOCZ].append((1,dummy.loc[2]))
			ipo[Blender.Ipo.OB_ROTX].append((1,0.0))
			ipo[Blender.Ipo.OB_ROTY].append((1,0.0))
			ipo[Blender.Ipo.OB_ROTZ].append((1,0.0))
			
			# First Node
			try: node = Object.Get(DOCK_NAME.val+'_key1')
			except:
				node = Object.New('Empty', DOCK_NAME.val+'_key1')
				grp.objects.link(node)
				scn.objects.link(node)
			node.emptyShape = 6
			node.drawSize = 1
			node.loc = Vector(Blender.Window.GetCursorPos())
			node.size = NODE_POINTTOL.val, NODE_POINTTOL.val, NODE_POINTTOL.val
			
			dummy.makeParent([node])
			node.addProperty("UseRot", 							NODE_USEROT.val,		"BOOL")
			node.addProperty("MaxSpeed",						NODE_MAXSPEED.val,	"FLOAT")
			node.addProperty("DropFocus", 					NODE_DROPFOCUS.val,	"BOOL")
			node.addProperty("checkRotation", 			NODE_CHKROT.val,		"BOOL")
			node.addProperty("forceCloseBehavior",	NODE_FCB.val,				"BOOL")
			node.addProperty("playerInControl", 		NODE_PIC.val,				"BOOL")
			node.addProperty("queueOrigin", 				NODE_ORIGIN.val,		"BOOL")
			node.addProperty("useClipPlane", 				NODE_UCP.val,				"BOOL")
			node.addProperty("advanceQueue", 				NODE_ADVQ.val,			"BOOL")
			
			# curve = Curve.New(DOCK_NAME.val+"REFCURVE")
			# bz = BezTriple.New([Window.GetCursorPos()])
			# bz.handleTypes = [BezTriple.HandleTypes.VECTOR,BezTriple.HandleTypes.VECTOR]
			# curve.appendNurb(bz)
			# Scene.GetCurrent().objects.new(curve)
			# grp.objects.link(curve)
			try:
				DOCK = Blender.Group.Get('Dockpaths')
				DOCK.objects.link(dummy)
				DOCK.objects.link(node)
				DOCK.objects.link(curve)
			except: pass
			
			scn.objects.active = dummy
			scn.objects.selected = [dummy]
			redraw3D()
			redrawOOPS()
			redrawIPO()
		
	def __updateNav(obj, evt):
		def __setKeyframes(obj):
			global NAV_PHASE, NAV_FREQ
			if obj.name.startswith ('LA'): name = obj.name[2:]
			else:	name = obj.name
			bIpoExists = False
			try:		
				IpoOB = Ipo.Get('OB'+name)
				bIpoExists = True
			except:	
				IpoOB = Ipo.New('Object', 'OB'+name)
			parent.setIpo(IpoOB) # Lamp
			ob.setIpo(IpoOB)		 # Empty
			# ANIMATION
			fps = Blender.Scene.GetCurrent().getRenderingContext().fps
			if bIpoExists:
				curveLay = IpoOB[Blender.Ipo.OB_LAYER]
				curveLay.extend = IpoCurve.ExtendTypes.CYCLIC
				curveLay.interpolation = IpoCurve.InterpTypes.CONST
				curveLay.bezierPoints = []
			else:
				curveLay = IpoOB.addCurve('Layer')
				curveLay.extend = IpoCurve.ExtendTypes.CYCLIC
				curveLay.interpolation = IpoCurve.InterpTypes.CONST
			kI = phase*fps
			curveLay.append((kI, 2))
			
			k1 = kI+fps*freq # freq = (k1-kI)/fps
			curveLay.append((k1, 1))
			
			kF = k1+fps*freq
			curveLay.append((kF, 2))
		global NAV_NAME, NAV_COLOR, NAV_ALPHA, NAV_PHASE, NAV_FREQ, NAV_SIZE, NAV_ADD, NAV_VIS, NAV_LIT
		if obj:
			if 		evt == EVENT_N_NAME:
				if obj.name != "LA"+NAV_NAME.val: obj.name = "LA"+NAV_NAME.val
			
			elif	evt == EVENT_N_COLOR:
				obj.R, obj.G, obj.B = NAV_COLOR.val
				try:		alpha = obj.getProperty('Alpha')
				except: 
					obj.addProperty('Alpha', 1.0, 'FLOAT')
					alpha = obj.getProperty('Alpha')
				alpha.data = NAV_ALPHA.val
			# elif	evt == EVENT_N_SECTION:
				# try:		section = obj.getProperty('Section')
				# except: obj.addProperty('Section', 0, 'INT')
			
			elif	evt == EVENT_N_PHASE or evt == EVENT_N_FREQ:
				try:		# PHASE
					phase = obj.getProperty('Phase'); upKEY = True;
				except:	
					obj.addProperty('Phase', 0.0, 'FLOAT')
					phase = obj.getProperty('Phase')
				phase.data = NAV_PHASE.val
				try:	 # FREQ
					freq = obj.getProperty('Freq'); upKEY = True;
				except: 
					obj.addProperty('Freq', 0.0,	'FLOAT')
					freq = obj.getProperty('Freq')
				freq.data = NAV_FREQ.val
				__setKeyframes(obj)
			elif	evt == EVENT_N_VIS:
				global NAV_VIS
				try:
					b = obj.getProperty('isVisible')
					b.data = bool(1-NAV_VIS.val)
				except RuntimeError:	obj.addProperty('isVisible', bool(NAV_VIS.val), 'BOOL')
			elif	evt == EVENT_N_LIT:
				global NAV_LIT
				try:
					b = obj.getProperty('isLightSource')
					b.data = bool(1-NAV_LIT.val)
				except RuntimeError:	obj.addProperty('isVisible', bool(NAV_LIT.val), 'BOOL')
			# elif	evt == EVENT_N_SIZE:
				# global NAV_SIZE
				# sizer = Object.Get(obj.name[2:])
				# sizer.setSize(NAV_SIZE.val, NAV_SIZE.val, NAV_SIZE.val)
		redraw3D()
		redrawOOPS()
		redrawIPO()
		
	def __getDockAnimData(pathname): # [ Not Tested ]
		class DockAnimData:
			def __init__(self, keyframe, node, loc, rot):
				self.keyframe = keyframe
				self.node = node
				self.loc = loc
				self.rot = rot
		# Result list entries should be of the form: 
		# (keyframe, [node, loc, rot]); 
		# i.e., asking for result[0].node would return the object of the point tolerance sphere associated with the first keyframe.
		result = []
		
		bExist = True
		index = 1
		while bExist:
			# Create an empty entry
			entry = DockAnimData(1, None, Vector(0,0,0), Euler(0,0,0))
			try:
				node = Object.Get(pathname+'_key'+str(index))
				# Set node for entry
				entry.node = node
				index += 1
				# Add to results list
				result.append(entry) 
			except:	bExist = False
		# Ipo locations and rotations
		try:
			dummy = Object.Get(pathname)
			ipo = dummy.ipo
			
			# Get location and rotations from keyframes
			ipoX = ipo[Blender.Ipo.OB_LOCX].bezierPoints
			ipoY = ipo[Blender.Ipo.OB_LOCY].bezierPoints
			ipoZ = ipo[Blender.Ipo.OB_LOCZ].bezierPoints
			
			ipoRX = ipo[Blender.Ipo.OB_ROTX].bezierPoints
			ipoRY = ipo[Blender.Ipo.OB_ROTY].bezierPoints
			ipoRZ = ipo[Blender.Ipo.OB_ROTZ].bezierPoints
			
			n = 0
			for point in ipoX:
				result[n].keyframe = point.pt[0]
				result[n].loc = Vector(point.pt[1], 		ipoY[n].pt[1], 	ipoZ[n].pt[1])
				result[n].rot = Vector(ipoRX[n].pt[1], 	ipoRY[n].pt[1],	ipoRZ[n].pt[1])
				n += 1
		except:		pass
		if result == []: 
			raise ValueError, 'the function __getDockAnimData returned an empty list', sys.exc_traceback
		return result
		
	def __updateDockAnim(basename, objToUpdateFrom): # [ Not Done]
		'''This will update the animation curves for dockpaths'''
		# Retrieve dock animation data
		DAD = __getDockAnimData(basename)
		
		if objToUpdateFrom.type != 'Empty':
			raise TypeError, "An invalid object was passed into the __updateDockAnim function"
			
		if objToUpdateFrom.name.find('_key') != -1:
			# Update Animation
			n = 1
			try:
				ipo = Blender.Ipo.Get(basename)
				
				ipoX = ipo[Blender.Ipo.OB_LOCX]
				ipoY = ipo[Blender.Ipo.OB_LOCY]
				ipoZ = ipo[Blender.Ipo.OB_LOCZ]
				ipoRX = ipo[Blender.Ipo.OB_ROTX]
				ipoRY = ipo[Blender.Ipo.OB_ROTY]
				ipoRZ = ipo[Blender.Ipo.OB_ROTZ]
				
			except:
				print "There was an error retrieving the Ipo data for",basename,"...animation update aborted."
				return
			
			if len(DAD) != len(ipoX):
				bTotalRedo = True
			for data in DAD:
				# Things that affect animation:
				# Nodes flags and qualities- 
				# 	Point Tolerance (object scale) = The sphere a ship must pass through before it can proceed to the next node.
				# 	UseRot							= Ships will change their orientation to match the node's while moving towards this node.
				# 	MaxSpeed						=	The maximum speed a ship can travel at while moving to this node; ships will travel at this speed or their own max speed; whichever is lower.
				# 	checkRotation				= Ship will stop and align itself to the node's rotation before proceeding to the next node.
				#		forceCloseBehavior	= Rotation is ignored between nodes (ship will maintain its current rotation while traving to this node)
				# Distance between nodes
				# The best course of action seems to be splitting every waypoint's animation into two parts: the actual movement and the rotation.
				# There will probably need to be some arbitrary rate of rotation to keep everything calculable.
				
				n += 0
		else:
			# Ipo data will determine animation
			pass
		nodes = []
		ipo = Object.Get(basename)
	def countNodes(pathName):
		n = 1
		try:		node = Object.Get( pathName+'_key'+str(n) )
		except:	node = None
		while node:
			node_name = pathName+'_key'+str(n)
			try:		node = Object.Get(node_name); n += 1;
			except:	node = None
		return n
	def getPathNodes(pathname):
		'''Return a list of objects representing the nodes in the path, or an empty list if there was nothing to be found.'''
		n = 1
		result = []
		
		if pathname.lower().find('_key') != -1:					basename = pathname[:pathname.lower().find('_key')]
		elif pathname.lower().find('_refcurve') != -1:	basename = pathname[:pathname.lower().find('_refcurve')]
		else:																						basename = pathname
		try:
			node = Object.Get(basename+'_key'+str(n))
			result.append(node)
		except:	node = None
		
		while node:
			n += 1
			try:
				node = Object.Get(basename+'_key'+str(n))
				result.append(node)
			except:	node = None
			
			
		return result
	def confirmNameChange():
		yn = Blender.Draw.PupMenu("Do you wish to change this object's name?%t|Yes%x1|No%x2")
		return yn
	# The joint related globals
	global ADD_JOINT
	global JOINT, JOINT_BLENDNAME, JOINT_BASENAME
	
	# Mesh-related globals
	global vCOLOR_MESH, vEXPORT_OBJ
	
	# Import/Export globals
	global vIMPORT_HSC, vEXPORT_HSC
	
	# Navlight related globals
	global NAV_ADD, NAV_SIZE
	
	# Marker related globals
	global MRKR_ADD, MRKR_NAME
	
	# Dock related globals
		# Helper displays
	global	DOCK_SHOWFRAMES, DOCK_FRAMEOFFSET
		# Actual settings
	global	DOCK_ADD, DOCK_NAME, DOCK_NODE_ADD_METHOD, NODE_USEROT, NODE_POINTTOL, NODE_DROPFOCUS, NODE_MAXSPEED, NODE_CHKROT, NODE_FCB, \
					NODE_PIC, NODE_ORIGIN, NODE_UCP, NODE_ADVQ, NODE_USEROT, NODE_CHKROT, NODE_FCB, NODE_UCP, NODE_PIC, NODE_DROPFOCUS,\
					NODE_ORIGIN, NODE_ADVQ, NODE_POINTTOL, NODE_MAXSPEED, DUMMY_UDA, DUMMY_LATCH, DUMMY_EXIT
	global XOff, YOff, ZOff
	global families, links
	
	sel = Object.GetSelected()
	if sel: actObj = sel[0]
	else: actObj = None
	
	global oldSel
	
	if actObj != oldSel:	
		redrawSCRIPTS()
		oldSel = actObj
	
	if 		evt == EVENT_JOINT:
		newJoint()
		ADD_JOINT.val = 0
	elif	evt == EVENT_NAVL:
		newNavLight()
		NAV_ADD.val = 0
	elif	evt == EVENT_MRKR:
		newMarker()
		MRKR_ADD.val = 0
	elif	evt == EVENT_DOCK:
		newDock()
	elif	evt == EVENT_MESH_EXPORT:
		vEXPORT_OBJ.val = 0
		Window.FileSelector(export_obj.write_ui, 'Export Wavefront OBJ', Blender.sys.makename(ext='.obj'))
	elif	evt == EVENT_HSC_IMPORT:
		try:		Blender.Window.FileSelector(HSCImport.load_obj_ui, 'Import HOD Script', '*.hsc')
		except:	Blender.Draw.PupMenu("ERROR%t|Couldn't find HSCImport.py")
		vIMPORT_HSC.val = 0
	elif	evt == EVENT_HSC_EXPORT:
		vEXPORT_HSC.val = 0
		Blender.Window.FileSelector(EXPORT_HSC.export_ui, 'Export HOD script', sys.makename(ext='.hsc'))
		# except:
			# Blender.Draw.PupMenu("ERROR%t|Couldn't find EXPORT_HSC.PY")
			# print "ERROR: Was unable to find EXPORT_HSC.PY in either the scripts directory or as Blender Text Object."		
	elif	evt == EVENT_MESH_COLOR:
		vCOLOR_MESH.val = 0
		ALL = Blender.Draw.PupMenu('Do you wish to colorize all meshes?%t|Yes%x1|No%x0')
		scn = Blender.Scene.GetCurrent()
		
		if 		ALL == 1:
			meshList = [ob for ob in scn.objects if ob.type == 'Mesh']
			meshcolorizer.setupMaterials(meshList)
		elif	ALL == 0:
			meshList = [ob for ob in scn.objects.selected if ob.type == 'Mesh']
			meshcolorizer.setupMaterials(meshList)
		elif ALL == -1:		pass
	elif	evt == EVENT_R_SIZE:
		root.drawSize = ROOT_SIZE.val
		redraw3D()
	elif	evt == EVENT_R_XRAY:
		# global ROOT_XRAY
		if ROOT_XRAY.val:
			# DRAWMODE bits:
			# 0 				- Bounds
			#  1 				- Axis
			#   2 			- TexSpace
			#    3			- Name
			# 		4			- ???
			#			 5		- Wire
			#				6		- X-ray
			#				 7	- Transp
			root.drawMode = int(root.drawMode) + 64
		else:
			root.drawMode = int(root.drawMode) - 64
		redraw3D()
	if actObj:
		if		evt == EVENT_D_SHOWFRAMES:
			actObj.enableDupFrames = bool(DOCK_SHOWFRAMES.val)
		elif	evt == EVENT_D_FRAMEOFFSET:
			actObj.DupOff = DOCK_FRAMEOFFSET.val
		elif	evt == EVENT_J_NAME:
			if actObj.name.lower().startswith('path') or actObj.name.lower().startswith('marker'):
				yn = confirmNameChange()
				if yn == 1:
					actObj.name = JOINT_BLENDNAME
					try:
						full = actObj.getProperty('fullName')
						full.data = JOINT_BASENAME
					except: actObj.addProperty('fullName', JOINT_BASENAME, 'STRING')
					redrawBUTS()
				else:
						pass
			else:
				if JOINT and JOINT_BLENDNAME and JOINT_BASENAME:
					actObj.name = JOINT_BLENDNAME
					try:
						full = actObj.getProperty('fullName')
						full.data = JOINT_BASENAME
					except: actObj.addProperty('fullName', JOINT_BASENAME, 'STRING')
			redrawSCRIPTS()
		elif	evt == EVENT_M_NAME:
			if 'marker' in actObj.name:	actObj.name = MRKR_NAME.val
			else:
				yn = confirmNameChange()
				if 		yn == 1:		actObj.name = MRKR_NAME.val
				else:							pass
			redrawBUTS()
		elif	evt == EVENT_D_NAME:
			if actObj.name.lower().startswith('path'):
				KEY = actObj.name.find('_key')
				CUR = actObj.name.find('REFCURVE')
				basename = actObj.name
				if 		KEY != -1: basename = actObj.name[:KEY]; bKEY = True; 	bCUR = False
				elif 	CUR != -1: basename = actObj.name[:CUR]; bKey = False; 	bCUR = True;
				
				grp = dummy = nodes = refCurve = None
				
				try: 		grp = Blender.Blender.Group.Get(basename)
				except: print "Couldn't get/update Blender Group",basename	
				nodes = getPathNodes(basename)
				if len(nodes) > 1: KEY = nodes[0].name.find('_key')
				
				if bCUR: # REFCURVE
					dummy = Object.Get(basename)
				elif bKEY: # NODE
					dummy = Object.Get(basename)
					try: refCurve = Object.Get(basename+"REFCURVE")
					except: pass
				else: # IPO DUMMY
					dummy = actObj
					try: refCurve = Object.Get(basename+"REFCURVE")
					except: pass
				ipo = dummy.getIpo()
				if grp:							grp.name 			= DOCK_NAME.val
				if ipo: 						ipo.name 			= DOCK_NAME.val
				if dummy: 					dummy.name		= DOCK_NAME.val
				if refCurve:				refCurve.name	= DOCK_NAME.val+"REFCURVE"
				if len(nodes) > 0:  [node.setName(DOCK_NAME.val+node.name[KEY:]) for node in nodes]
			else:
				Blender.Draw.PupMenu("Can't do that...selection wasn't a path.")
			
		elif	evt == EVENT_N_SIZE:
			actObj.setSize(NAV_SIZE.val, NAV_SIZE.val, NAV_SIZE.val)
			redraw3D()
		elif	evt in [EVENT_N_NAME, EVENT_N_LIT]:
			if actObj == None:					pass
			elif actObj.type != 'Lamp':	print "You can only change the attributes of Lamps with this."
			else:												__updateNav(actObj, evt)
		# [IPO DUMMY]
		elif	evt == EVENT_D_UPDATE_FROMNODE:		# [ Not Working ]
			n = actObj.name.lower().find('_key')+4
			index = int(actObj.name[n:])-1 					# Determine current nodes index from it's name
			# print index
			basename = actObj.name[:n-4]
			
			ipoDummy = Object.Get(basename)
			ipoCur = ipoDummy.getIpo()
			
			loc = Vector(actObj.loc)
			rot = Euler(actObj.rot)
			
			try: 		curve = Object.Get(basename+"REFCURVE")
			except: curve = None
			
			if ipoCur:
				ipoX	= ipoCur[Blender.Ipo.OB_LOCX].bezierPoints[index]
				ipoY	= ipoCur[Blender.Ipo.OB_LOCY].bezierPoints[index]
				ipoZ	= ipoCur[Blender.Ipo.OB_LOCZ].bezierPoints[index]
				ipoRX = ipoCur[Blender.Ipo.OB_ROTX].bezierPoints[index]
				ipoRY = ipoCur[Blender.Ipo.OB_ROTY].bezierPoints[index]
				ipoRZ = ipoCur[Blender.Ipo.OB_ROTZ].bezierPoints[index]
				# Set the location of the REF curve's node to the same location as the sphere node.
				if curve:
					curve[0][index] = Blender.BezTriple.New(loc)
				
				# Set the pts of the IPO curve's nodes to match the location of the sphere node.
				#if len(ipoX) > 1:
				ipoX 	= Blender.BezTriple.New(ipoX.vec[1][0], loc.x, 0)
				ipoY 	= Blender.BezTriple.New(ipoY.vec[1][0], loc.y, 0)
				ipoZ 	= Blender.BezTriple.New(ipoZ.vec[1][0], loc.z, 0)
				ipoRX = Blender.BezTriple.New(ipoRX.vec[1][0], math.degrees(rot.x)/10, 0)
				ipoRY = Blender.BezTriple.New(ipoRY.vec[1][0], math.degrees(rot.y)/10, 0)
				ipoRZ = Blender.BezTriple.New(ipoRZ.vec[1][0], math.degrees(rot.z)/10, 0)
				if 'ipoUpdate' in DEBUG:
					print ipoX, ipoY, ipoZ
					print ipoRX, ipoRY, ipoRZ
				
				ipoCur[Blender.Ipo.OB_LOCX].recalc()
				ipoCur[Blender.Ipo.OB_LOCY].recalc()
				ipoCur[Blender.Ipo.OB_LOCZ].recalc()
				ipoCur[Blender.Ipo.OB_ROTX].recalc()
				ipoCur[Blender.Ipo.OB_ROTY].recalc()
				ipoCur[Blender.Ipo.OB_ROTZ].recalc()
			else:				Draw.PupMenu("ERROR%t|Unable to update from nodes; couldn't get ipo curve for "+basename)
			if curve:
				cu = curve[0][index]
				cu = BezTriple.New(Vector(loc))
		# [Not Done] [Cancelled]
		# elif	evt == EVENT_D_UPDATE_FROMCURVE:
			# This will require one to find out which nodes are selected in the curve, and then change the corresponding point tolerance spheres accordingly.
			# Selection for control points is found in the BezTriple data for the curve; which can be accessed using the [] operator.
			# i.e,
			# 	c = <some curve object>
			# 	points = [pts for pts in c.data[0]]
			# The select status is a tuple of three booleans
			# However, the selection status doesn't change until one exits Edit mode. This is bad; and proved fatal to this event's objective.
			#	Thus this feature has been CANCELLED.
		elif	evt == EVENT_D_UPDATE_FROMIPO:		# [ Not Done ]
			# Make a list of the nodes in the path.
			nodes = getPathNodes(DOCK_NAME.val)
			# if 'UPDATEIPO' in DEBUG: print nodes
			
			# retrieve IPO data
			try:		obj = Object.Get(DOCK_NAME.val)
			except:	obj = None
			
			if obj:	
				try:		ipo = obj.getIpo()
				except:	ipo = None
				
				if ipo:
					# Need to retrieve locations from Ipo curves; LocX, LocY, LocZ
					locX = [pts.pt[1] for pts in ipo[Blender.Ipo.OB_LOCX].bezierPoints]
					locY = [pts.pt[1] for pts in ipo[Blender.Ipo.OB_LOCY].bezierPoints]
					locZ = [pts.pt[1] for pts in ipo[Blender.Ipo.OB_LOCZ].bezierPoints]
					#if 'UPDATEIPO' in DEBUG: print "X:"
					# Retrieve and convert rotation values (RotX, RotY, RotZ : degrees => radians)
					rotX = [math.radians(pts.pt[1]) for pts in ipo[Blender.Ipo.OB_ROTX].bezierPoints]
					rotY = [math.radians(pts.pt[1]) for pts in ipo[Blender.Ipo.OB_ROTY].bezierPoints]
					rotZ = [math.radians(pts.pt[1]) for pts in ipo[Blender.Ipo.OB_ROTZ].bezierPoints]
					#if 'UPDATEIPO' in DEBUG: print "RX:"
					
					# Apply changes to nodes
					n = 0
					for node in nodes:
						node.loc = Vector(locX[n], locY[n], locZ[n])
						node.rot = Euler( rotX[n], rotY[n], rotZ[n])
						n += 1 
				else:		Draw.PupMenu("Couldn't retrieve animation data from the Ipo curve for "+DOCK_NAME.val)
			else:			Draw.PupMenu("ERROR%t|Couldn't find an object called "+DOCK_NAME.val+"\nUpdate aborted.")
		elif	evt == EVENT_D_NODE:
			# Remove any excess baggage from the dock_name
			basename = DOCK_NAME.val
			if basename.lower().find('_refcurve') != -1:
				basename = basename[:basename.lower().find('_refcurve')]
			elif basename.lower().find('_key') != -1:
				basename = basename[:basename.lower().find('_key')]
				
			# Determine the method for adding nodes
			if 		DOCK_NODE_ADD_METHOD == 1: # Use 3-D marker gizmo
				node_loc = Window.GetCursorPos()
			elif	DOCK_NODE_ADD_METHOD == 2: # Manually-entered offset
				# Create location based on coordinates set in the UI
				curve_cntr = Vector(actObj.loc)
				node_loc = curve_cntr.x+XOff.val,\
										curve_cntr.y+YOff.val,\
										curve_cntr.z+ZOff.val
			else:
				node_loc = Vector(0,0,0)
				Blender.Draw.PupMenu("Error%t|The dock node addition method wasn't set correctly,\nthe node has been placed at the origin (0,0,0).")
			# Set name
			new_node_index = countNodes(basename)
			name = basename+'_key'+str(new_node_index)
			
			POINTTOL = Draw.PupIntInput('Point Tolerance:', NODE_POINTTOL.val, 0, 1000)
			
			if POINTTOL:
				NODE_POINTTOL.val = POINTTOL
				node = Object.New('Empty', name)
				
				node.size = POINTTOL, POINTTOL, POINTTOL
				
				# Set location
				node.loc = Vector(node_loc)
				
				# Set shape
				node.emptyShape = 6
				
				# Attach to scene
				scn = Scene.GetCurrent()
				scn.objects.link(node)
				
				# Add location/rotation to dummy's ipo
				dummy = Object.Get(basename)
				ipo = dummy.getIpo()
				if ipo:
					# Get location of previous node
					try:		
						prevNode = Object.Get(basename+'_key'+str(new_node_index - 1))
						prevLoc = Vector(prevNode.loc)
					except:	prevNode = None
					
					
					# Get distance to previous node
					dist = 0
					if prevNode:	
						dist =	Vector(\
											node.loc[0]-prevLoc[0],\
											node.loc[1]-prevLoc[1],\
											node.loc[2]-prevLoc[2]).length
					
					if dist == 0:	dist = 5
					
					# Get maximum speed (m/s)
					spd = NODE_MAXSPEED.val
					if spd == 0: spd = 100
					# Get ETA (m / m/s)
					ETA = dist/spd
					
					# Get previous nodes ipo keyframe
					
					scn = Scene.GetCurrent()
					fps = scn.getRenderingContext().fps
					
					# Retrieve the last keyframe in the curve
					kf = ipo[Blender.Ipo.OB_LOCX].bezierPoints[-1].pt[0]
					kf += fps*ETA
					
					# Add new node to ipo curves
					bzY = kf, node.loc[1], 0
					print bzY
					
					ipo[Blender.Ipo.OB_LOCX].append(Blender.BezTriple.New(kf, node.loc[0], 0))
					ipo[Blender.Ipo.OB_LOCY].append(Blender.BezTriple.New(bzY))
					ipo[Blender.Ipo.OB_LOCZ].append(Blender.BezTriple.New(kf, node.loc[2], 0))
					ipo[Blender.Ipo.OB_ROTX].append(Blender.BezTriple.New(kf, math.degrees(node.rot[0])/10, 0))
					ipo[Blender.Ipo.OB_ROTY].append(Blender.BezTriple.New(kf, math.degrees(node.rot[1])/10, 0))
					ipo[Blender.Ipo.OB_ROTZ].append(Blender.BezTriple.New(kf, math.degrees(node.rot[2])/10, 0))
				else:
					# See if the ipo exists, but wasn't assigned yet
					temp = False
					try:		
						ipo = Blender.Ipo.Get(basename)
						dummy.setIpo(ipo)
					except:	
						temp = Draw.PupMenu('ERROR: Couldn\'t retrieve Ipo data for the path <'+basename+'>. Create Ipo?%t|Yes%x1|No%x0')	
								
					if temp:
						ipo = Blender.Ipo.New('Object', basename)
						# Compile a list of locations and rotations from previous; no need to make an exception for the newest node
						LocRot = []
						maxSpd = []
						n = 1
						try:		nextNode = Object.Get(basename+'_key'+str(n))
						except:	nextNode = None
						while nextNode:
							# Retrieve location and rotation, append to lists
							LocRot.append( [nextNode.loc.x, nextNode.loc.y, nextNode.loc.z, \
															math.degrees(nextNode.rot.x)/10, \
															math.degrees(nextNode.rot.x)/10, \
															math.degrees(nextNode.rot.x)/10])
							# Get maximum speed
							try:		spd = nextNode.getProperty('MaxSpeed').data
							except:	spd = 1
							maxSpd.append(spd)
							n += 1
							try:		nextNode = Object.Get(basename+'_key'+str(n))
							except:	nextNode = 0
						# Add requisite Ipo curves
						curves2Add = ['LocX', 'LocY', 'LocZ', 'RotX', 'RotY', 'RotZ']
						for curv in curves2Add:		curv = ipo.addCurve(curv)
						# ...sigh...Iterate through the existing nodes and add their rotation and location to the ipo curve.
						n1 = 0
						keyframe = 0
						fps = Scene.GetCurrent().getRenderingContext().fps
						for l in LocRot:
							# Determine keyframe
							if n1 > 0:	dist = Vector(l[0]-loc[n1-1][0], l[1]-loc[n1-1][1], l[2]-loc[n1-1][2]).length
							else:				dist = 1
							
							spd = maxSpd[n1]
							
							ETA = dist/spd
							
							keyframe += ETA*fps
							# Add values to Ipo curves (rotations have already been converted)
							for curv in curves2Add:
								index = curves2Add.index(curv)
								curv.append( Blender.BezTriple.New(keyframe, l[index], 0) )
								
					else:	print "Dockpath dummy object didn't have an Ipo curve:",basename
				# Add game properties
				node.addProperty("UseRot", 						NODE_USEROT.val,		"BOOL")
				node.addProperty("MaxSpeed", 					NODE_MAXSPEED.val,	"FLOAT")
				node.addProperty("DropFocus", 				NODE_DROPFOCUS.val,	"BOOL")
				node.addProperty("checkRotation", 		NODE_CHKROT.val,		"BOOL")
				node.addProperty("forceCloseBehavior",NODE_FCB.val,				"BOOL")
				node.addProperty("playerInControl", 	NODE_PIC.val,				"BOOL")
				node.addProperty("queueOrigin", 			NODE_ORIGIN.val,		"BOOL")
				node.addProperty("useClipPlane", 			NODE_UCP.val,				"BOOL")
				node.addProperty("advanceQueue", 			NODE_ADVQ.val,			"BOOL")
				
				dummy.makeParent([node])
				
				try:
					pathgrp = Blender.Group.Get(basename)
					pathgrp.objects.link(node)
				except ValueError:
					print "Blender group,",basename,"not found"
		elif	evt == EVENT_D_D_EXIT:
			try:
				actObj.removeProperty('isExit')
				actObj.addProperty('isExit', bool(DUMMY_EXIT.val), 'BOOL')
			except:
				print '''Error: [EVENT_D_D_EXIT] Couldn't retrieve property "isExit" from object '''+actObj.name
		elif	evt == EVENT_D_D_LATCH:
			try:
				actObj.removeProperty('isExit')
				actObj.addProperty('isExit', bool(DUMMY_LATCH.val), 'BOOL')
			except:
				print '''Error: [EVENT_D_D_LATCH] Couldn't retrieve property "isLatchPath" from object '''+actObj.name
		elif 	evt == EVENT_D_D_UDA:
			try:
				prop = actObj.getProperty('useDockAnimation')
				#if DUMMY_UDA.val:	prop.data = True # This changes the property type to INT...not that it makes a huge difference, but still!
				#else:							prop.data = False
				actObj.removeProperty('useDockAnimation')
				if DUMMY_UDA.val: actObj.addProperty('useDockAnimation', True, 'BOOL')
				else:							actObj.addProperty('useDockAnimation', False, 'BOOL')
			except ValueError:
				print '''Error: [EVENT_D_D_UDA] Couldn't retrieve property "isLatchPath" from object '''+actObj.name
			redrawBUTS()
		# [Dock Families]
		elif	evt == EVENT_D_D_FAMILY_ADD:
			index = len(families) + 1
			actObj.addProperty('dockFamily'+str(index), 'className', 'STRING')
		elif	evt in EVENT_D_D_FAMILY_UPDATE_RNG:
			global familyMenu
			index = evt - EVENT_D_D_FAMILY_UPDATE
			# print evt, index, "Was in EVENT_D_D_FAMILY_UPDATE_RNG"
			prop = actObj.getProperty('dockFamily'+str(index+1))
			prop.data = familyMenu[index][0].val
			redrawBUTS()
			redrawSCRIPTS()
		elif	evt in EVENT_D_D_FAMILY_DELETE_RNG:
			index = evt - EVENT_D_D_FAMILY_DELETE
			#print "removing dockfamily"+str(index+1)
			actObj.removeProperty('dockFamily'+str(index+1))
			# Need to renumber the family list to reflect any changes
			index2 = index+2
			prop = getSafeProperty( actObj, 'dockFamily'+str(index2) )
			while prop:
				prop.name = 'dockFamily'+str(index+1)
				index  += 1; index2 += 1;
				prop = getSafeProperty( actObj, 'dockFamily'+str(index2) )
			redrawBUTS()
			redrawSCRIPTS()
		# [DOCK LINKED PATHS]
		elif	evt == EVENT_D_D_LINK_ADD:
			index = len(links) + 1
			actObj.addProperty('linkedPath'+str(index), 'pathName', 'STRING')
			
		elif	evt in EVENT_D_D_LINK_UPDATE_RNG:
			global linkMenu
			index = evt - EVENT_D_D_LINK_UPDATE
			prop = actObj.getProperty('linkedPath'+str(index+1))
			prop.data = linkMenu[index][0].val
			redrawBUTS()
			redrawSCRIPTS()
			
		elif	evt in EVENT_D_D_LINK_DELETE_RNG:
			index = evt - EVENT_D_D_LINK_DELETE
			#print "removing dockfamily"+str(index+1)
			actObj.removeProperty('linkedPath'+str(index+1))
			# Need to renumber the family list to reflect any changes
			index2 = index+2
			prop = getSafeProperty(actObj, 'linkedPath'+str(index2))
			while prop:
				prop.name = 'linkedPath'+str(index+1)
				index  += 1; index2 += 1;
				prop = getSafeProperty(actObj, 'linkedPath'+str(index2))
			redrawBUTS()
			redrawSCRIPTS()
			
		# [NODES]
		elif	evt == EVENT_D_N_USEROT:
			actObj.removeProperty('UseRot')
			actObj.addProperty('UseRot', bool(NODE_USEROT.val), 'BOOL')
			redrawBUTS()
		elif	evt == EVENT_D_N_CHKROT:
			actObj.removeProperty('checkRotation')
			actObj.addProperty('checkRotation', bool(NODE_CHKROT.val), 'BOOL')
			redrawBUTS()
		elif	evt == EVENT_D_N_FCB:
			actObj.removeProperty('forceCloseBehavior')
			actObj.addProperty('forceCloseBehavior', bool(NODE_FCB.val), 'BOOL')
			redrawBUTS()
		elif	evt == EVENT_D_N_UCP:
			actObj.removeProperty('useClipPlane')
			actObj.addProperty('useClipPlane', bool(NODE_UCP.val), 'BOOL')
			redrawBUTS()
		elif	evt == EVENT_D_N_PIC:
			actObj.removeProperty('playerInControl')
			actObj.addProperty('playerInControl', bool(NODE_PIC.val), 'BOOL')
			redrawBUTS()
		elif	evt == EVENT_D_N_DROPFOCUS:
			actObj.removeProperty('DropFocus')
			actObj.addProperty('DropFocus', bool(NODE_DROPFOCUS.val), 'BOOL')
			redrawBUTS()
		elif	evt == EVENT_D_N_ORIGIN:
			actObj.removeProperty('queueOrigin')
			actObj.addProperty('queueOrigin', bool(NODE_ORIGIN.val), 'BOOL')
			redrawBUTS()
		elif	evt == EVENT_D_N_ADVQ:
			actObj.removeProperty('advanceQueue')
			actObj.addProperty('advanceQueue', bool(NODE_ADVQ.val), 'BOOL')
			redrawBUTS()
		elif	evt == EVENT_D_N_POINTTOL:
				actObj.size = NODE_POINTTOL.val, NODE_POINTTOL.val, NODE_POINTTOL.val
				redrawBUTS()
		elif	evt == EVENT_D_N_MAXSPEED:
			actObj.getProperty('MaxSpeed').data = NODE_MAXSPEED.val
			redrawBUTS()
	redrawSCRIPTS()

def draw_ui():
	# UI related functions
	def __isNavLight(obj):
		if obj:
			if obj.type == 'Lamp': return True
			# elif obj.name.startswith('Nav') and obj.name.endswith('size'): return True
		return False
	
	def __isMarker(obj):
		if obj:
			if obj.type == 'Empty' and obj.name.startswith('marker'): return True
		return False
		
	def __hasProp(obj, propertyName, propertyType=''):
		'''Returns True if object has a property called <propertyName> of type <propertyType> 
		(valid entries for type are 'STRING', 'BOOL', 'INT', 'FLOAT', .'''
		try:
			prop = obj.getProperty(propertyName).type
			if prop == propertyType or propertyType == '':	return True
		except RuntimeError: return False
		
	def drawHEADER(x=0, y=0, subhead = ''):
		'''Draws the simple header for the toolbox, returns the bottom left coordinate of the header.'''
		title = '--HOD TOOLBOX--'
		title_w = Draw.GetStringWidth(title, 'large')		
		y -= 40
		glColor3f(0,1,1)
		glRasterPos2i(x, y+5)
		Draw.Text(title, 'large')
		glColor3f(0,0.00,0.50);	glRecti(x-10,					y+23,	x+title_w+10,	y+25)
		glColor3f(0,0.25,0.75);	glRecti(x-25,					y+20,	x+title_w+25,	y+23)
		glColor3f(0,0.50,1.00);	glRecti(x-30,					y+15, x-10,					y+20); 	glRecti(x+title_w+10,			y+15, x+title_w+30,	y+20)
		glColor3f(0,0.25,1.00);	glRecti(x-35,					y+5, 	x-20,					y+15); 	glRecti(x+title_w+20,			y+5, 	x+title_w+35,	y+15)
		glColor3f(0,0.50,1.00);	glRecti(x-45,					y, 		x-10,					y+5); 	glRecti(x+title_w+10,			y, 		x+title_w+45,	y+5)
		y -= 3
		glColor3f(0,0.75,1.0);	glRecti(x-60,					y,		x+title_w+60,	y+3)
		y -= 2
		glColor3f(0,1.00,1.0);	glRecti(x-140,				y,		x+235,				y+2)
		return x, y-25
		
	def drawMenu():
		'''Draws the various menus'''
		def __drawJOINT(x=0,	y=0, actObj=None):
			def __drawNameStatus(x, y, actObj = None):
				'''Draws the status indicators for a joint name'''
				global JOINT, JOINT_BLENDNAME, JOINT_BASENAME
				nameSeq = JOINT, JOINT_BASENAME, JOINT_BLENDNAME = __getName__()
				# print JOINT, JOINT_BASENAME, JOINT_BLENDNAME
				try:
					ob = Blender.Object.Get(JOINT_BLENDNAME)
					bExists = True
				except ValueError: bExists = False
				
				if actObj:
					# print JOINT_BLENDNAME, actObj.name
					if JOINT_BLENDNAME == actObj.name:	bSelected = True
					else:	bSelected = False
				else:		bSelected = False
				
				if bSelected:		Jred, Jgreen, Jblue = 0.0, 0.5, 1.0; JsUse = "Selected"
				else:
					# Jred2 = 0.0;  Jgreen2 = 0.0;	Jblue2 	= 0.0; JsUse	= ""
					if bExists:		Jred, Jgreen, Jblue = 1.0, 0.0, 0.0; JsUse 	= 'Used';
					else:					Jred, Jgreen, Jblue = 0.0, 1.0, 0.0; JsUse		= 'OK';
				
				
				margin = 5
				ht = 10
				spacing = 5
				#if bExists:
				msg1 = 'GameName: '+JOINT
				lenJOINT = Blender.Draw.GetStringWidth(msg1)
				
				glColor3f(0, 0.75, 1.0)
				glRecti(x-140, y-margin, x-140+margin+lenJOINT+margin, y+ht+margin)
				glColor3f(0,0,0)
				glRasterPos2i(x-140+margin, y)
				Draw.Text(msg1)
				
				msg2 = 'BlendName: '+JOINT_BLENDNAME + ' - ' + JsUse
				lenBLENDNAME = Blender.Draw.GetStringWidth(msg2)
				
				y = y-margin-ht-spacing
				glColor3f(Jred,Jgreen,Jblue)
				glRecti(x-140, y-margin, x-140+margin+lenBLENDNAME+margin, y+ht+margin)
				glColor3f(0,0,0)
				glRasterPos2i(x-140+margin, y)
				Draw.Text(msg2)
				
				y = y+2*(-margin-ht-spacing)
				return x, y
			'''Draws joint menu'''
			# Declare Globals
			global ADD_JOINT, UPDATE_JOINT, JOINT_TYPE, JOINT_SUB, JOINT_INDEX, JOINT_NAME, JOINT_SLAVE, JOINT_SINDEX, JOINT_POS, JOINT, JOINT_BLENDNAME
			global POSITION, TYPE, SLAVE, SUBTYPE
			global SHOW_JOINT
			if SHOW_JOINT.val:
				if 		JOINT_TYPE.val == 0:			# WEAPON
					y -= 20
					JOINT_TYPE = Draw.Menu(TYPE, 					EVENT_J_NAME, x-140, 	y, 225, 20, JOINT_TYPE.val, 'Select what kind of joint to add')
					
					if JOINT_SLAVE.val:
						JOINT_SLAVE = Draw.Toggle('S', 	EVENT_J_NAME, x+85, 	y, 20, 20, JOINT_SLAVE.val, 'Is this joint a slave?')
						JOINT_SINDEX = Draw.Number('',	EVENT_J_NAME, x+105, 	y, 35, 20, JOINT_SINDEX.val, 0, 99, 'Slave index; setting this to 0 will hide the number.')
					else:	
						JOINT_SLAVE = Draw.Toggle('Slave', EVENT_J_NAME, x+85, y, 55, 20, JOINT_SLAVE.val, 'Is this joint a slave?')
						JOINT_SINDEX.val = 0
					
					y -= 20
					# JOINT_SUB.val = 0							# Only used by hardpoints
					JOINT_INDEX = Draw.Number('', 				EVENT_J_NAME,x-140, 	y, 85, 20, JOINT_INDEX.val, -1, 9999, 'Set the index of the joint; -1 to hide')
					JOINT_NAME = Draw.String('Name:', 		EVENT_J_NAME, x-55, 	y, 195, 20, JOINT_NAME.val, 31, 'Enter a name for the new joint')
					if JOINT_POS.val == 3:	JOINT_POS.val = 0
					j = POSITION[JOINT_TYPE.val]
					y -= 20
					JOINT_POS = Draw.Menu(j,							EVENT_J_NAME, 	x-140, 	y, 280, 20, JOINT_POS.val, "Select the joint's function")
					Draw.EndAlign()
					
					ADD_JOINT = Draw.Toggle('Add', 				EVENT_JOINT, 	x+140,	y, 70, 80, ADD_JOINT.val, 'Create joint')
				elif	JOINT_TYPE.val == 1:			# HARDPOINT
					y -= 20
					JOINT_TYPE = Draw.Menu(TYPE, 					EVENT_J_NAME,		x-140,	y, 225, 20, JOINT_TYPE.val, 'Select what kind of joint to add')
					
					JOINT_SLAV_DUMMY = \
						Draw.PushButton('-N/A-', 						EVENT_NONE, 	x+85,		y, 55, 20, "Cannot be set as slave.")
					y-= 20
					JOINT_INDEX = Draw.Number('', 				EVENT_J_NAME, 	x-140,	y, 85, 20, JOINT_INDEX.val, -1, 9999, 'Set the index of the joint; -1 to disable ')
					JOINT_SUB = Draw.Menu(SUBTYPE, 				EVENT_J_NAME,		x-55,		y, 195, 20, JOINT_SUB.val, 'Select the HardPoint type to add')
					
					y -= 20
					JOINT_POS_DUMMY = \
						Draw.PushButton('Position', 				EVENT_NONE, 	x-140, 	y, 280, 20)
					Draw.EndAlign()
					JOINT_POS.val = 0
					Draw.EndAlign()
					ADD_JOINT = Draw.Toggle('Add', 				EVENT_NONE,		x+140,	y, 70, 80, ADD_JOINT.val, 'Create joint')
				elif	JOINT_TYPE.val in [2,3]:	# CAPTURE/REPAIR
					y -= 20
					# Draw.BeginAlign()
					JOINT_TYPE = Draw.Menu(TYPE, 					EVENT_J_NAME, 	x-140, 	y, 225, 20, JOINT_TYPE.val, 'Select what kind of joint to add')
					JOINT_SLAV_DUMMY = \
						Draw.PushButton('-N/A-', 						EVENT_NONE, 	x+85,		y, 55, 20, "Cannot be set as slave.")
					y -= 20
					JOINT_INDEX = Draw.Number('', 				EVENT_J_NAME, 	x-140, 	y, 85, 20, JOINT_INDEX.val, -1, 9999, 'Set the primary index of the joint')
					JOINT_NAME_DUMMY = \
						Draw.PushButton('-----N/A-----', 		EVENT_NONE, 	x-55, 	y, 195, 20, "Capture/Repair Points don't have a special name.")
					y -= 20
					JOINT_POS_DUMMY = \
						Draw.PushButton('-----N/A-----', 		EVENT_NONE, 	x-140, 	y, 280, 20, "Capture/Repair points only have position")
					Draw.EndAlign()
					# y -= 20
					
					ADD_JOINT = Draw.Toggle('Add',				EVENT_J_NAME, 	x+140,	y, 70,	80, ADD_JOINT.val, 'Create joint')
				elif	JOINT_TYPE.val == 4:			# CUSTOM
					y -= 20;	JOINT_TYPE = Draw.Menu(TYPE, 					EVENT_J_NAME, 	x-140, 	y, 225, 20, JOINT_TYPE.val, 'Select what kind of joint to add')
					
					if JOINT_SLAVE.val:
						JOINT_SLAVE = Draw.Toggle('S', 			EVENT_J_NAME,		x+85, 	y, 20, 20, JOINT_SLAVE.val, 'Is this joint a slave?')
						JOINT_SINDEX = Draw.Number('',			EVENT_J_NAME, 	x+105, 	y, 35, 20, JOINT_SINDEX.val, 0, 99, 'Slave index')
					else:	
						JOINT_SLAVE = Draw.Toggle('Slave',	EVENT_J_NAME,		x+85,		y, 55, 20, JOINT_SLAVE.val, 'Is this joint a slave?')
						JOINT_SINDEX.val = 0
					
					y -= 20
					JOINT_SUB.val = 0
					JOINT_INDEX = Draw.Number('', 				EVENT_J_NAME, 	x-140, 	y, 85, 	20, JOINT_INDEX.val, -1, 9999, 'Set the index of the joint; -1 to hide ')
					JOINT_NAME = Draw.String('Name:', 		EVENT_J_NAME, 	x-55, 	y, 195,	20, JOINT_NAME.val, 31, 'Enter a name for the new joint')
					y -= 20
					JOINT_POS = \
						Draw.Menu(POSITION[JOINT_TYPE.val], EVENT_NONE, 	x-140, 	y, 280, 	20, JOINT_POS.val, "Select the joint's function")
					Draw.EndAlign()
					ADD_JOINT = Draw.Toggle('Add',				EVENT_J_NAME,		x+140,	y, 70,		80, ADD_JOINT.val, 'Create joint')
				x, y = __drawNameStatus(x, y-20, actObj)
				return x, y
			else: return x, y-30
			
		def __drawNAV(	x=0,	y=0, actObj=None):
			'''Draws NavLight Menu'''
			global NAV_ADD, NAV_NAME, NAV_COLOR, NAV_ALPHA, NAV_VIS, NAV_LIT, NAV_PHASE, NAV_FREQ, NAV_SIZE
			if __isNavLight(actObj):	NAV_NAME.val = actObj.name
			global SHOW_NAV
			if SHOW_NAV.val:
				try:
					nav = Object.Get(NAV_NAME.val)
					bExists = True
					# print actObj, nav
					if nav == actObj:	bSelected = True
					else:							bSelected = False
				except:
					nav = None
					bExists = False
					bSelected = False
					
				VIS = 'Visibility%t|Hidden%x0|Visible%x1'
				LIT = 'Light Quality%t|Simple%x0|Cast Light%x1'
				y -= 20
				if nav:	Draw.PushButton('', EVENT_NONE, x+140, 	y, 70, 40, '')
				else:		NAV_ADD = Draw.Toggle('Add', 				EVENT_NAVL, 	x+140, 	y, 70, 40, NAV_ADD.val, 'Create NavLight')
				NAV_NAME = Draw.String('Name:', 		EVENT_N_NAME, x-140,	y, 280, 20, NAV_NAME.val, 21, 'Enter name for NavLight')
				#NAV_DEX = Draw.Number('', eDex, 									x+230, 	y+175, 35, 20, NAV_DEX.val, 0, 99, 'NavLight Index (-1 to hide)')
				y-= 20
				Draw.BeginAlign()
				NAV_VIS = Draw.Menu(VIS, EVENT_N_VIS, 						x-80, 	y, 145, 20, NAV_VIS.val, "Is this light visible in-game")
				NAV_LIT = Draw.Menu(LIT, EVENT_N_LIT, 						x+65, 	y, 145, 20, NAV_LIT.val, "Should this light source cast light on high-end systems?")
				Draw.EndAlign()
				
				Draw.BeginAlign()
				NAV_COLOR = Draw.ColorPicker(	EVENT_N_COLOR, 			x-140, 	y-20, 60, 40, NAV_COLOR.val, 'Select a color for the light')
				NAV_ALPHA = Draw.Number('A:', EVENT_N_COLOR,			x-140, 	y-40, 60, 20, NAV_ALPHA.val, 0.0, 1.0, 'Set the alpha level')
				Draw.EndAlign()

				Draw.BeginAlign()
				y -= 20
				NAV_PHASE = Draw.Slider('Phase: ', 	EVENT_N_PHASE,x-80, 	y, 145, 20, 0.0, NAV_PHASE.val, 20.0, 1, "Initial delay before this navlight will start it's cycle.")
				NAV_FREQ = Draw.Slider('Freq: ', 		EVENT_N_FREQ, x+65, 	y, 145, 20, 0.0, NAV_FREQ.val, 20.0, 1, "Frequency that Navlight will appear.")
				y -= 20
				NAV_SIZE = Draw.Slider('Size: ', 		EVENT_N_SIZE, x-80, 	y, 290, 20, NAV_SIZE.val, 0, 1000, 1, "Size of navlight image.")
				Draw.EndAlign()		
				
				NAV = NAV_NAME.val
				
				if bSelected:	Nred, Ngreen, Nblue = 0.0, 0.5, 1.0; NsUse = 'Selected'
				elif bExists:	Nred, Ngreen, Nblue = 1.0, 0.0, 0.0; NsUse = 'Used'
				else:					Nred, Ngreen, Nblue = 0.0, 1.0, 0.0; NsUse = 'OK'
				
				ht = 10
				margin = 5
				msg = 'NavName: '+NAV+" - "+NsUse
				l = Draw.GetStringWidth(msg)
				y -= 20
				
				glColor3f(Nred,Ngreen,Nblue)
				glRecti(x-140,y-margin,x-140+margin+l+margin,y+ht+margin)
				
				glColor3f(0,0,0)
				glRasterPos2i(x-140+margin, y)
				Draw.Text(msg)
				y += -2*margin-20
				return x, y
			else:	return x, y-30
		def __drawMRKR(	x=0,	y=0, actObj=None):
			global MRKR_NAME, MRKR_ADD
			global SHOW_MRKR
			if SHOW_MRKR.val:
				mrkr = None
				r,g,b = 0.0, 1.0, 0.0
				sMsg = 'OK'
				try:		mrkr = Object.Get(MRKR_NAME.val)
				except:	pass
				
				if mrkr:
					if mrkr != actObj:	r,g,b = 1.0, 0.0, 0.0;	sMsg	= 'Used';
					else:								r,g,b = 0.0, 0.5, 1.0;	sMsg 	= 'Selected';
					
				y -= 20
				MRKR_NAME = Draw.String('Name:',	EVENT_M_NAME, 	x-140,		y, 280, 20, MRKR_NAME.val, 21, 'Enter name for marker')
				Draw.EndAlign()
				if mrkr:	Draw.PushButton('', 		EVENT_MRKR, 	x+140,		y, 70, 40, '')
				else:			MRKR_ADD = Draw.Toggle('Add', 		EVENT_MRKR, 	x+140,		y, 70, 40, MRKR_ADD.val, 'Create Marker')
				ht = 10
				margin = 5
				msg = 'Marker Name: '+MRKR_NAME.val+" - "+sMsg
				l = Draw.GetStringWidth(msg)
				y -= 20
				
				glColor3f(r,g,b)
				glRecti(x-140,y-margin,x-140+margin+l+margin,y+ht+margin)
				
				glColor3f(0,0,0)
				glRasterPos2i(x-140+margin, y)
				Draw.Text(msg)
				y += -2*margin-20
				return x, y
			else:		return x, y-30
		def __drawDOCK(	x=0,	y=0, actObj=None):
			def __drawDOCKMenu(	x=0, y=0, actObj=None):
				def __writeSCRIPT__(method):
					if method.lower() == "live":
						try: py = Blender.Text.Get('PATH_LIVE_UPDATER.py')
						except: 
							py = Blender.Text.New('PATH_LIVE_UPDATER.py')
							py.fakeUser = True
							for line in pyLIVE: py.write(line)
					elif method.lower() == 'postedit' or method.lower() == 'pe':
						try: py = Blender.Text.Get('PATH_POST_UPDATER.py')
						except: 
							py = Blender.Text.New('PATH_POST_UPDATER.py')
							py.fakeUser = True
							for line in pyPOSTEDIT: py.write(line)
					return py
				def __showDupliframes(evt, val):
					global DOCK_SHOWFRAMES
					obj = Object.GetSelected()
					if obj:	
						obj = obj[0]
						obj.enableDupFrames = bool(DOCK_SHOWFRAMES.val)
				global	DOCK_NAME, DOCK_UPDATE_METHOD, DOCK_SHOWFRAMES, DOCK_FRAMEOFFSET, DOCK_UPDATE, DOCK_NODE_ADD_METHOD, DOCK_NODE_ADD,\
								XOff, YOff, ZOff
				
				ui_x, ui_y 		= x, y
				#print "type=>",type
				nT = __getSubPathType(actObj)[1]
				nType = nT*3
				#print nType
				MENU 					= 'Method%t|Manual%x0|Live%x1|Post-edit%x2'
				ADD_NODE_MENU = 'Method%t|3D Cursor%x1|Local Coordinates%x2'
				y -= 20
				DOCK_UPDATE_METHOD 		= Draw.Menu(	MENU, 					EVENT_DRAW, 						x-140,	y, 125, 20, DOCK_UPDATE_METHOD.val, "Select a method for updating the dockpath.")
				if DOCK_SHOWFRAMES.val:
					DOCK_SHOWFRAMES				= Draw.Toggle('Show Frame',		EVENT_D_SHOWFRAMES,		x-15,		y, 75,	20, DOCK_SHOWFRAMES.val, "When active, ghosted copies of the animation are displayed." )
					DOCK_FRAMEOFFSET			= Draw.Number('Offset:',			EVENT_D_FRAMEOFFSET,	x+60,		y, 80,	20, DOCK_FRAMEOFFSET.val, 0, 15000, "Draw every <x> frame (set to 0 to display all).")
				else:
					DOCK_SHOWFRAMES				= Draw.Toggle('Show Frame',		EVENT_D_SHOWFRAMES,		x-15,		y, 155,20, DOCK_SHOWFRAMES.val, "When active, ghosted copies of the animation are displayed." )
				y -= 20
				DOCK_NAME 							=	Draw.String('Name:', 				EVENT_D_NAME, 				x-140,	y, 125, 20, DOCK_NAME.val, 21, 'Enter name for dockpath.')
				if DOCK_UPDATE_METHOD.val == 0:
					y -= 20
					help = ['', "Update from nodes.", '', "Update from Ipo"]
					DOCK_UPDATE 				= Draw.Toggle('Update', 		EVENT_D_UPDATE[nT], 		x-140, 		y, 125, 20, 0, help[nT])
				elif DOCK_UPDATE_METHOD.val == 1:
					actObj.clearScriptLinks()
					try:		script = Blender.Text.Get('PATH_LIVE_UPDATER.py')
					except:	script = __writeSCRIPT__('live')
					actObj.addScriptLink(script,'ObjectUpdate')
					# if type == 3: # NODE
						# Draw.Label("Not implemented yet", x-140, y, 330, 20)
					# elif type == 9: # IPO
						# Draw.Label("Not implemented yet", x-140, y-40, 330, 20)
				elif DOCK_UPDATE_METHOD.val == 2:
					actObj.clearScriptLinks()
					try: 		script = Blender.Text.Get('PATH_POST_UPDATER.py')
					except: script = __writeSCRIPT__('postedit')
					actObj.addScriptLink('PATH_POST_UPDATER.py','ObDataUpdate')
				# Node addition
				if 		DOCK_NODE_ADD_METHOD.val == 1:
					y -= 20
					Draw.PushButton('', EVENT_NONE, x-15, y, 155, 60)
					temp = Draw.Toggle('Add Node', EVENT_D_NODE, 	x+140,	y, 70, 100, 0, "Add a new node to the dockpath.");
					
				elif	DOCK_NODE_ADD_METHOD.val == 2:
					y -= 20
					#DOCK_NODE_ADD.val = 0
					Draw.PushButton('Add Node', EVENT_D_NODE, 	x+140,	y, 70, 100, "Add a new node to the dockpath")
					#Draw.BeginAlign()
					XOff = Draw.Slider(					'X: ', 				EVENT_NONE, 		x-15, 	y, 155, 20, 0.0, -250, 250, XOff.val, "Offset from curve's center on X-axis.")
					y += 20
					YOff = Draw.Slider(					'Y: ', 				EVENT_NONE, 		x-15, 	y, 155, 20, 0.0, -250, 250, YOff.val, "Offset from curve's center on Y-axis.")
					y += 20
					ZOff = Draw.Slider(					'Z: ', 				EVENT_NONE, 		x-15, 	y, 155, 20, 0.0, -250, 250, ZOff.val, "Offset from curve's center on Z-axis.")
					#Draw.EndAlign()
					
					str = '''* Coordinates are relative to Curve's Center'''
					str_w = Draw.GetStringWidth(str)
					glRasterPos2i(ui_x+str_w/2-130, ui_y-95)
					glColor3f(1,1,1)
					Draw.Text(str)
					glColor3f(0,0,0)
					y -= 40
				DOCK_NODE_ADD_METHOD 	=	Draw.Menu(	ADD_NODE_MENU,	EVENT_DRAW, 					x-140, 	y, 125, 20, DOCK_NODE_ADD_METHOD.val, "Method for determining where to place a new node.")
				y -= 20
				return x, y
			def __drawNODEMenu(	x=0, y=0, actObj=None):
				'''Draws the menu for editing nodes'''
				global	NODE_USEROT, NODE_POINTTOL, NODE_DROPFOCUS, NODE_MAXSPEED, \
								NODE_CHKROT, NODE_FCB, 	NODE_PIC, NODE_ORIGIN, NODE_UCP, NODE_ADVQ

				#TF = ["Off", "On"]
				YN = ["No", "Yes"]
				Draw.BeginAlign()
				# Ship rotation-related; These affect the animation as well.
				y -= 20; NODE_USEROT =	Draw.Toggle("Use Rotation: "+YN[NODE_USEROT.val], 				EVENT_D_N_USEROT, x-130, 		y, 170, 	20, NODE_USEROT.val,	'When active, ships will gradually match the rotation of this node during their journey to the next.')
				y -= 20; NODE_CHKROT	=	Draw.Toggle("Check Rotation: "+YN[NODE_CHKROT.val], 			EVENT_D_N_CHKROT,	x-130,		y,	170, 	20, NODE_CHKROT.val,	"When active, a ship will stop and match it's rotation to the node's before moving on to the next.");
				y -= 20; NODE_FCB 		= Draw.Toggle("Force Close Behavior: "+YN[NODE_FCB.val],		EVENT_D_N_FCB, 		x-130,		y,	170,	20, NODE_FCB.val, 		"When active, a docking ship will match it's rotation to the node's and then slide to the next node.");
				Draw.EndAlign()
				# HW2 GUI-related (these affect how 
				Draw.BeginAlign()
				y += 40; NODE_UCP				= Draw.Toggle("Use Clip Plane: "+YN[NODE_UCP.val], 			EVENT_D_N_UCP, 	x+40,		y,		170,	20, NODE_UCP.val, 			"When active, any polygons of a ship that pass this node will not be drawn.");
				y -= 20; NODE_PIC				= Draw.Toggle("Player in Control: "+YN[NODE_PIC.val], 	EVENT_D_N_PIC, 	x+40,		y,		170,	20, NODE_PIC.val,				'When active, the player can still issue orders to the ship. When inactive, all player orders are ignored.')
				y -= 20; NODE_DROPFOCUS	= Draw.Toggle("Drop Focus: "+YN[NODE_DROPFOCUS.val], 		EVENT_D_N_DROPFOCUS, 	x+40,		y,		170,	20, NODE_DROPFOCUS.val,	'When active, a ship that reaches this node will no longer be able to be centered on by the camera.')
				Draw.EndAlign()
				# Ship path related (Only one node in a path may have these active at a given time.)
				Draw.BeginAlign()
				y -= 22;	NODE_ORIGIN	= 		Draw.Toggle("Queue Origin: "+YN[NODE_ORIGIN.val], 		EVENT_D_N_ORIGIN, x-65,		y,	210,	20, NODE_ORIGIN.val,		'When active, this node will serve as the point for the beginning of the ship queue.');
				y -= 20;	NODE_ADVQ	= 			Draw.Toggle("Advance Queue: "+YN[NODE_ADVQ.val], 			EVENT_D_N_ADVQ, 	x-65,		y,	210,	20, NODE_ADVQ.val,			"When active, ship's reaching this node will trigger the start of the docking procedure for the next ship in the queue.");
				Draw.EndAlign()
				# Pathfinding-related
				y -= 22;	NODE_POINTTOL = 	Draw.Slider('Point Tolerance: ',		EVENT_D_N_POINTTOL,	x-140,		y,350,	20, NODE_POINTTOL.val, 0, 1000, 1,	'Radius around sphere a ship must be within to be considered on this particular node.')
				y -= 20;	NODE_MAXSPEED	= 	Draw.Slider('Max Speed: ', 					EVENT_D_N_MAXSPEED,	x-140,		y,350,	20, NODE_MAXSPEED.val, 0.0, 10000.0, 1, 'Maximum speed a ship may travel at while on this node.')
				y -= 20;	Draw.PushButton('Recalc Animation',					EVENT_D_UPDATE_FROMNODE, x-140,		y,	350,	20)
				# __LocBox__(x, y)
				return x, y
				
			def __drawDUMMYMenu(x=0, y=0, actObj=None):
				def __drawFAMILYMenu(x=0,y=0, actObj=None):
					'''Draw a menu showing all dockable ship classes'''
					global families, familyMenu
					# print "families", families
					familyMenu = []
					n = 0
					for fam in families:
						index = families.index(fam)
						
						bDup = False
						cnt = families.count(fam)
						draw_x = -140, 60
						if cnt >= 2:
							# print "MoreThanOne",fam
							index = families[n:].index(fam)+n
							# print index
							bDup = True
							draw_x = -140+5*(cnt+1), 60+5*(cnt+1)
							
						y = y-20 # *(index + 1)
						m = [Draw.Create(fam), Draw.Create(0)]
						m = [	Draw.String('Class: ', 	EVENT_D_D_FAMILY_UPDATE+index,	x+draw_x[0], 		y,	200,20, m[0].val, 15),\
									Draw.Toggle('Delete', 	EVENT_D_D_FAMILY_DELETE+index,	x+draw_x[1],		y,	80,	20, m[1].val, 'Remove this class from the list.') ]
						if bDup:
							glColor3f(1.0, 0.0, 0.0)
							glRecti(x+draw_x[0]-20, y+2, x+draw_x[0]-5, y+17)
							dup = 'Duplicate'
							lngth = Draw.GetStringWidth(dup)
							glRasterPos2i(x-lngth+draw_x[0]-25, y+5)
							Draw.Text(dup)
							
						familyMenu.append(m)
						n += 1
					#print "familyMenu", familyMenu
					bAdd = Draw.PushButton('Add Class', EVENT_D_D_FAMILY_ADD,			x-140,	y-20, 280,20)
					return x, y-20
					
				def __drawLINKSMenu(x=0, y=0, actObj= None): # [ Not Done ]
					'''Draw a menu showing all dockable ship classes'''
					global links, linkMenu
					
					linkMenu = []
					n = 0
					for link in links:
						index = links.index(link)
						
						bDup = False
						cnt = links.count(link)
						draw_x = -140, 60
						if cnt >= 2:
							# print "MoreThanOne",fam
							index = links[n:].index(link)+n
							# print index
							bDup = True
							draw_x = -140+5*(cnt+1), 60+5*(cnt+1)
							
						y = y-20 # *(index + 1)
						
						m = [Draw.Create(link), Draw.Create(0)]
						m = [	Draw.String('Linked to: ', 	EVENT_D_D_LINK_UPDATE+index,	x+draw_x[0], 		y,	200,20, m[0].val, 15),\
									Draw.Toggle('Delete', 			EVENT_D_D_LINK_DELETE+index,	x+draw_x[1],		y,	80,	20, m[1].val, 'Remove this class from the list.') ]
						if bDup:
							glColor3f(1.0, 0.0, 0.0)
							glRecti(x+draw_x[0]-20, y+2, x+draw_x[0]-5, y+17)
							dup = 'Duplicate'
							lngth = Draw.GetStringWidth(dup)
							glRasterPos2i(x-lngth+draw_x[0]-25, y+5)
							Draw.Text(dup)
							
						linkMenu.append(m)
						n += 1
					y -= 20
					bAdd = Draw.PushButton('Add Link', EVENT_D_D_LINK_ADD,			x-140,	y, 280,20)
					sel = Object.GetSelected()
					if sel:
						if len(sel) > 1:
							y -= 20
							bAddBatch = Draw.PushButton('Link selected paths to active path', EVENT_D_D_LINK_SEL2ACT, x-140, y, 280, 20, "All selected (as in highlighted, but not active) paths will be added to the linked path list.")
							
					return x, y-20
				# First need to separate the lumped together version of this, if it is present
				global families, links
				global DUMMY_EXIT, DUMMY_LATCH, DUMMY_FAMILIES, DUMMY_UDA, DUMMY_LINKED, DOCK_ADD
				SITUAT_UPDATE = 0
				SITUAT_ADD = 1
				
				nSituat = SITUAT_UPDATE
				families = []
				links = []
				if actObj:
					props = actObj.getAllProperties()
					
					cleanseFam = []
					cleanseLink = []
					# Sort lists
					for p in props:
						# print p.name
						if p.name.startswith('dockFamilies'):
							if p.name == 'dockFamilies': p.name = 'dockFamilies0'
							if p.data != '':		cleanseFam.append(p)
							elif p.data == '':	actObj.removeProperty(p.name)
							
						elif p.name.startswith('linkedPaths'):
							if p.name == 'linkedPaths': p.name = 'linkedPaths0'
							if p.data != '':		cleanseLink.append(p)
							elif p.data == '':	actObj.removeProperty(p.name)
							
						elif p.name.startswith('dockFamily'):		families.append(p.data)
						elif p.name.startswith('linkedPath'):		links.append(p.data)
					
					if 'cleansing' in DEBUG:
						print "cleanse Us!"
						print "Families:",cleanseFam
						print "Links:",cleanseLink
					
					lenFam = len(cleanseFam)
					if lenFam > 0:
						familiesStr = ''
						# sort list by the number after dockFamilies
						if lenFam > 1:
							try:
								cleanseFam.sort( \
									lambda x,y: \
										cmp( \
											int(x.name[12:]),\
											int(y.name[12:]) ))
							except:
								print 'Contenst of cleanseFam',cleanseFam
								raise
						# Take knowledge and then burn the heretic!
						for cinder in cleanseFam:
							print cinder.name, cinder.data
							try:
								familiesStr = familiesStr + cinder.data
							except:		pass
							actObj.removeProperty(cinder.name)
						# Divy up the string into individual words
						breakdown = re.split(r'\w+', familiesStr)
						families = [br for br in breakdown if br.find(',') == -1 and br != '']
						# Add new, individual wrapped, properties
						for fam in families:
							actObj.addProperty('dockFamily'+str(n), fam, 'STRING')
							n += 1
					lenLink = len(cleanseLink)
					if lenLink > 0:
						linkStr = ''
						# sort list by the number after linkedPaths
						if len(cleanseLink) >= 2:
							try:
								cleanseLink.sort( \
									lambda x,y: \
										cmp( \
											int(x.name[11:]),\
											int(y.name[11:]) ))
							except:	
								print 'Contenst of cleanseLink', cleanseLink
								raise
						for cinder in cleanseLink:
							linkStr = linkStr + cinder.data
							actObj.removeProperty(cinder.name)
						breakdown = re.split(r'''\w+''', linkStr)
						pathList = [br for br in breakdown if br.find(',') == -1 and br != '']
						n = 1
						for path in pathList:		
							actObj.addProperty('linkedPath'+str(n), path, 'STRING')
							n += 1
				else:			nSituat = SITUAT_ADD
				# Menu for altering Ipo Dummy flags
				YN = ['No', 'Yes']
				
				Draw.BeginAlign()
				DUMMY_EXIT = Draw.Toggle('Exit Path: '+YN[DUMMY_EXIT.val], 		EVENT_D_D_EXIT, 	x-140, 	y, 175, 20, DUMMY_EXIT.val, "Set this path as an exit path.")
				DUMMY_LATCH = Draw.Toggle('Latch Path: '+YN[DUMMY_LATCH.val],	EVENT_D_D_LATCH,	x+35, 	y, 175, 20, DUMMY_LATCH.val, "This path is a latch path (i.e. the ship won't disappear/appear at the end of this path.")
				y -= 20;	
				DUMMY_UDA = Draw.Toggle('Use Dock Animation:'+YN[DUMMY_UDA.val],EVENT_D_D_UDA, 	x-140,	y, 350, 20, DUMMY_UDA.val, "Indicates if the docking MAD state will be triggered.")
				Draw.EndAlign()
				if 		nSituat == SITUAT_UPDATE:
					y -= 20; 	Draw.PushButton('Recalc Animation',					EVENT_D_UPDATE_FROMIPO, x-140,		y,350,	20);
					y -= 25;	DUMMY_FAMILIES = Draw.Toggle('Edit Dock Family List', EVENT_NONE, x-140, y, 350, 20, DUMMY_FAMILIES.val, 'Hide the list');
					if DUMMY_FAMILIES.val:
						x, y = __drawFAMILYMenu(x, y, actObj)
					else:
						string = ''
						if len(families) > 0:
							string = families[0]
							if len(families) > 1:
								for fam in families[1:]:	string = string + ', ' + fam
						
						if string == '':			string = 'None'
						y -= 15
						glColor3f(0, 1, 0.5)
						glRasterPos2i(x-140, y)
						Draw.Text(string)
						y -= 5
						
					y -= 22; 	DUMMY_LINKED = Draw.Toggle('Edit Linked Paths list', EVENT_NONE, x-140, y, 350, 20, DUMMY_LINKED.val);
					if DUMMY_LINKED.val:
						x, y = __drawLINKSMenu(x, y, actObj)
					else:
						string = ''
						if len(links) > 0:
							string = links[0]
							if len(links) > 1:
								for link in links[1:]:		string = string + ', ' + link
						if string == '':			string = 'None'
						y -= 15
						glColor3f(0, 0.5, 1)
						glRasterPos2i(x-140, y)
						Draw.Text(string)
						# y-= 5
				elif	nSituat == SITUAT_ADD:	pass
				return x, y
					
			def __drawStatus(		x=0, y=0, actObj=None):
				def __checkNodeFlags(basename): # [NOT DONE]
					'''This will check all other nodes in the path to see if there are some already set as queueOrigin or dropFocus points'''
					bValidOrigin = bValidDropFocus = bInvalidOrigin = False
					sOriginNode = sDropFocus = []
					n = 1
					nPostOrigin = 0
					try:		node = Object.Get( basename+'_key'+str(n) )
					except:	node = None
					while node:
						try:
							bOrigin = node.getProperty('queueOrigin').data
							if bOrigin:
								bValidOrigin = True
								sOriginNode.append(node.name)
								nPostOrigin = 1
						except:		pass
						if nPostOrigin:	nPostOrigin += 1
						try:
							bDropFocus = node.getProperty('dropFocus').data
							if bDropFocus:
								bValidDropFocus = True
								sDropFocus.append(node.name)
						except:
							pass
						n+= 1
						try:		node = Object.Get( basename+'_key'+str(n) )
						except:	node = None
					if bValidOrigin:
						if nPostOrigin < 2:
							bValidOrigin = False
							bInvalidOrgin = True
					return bValidOrigin, bInvalidOrigin, sOriginNode, bValidDropFocus, sDropFocus
				global DOCK_NAME
				try:
					dock = Object.Get(DOCK_NAME.val)
					bExists = True
				except ValueError:
					dock = None
					bExists = False
					
				if bExists:		Dcolor = 1,0,0;	DsUse = 'Used'
				else:					Dcolor = 0,1,0; DsUse = 'OK'
				# Node flag checker
				# warning label spacing
				ht = 10
				margin = 5
				spacing = 5
				
				if actObj:
					if actObj.name.find(DOCK_NAME.val) != -1:	Dcolor = 0, 0.5, 1; DsUse = 'Selected'
					
					y -= ht+margin+spacing
					glColor3f(Dcolor[0], Dcolor[1], Dcolor[2])
					glRecti(x-140, y-margin, x-140+Draw.GetStringWidth(DsUse)+2*margin, y+ht+margin)
					glColor3f(0.0, 0.0, 0.0)
					glRasterPos2i( x-140+margin, y+1 )
					Draw.Text(DsUse)
					
					bOrigin, bBadOrigin, sOrigin, bDF, sDF = __checkNodeFlags(DOCK_NAME.val)
					if bOrigin:
						if len(sOrigin) > 1:
							msg = '> Too many queue origins: '+sOrigin[0]
							for s in sOrigin[1:]:	msg = msg + ', ' + s
							glColor3f(1, 0, 0)
							y -= ht+spacing+spacing
							glRecti(x-140, y-margin-2, x-140+Draw.GetStringWidth(msg)+margin, y+ht+margin)
							glColor3f(0, 0, 0)
							glRasterPos2i(x-140+margin, y)
							Draw.Text(msg)
						else:
							if actObj.name not in sOrigin:
								msg = '> Queue Origin: '+sOrigin[0]
								
							else:		msg = '> Origin selected  '
							glColor3f(1, 0.5, 0)
							y -= ht+spacing+spacing
							glRecti(x-140, y-margin-2, x-140+Draw.GetStringWidth(msg)+margin, y+ht+margin)
														
							glColor3f(0, 0, 0)
							glRasterPos2i(x-140+margin, y)
							Draw.Text(msg)
					if bBadOrigin:
						msg = '> Invalid origin; need at least two (2) more nodes after this node.'
						glColor3f(1, 0, 0)
						y -= ht+spacing+spacing
						glRecti(x-140, y-margin, x-140+Draw.GetStringWidth(msg)+20, y+ht+margin)
						glColor3f(0, 0, 0)
						glRasterPos2i(x-140+margin, y)
						Draw.Text(msg)
				
				return x, y
			
			scn = Scene.GetCurrent()
			
			# CONSTANTS
			SITUAT_UPDATE = 0
			SITUAT_ADD = 1
			
			isPath = __getSubPathType(actObj)
			global SHOW_DOCK, DOCK_ADD, DOCK_NAME
			if SHOW_DOCK.val:
				if isPath[0]:
					DOCK_NODE 	= 3
					DOCK_CURVE 	= 6
					DOCK_DUMMY 	= 9
					SUB = 3*isPath[1] # To match up event number; 3 = NODE, 6 = CURVE, 9 = DUMMY
					
					if 		SUB == DOCK_NODE: 	DOCK_NAME.val = sel[0].name[:sel[0].name.find('_key')]
					elif 	SUB == DOCK_CURVE:	DOCK_NAME.val = sel[0].name[:sel[0].name.find('REFCURVE')]
					elif  SUB == DOCK_DUMMY:	DOCK_NAME.val = sel[0].name
					
					# else:	Blender.Draw.PupMenu("WARNING%t|Couldn't get pathname")
					# ipo = Object.Get(DOCK_NAME.val)
					# ipo.enableDupFrames = True
					
					x, y = __drawDOCKMenu(x, y, actObj)
					# status_x, status_y = x, y
					if 		SUB == DOCK_NODE:
						# Set the current values for Node flags.
						global	NODE_USEROT, NODE_POINTTOL, NODE_DROPFOCUS, NODE_MAXSPEED, \
										NODE_CHKROT, NODE_FCB, NODE_PIC, NODE_ORIGIN, NODE_UCP, NODE_ADVQ
						NODE_USEROT.val = actObj.getProperty('UseRot').data
						NODE_POINTTOL.val = actObj.size[0]
						NODE_DROPFOCUS.val = actObj.getProperty('DropFocus').data
						NODE_MAXSPEED.val = actObj.getProperty('MaxSpeed').data
						NODE_CHKROT.val = actObj.getProperty('checkRotation').data
						NODE_FCB.val = actObj.getProperty('forceCloseBehavior').data
						NODE_PIC.val = actObj.getProperty('playerInControl').data
						NODE_ORIGIN.val = actObj.getProperty('queueOrigin').data
						NODE_UCP.val = actObj.getProperty('useClipPlane').data
						NODE_ADVQ.val = actObj.getProperty('advanceQueue').data
						
						x, y = __drawNODEMenu(x, y, actObj)
					elif	SUB == DOCK_DUMMY:
						global DUMMY_EXIT, DUMMY_LATCH, DUMMY_UDA # Dock families is updated when activated.
						DUMMY_EXIT.val = actObj.getProperty('isExit').data
						DUMMY_LATCH.val = actObj.getProperty('isLatchPath').data
						DUMMY_UDA.val = actObj.getProperty('useDockAnimation').data
						x, y = __drawDUMMYMenu(x, y, actObj)
												
				else:
					y -= 20; DOCK_NAME = Draw.String('Name:',			EVENT_NONE,	x-140,	y, 280, 20,	DOCK_NAME.val, 21, 'Enter name for Dockpath');
					Draw.PushButton('', EVENT_NONE, x+140, y, 70, 40)
					nSituat = SITUAT_ADD
					for obj in scn.objects:
						if DOCK_NAME.val == obj.name:
							nSituat = SITUAT_UPDATE
							break
					
					if nSituat == SITUAT_ADD:
						DOCK_ADD = Draw.Toggle('Add', 				EVENT_DOCK,	x+140, 	y, 70, 40, 	DOCK_ADD.val, 'Add new dockpath to scene')
						x, y = __drawDUMMYMenu(x, y)
				y -= 2
				x, y = __drawStatus(x, y, actObj);
			return x, y-30
			
		def __drawMISC( x=0,	y=0, actObj=None):
			global vEXPORT_OBJ, vCOLOR_MESH, SHOW_MISC
			#ui_x,ui_y = (Blender.Window.GetAreaSize()[0]-230)/2, Blender.Window.GetAreaSize()[1]/2
			if SHOW_MISC.val:
				y-= 30
				if export_obj:
					vEXPORT_OBJ = Draw.Toggle('Export Wavefront (*.obj)', EVENT_MESH_EXPORT, x-140, y, 140, 30, vEXPORT_OBJ.val)
				else:
					Draw.PushButton('', EVENT_NONE, x-140, y, 140, 30, 'Unable to find "export_obj.py" in <'+Blender.Get('scriptsdir')+'>')
				if meshcolorizer:
					vCOLOR_MESH = Draw.Toggle('Colorize Meshes/Initialize Materials', EVENT_MESH_COLOR, x, y, 140,30, vCOLOR_MESH.val)
				else:
					Draw.PushButton('', EVENT_NONE, x, y, 140, 30, 'Unable to find "meshcolorizer.py" in <'+Blender.Get('scriptsdir')+'>'')
				
				return x, y-30
			else:	return x, y-30
			
		def __drawHSC(	x=0,	y=0	):
			global SHOW_HSC_OPS, vIMPORT_HSC, vEXPORT_HSC
			if SHOW_HSC_OPS.val:
				y -= 40
				if HSCImport:
					vIMPORT_HSC = Draw.Toggle('Import HSC', EVENT_HSC_IMPORT, x-140, y, 280, 40, vIMPORT_HSC.val)
				else:
					Draw.PushButton('Unable to find HSCImport.py in Blender scripts directory.', EVENT_NONE, x-140, y, 140, 40)
				y -= 40
				if EXPORT_HSC:
					vEXPORT_HSC = Draw.Toggle('Export HSC', EVENT_HSC_EXPORT, x-140, y, 280, 40, vEXPORT_HSC.val)
				else:
					Draw.PushButton('Unable to find EXPORT_HSC.PY in Blender scripts directory.', EVENT_NONE, x-140, y, 140, 40)
			y -= 30
			return x, y
		def __drawBUDGET(	x=0,	y=0 ):
			# Show bar with poly budgets for the various ship types, as well as a custom polybudget that can be set as well.
			# Should also have some sort of a progress bar to show how much of the budget has been used.
			global SHOW_BUDGET
			
			if SHOW_BUDGET.val:
				global BUDGET_TYPE, BUDGET_CUSTOM_BASE, BUDGET_CUSTOM_GOB, BUDGET_EXACT_FACES
				type = ['Subsystem', 'Fighter', 'Corvette', 'Frigate', 'Cruiser/Carrier', 'Mothership', 'Resources', 'Megaliths', 'Custom']
				base = [50, 660, 825, 1320, 1346, 1964, 300, 1964, BUDGET_CUSTOM_BASE.val]
				gob	 = [24, 165, 825, 1980, 2614, 3812, 0,	 3812, BUDGET_CUSTOM_GOB.val]
				
				menu = 'Poly Budget%t|Subsystem%x0|Fighter%x1|Corvette%x2|Frigate%x3|Cruiser/Carrier/Destroyer%x4|Mothership%x5|Resources%x6|Megaliths%x7|Custom%x8'
				y -= 20
				BUDGET_TYPE = Draw.Menu(menu,	EVENT_BUDGET, x-140, y, 280, 20, BUDGET_TYPE.val)
				if BUDGET_TYPE.val == 8: # Custom
					y -= 20
					BUDGET_CUSTOM_BASE= Draw.Number('Base:', EVENT_NONE, x-140, y, 100, 20, BUDGET_CUSTOM_BASE.val, 0, 99999, "Budget for the base mesh")
					BUDGET_CUSTOM_GOB	= Draw.Number('Goblin:', EVENT_NONE, x-40, y, 100, 20, BUDGET_CUSTOM_GOB.val, 0, 99999, "Budget for the goblin mesh")

				budget_base 		= base[BUDGET_TYPE.val]
				budget_goblin		= gob[BUDGET_TYPE.val]
				
				# Create a list of all meshes in scene
				scn = Scene.GetCurrent()
				meshes = [obj for obj in scn.objects if obj.type == 'Mesh']
				
				# Divide and sum goblins and base meshes (goblins having "goblin" or "goblins" somewhere in the name)
				goblins = 0
				bases = 0
				for m in meshes:
					data = m.getData(mesh=True)
					if Blender.Modifier.Types.MIRROR in m.modifiers:
						faces = 2*faces
					else:
						pass
					
					# Should it determine faces based on 
					faces = 0
					for face in data.faces:
						# print face.verts
						lVerts = len(face.verts)
						faces = faces + (lVerts / 3) + (lVerts % 3)
						
					# Sort according to mesh name
					if m.name.endswith('_$g') or m.name.lower().find('goblin') != -1:	
						goblins = goblins + faces
					else:
						bases = bases + faces
						

				# Under budget = green			(0.0, 1.0, 0.0)
				# Nearing budget = yellow	(1.0, 1.0, 0.0)
				# At budget = Orange				(1.0, 0.5, 0.0)
				# Beyond budget = red			(1.0, 0.0, 0.0)
				# print bases, goblins
				
				# Set bar color based on usage
				r,	g,	b 	= 0.0,0.0,0.0
				gr, gg, gb	= 0.0,0.0,0.0
				# print goblins, budget_goblin
				if budget_base > 0:		percent_base = float(bases)/float(budget_base)
				else:									percent_base = float(bases)/100.0
				if budget_goblin > 0:	percent_goblins = float(goblins)/float(budget_goblin)
				else:									percent_goblins = float(goblins)/100.0
				
				#print percent_base, percent_goblins
				
				# if 		0 <= percent_base < 0.33:
				r,g,b = percent_base, 1.0-percent_base,	0.0
				# elif 		0 <= percent_base < 0.33:	r,g,b = float(percent_base), 1.0-float(percent_base), 0.0
				# elif 		percent_base > 0.99:	r,g,b = 1.0, 0.0, 1.0-float(percent_base)
				#print r, g, b
				
				gr,gg,gb = percent_goblins, 1.0-percent_base, 0.0
				
				# Keep bars a manageable length
				margin = 3
				ht = 15
				spacing = 5
				bar_x = x-140
				bar_max = 280
				y -= ht+margin+spacing
				if percent_base <= 1.00:		base_width = int( math.floor(float(bar_max)*percent_base) )
				else:												base_width = bar_max
				
				if percent_goblins <= 1.00:	gob_width = int( math.floor(float(bar_max)*percent_goblins) )
				else:												gob_width = bar_max
				
				strBase = str(int(percent_base*100))+'%'
				BaseStrWidth = Draw.GetStringWidth(strBase)
				
				strGob = str(int(percent_goblins*100))+'%'
				GobStrWidth = Draw.GetStringWidth(strGob)
				
				glColor3f(r, g, b)
				glRecti(bar_x, y-margin, bar_x+base_width, y+ht+margin)
				
				glColor3f(0.0, 0.0, 0.0)
				glRasterPos2i(bar_x+base_width-BaseStrWidth, y+margin)
				Draw.Text(strBase)		# Shows percentage of budget used
				glColor3f(1.0, 1.0, 1.0)
				glRecti(bar_x+base_width, y-margin, bar_x+bar_max, y+ht+margin)
				glColor3f(1.0, 1.0, 1.0)
				glRasterPos2i(bar_x+bar_max+4, y+margin)
				Draw.Text(str(bases)+' / '+str(budget_base))	# Shows current number of faces / number of budgeted faces
				
				y -= ht+margin+spacing
				glColor3f(gr, gg, gb)
				glRecti(bar_x, y-margin, bar_x+gob_width, y+ht+margin)
				glColor3f(0.0, 0.0, 0.0)
				glRasterPos2i(bar_x+gob_width-GobStrWidth, y+margin)
				Draw.Text(strGob)			# Shows percentage of budget used
				glColor3f(1.0, 1.0, 1.0)
				glRecti(bar_x+gob_width, y-margin, bar_x+bar_max, y+ht+margin)
				glColor3f(1.0, 1.0, 1.0)
				glRasterPos2i(bar_x+bar_max+4, y+margin)
				Draw.Text(str(goblins)+' / '+str(budget_goblin))	# Shows current number of faces / number of budgeted faces
				
				return x, y
			else:	return x, y-30
		global SHOW_JOINT, SHOW_NAV, SHOW_MRKR, SHOW_DOCK, SHOW_HSC_OPS, SHOW_MISC, SHOW_BUDGET
		global ROOT_SIZE, ROOT_XRAY
		global NAV_NAME, MRKR_NAME
		global oldSel
		global NAV_NAME, NAV_COLOR, NAV_ALPHA, NAV_PHASE, NAV_FREQ, NAV_SIZE, NAV_ADD, NAV_VIS, NAV_LIT
		global JOINT_TYPE, JOINT_INDEX, JOINT_NAME, JOINT_SLAVE, JOINT_SINDEX, JOINT_SUB, JOINT_POS
		
		sel = Object.GetSelected()
		if sel:	actObj = sel[0]
		else: 	actObj = None
		
		if actObj != oldSel:
			if actObj:
				# Set options to reflect the selections settings
				if actObj.name.startswith('LA') and actObj.type == 'Lamp':	# [ Not Done ]
					SHOW_JOINT.val = SHOW_MRKR.val = SHOW_DOCK.val = 0
					SHOW_NAV.val = 1
					SHOW_JOINT.val = 0
					data = actObj.getData()
					
					NAV_NAME.val = actObj.name
					NAV_COLOR.val = data.R, data.G, data.B
					try:		NAV_ALPHA.val = actObj.getProperty('Alpha').data
					except:	pass				
					
					NAV_SIZE.val = actObj.size[0]
					try:		NAV_VIS.val = actObj.getProperty('isVisible').data
					except:	pass
					try:		NAV_LIT.val = actObj.getProperty('isLightSource').data
					except:	pass
					
					fps = Blender.Scene.GetCurrent().getRenderingContext().fps
					keyframes = []
					try:
						ipo = actObj.getIpo()
						points = ipo.curves[0].bezierPoints
						keyframes = [pt.pt[0] for pt in points]
					except: print "Couldn't retrieve Ipo data for active object"; ipo = None;
					
					if ipo and len(keyframes) > 1:
						if ipo: NAV_PHASE.val = keyframes[0]/fps
						else:
							try:		NAV_PHASE.val = actObj.getProperty('Phase').data
							except:	
								print "Couldn't get phase data for",actObj.name
								NAV_PHASE.val = 0
						
						if ipo: NAV_FREQ.val = (keyframes[1]-NAV_PHASE.val)/fps
						else:
							try:		NAV_FREQ.val = actObj.getProperty('Freq').data
							except:
								print "Couldn't get frequency data for", actObj.name
								NAV_FREQ.val = 0
					else:			NAV_FREQ.val = NAV_PHASE.val = 0
				oldSel = actObj
					
				if 	actObj.type == 'Empty' 						and \
				not actObj.name.startswith('marker') 	and \
				not actObj.name.startswith('path'):
					brkName = __breakName__(actObj)
					# print brkName, JOINT_NAME.val
					if brkName[0] != -1:	JOINT_TYPE.val 		= brkName[0]
					if brkName[1] != -1:	JOINT_INDEX.val 	= brkName[1]
					if brkName[2] != '':	JOINT_NAME.val 		= brkName[2]
					if brkName[3]:				JOINT_SLAVE.val 	= brkName[3]
					if brkName[4] !=  0:	JOINT_SINDEX.val	= brkName[4]
					if brkName[5] != -1:	JOINT_SUB.val 		= brkName[5]
					if brkName[6] != -1:	JOINT_POS.val 		= brkName[6]
					# type, index, name, subsys, subtype

		ui_x, ui_y = MENU_LOC
		Draw.BeginAlign()
		ROOT_SIZE = Draw.Slider('Root Size: ',		EVENT_R_SIZE, ui_x-140, ui_y, 250,	20, ROOT_SIZE.val, 0.001, 10.0, 1, 'Change Root size (Without affecting children)')
		ROOT_XRAY = Draw.Toggle('Always Show', 		EVENT_R_XRAY, ui_x+110, ui_y, 125,	20, ROOT_XRAY.val, "When active, the root joint will be drawn over all other objects.")
		Draw.EndAlign()
		ui_x, ui_y = ui_x, ui_y-40
		
		# JOINTS
		Draw.BeginAlign()
		SHOW_JOINT = Draw.Toggle('JOINTS (Shift+J)', EVENT_NONE, ui_x-140, ui_y, 280, 20, SHOW_JOINT.val, "Show/Hide Joint submenu.")
		ui_x, ui_y = __drawJOINT(ui_x, ui_y,	actObj)
		Draw.EndAlign()
		
		# NAVLIGHTS
		#Draw.BeginAlign()
		SHOW_NAV = Draw.Toggle('NAVLIGHTS (Shift+N)', EVENT_NONE, ui_x-140, ui_y, 280, 20, SHOW_NAV.val, "Show/Hide NavLight submenu.")
		if __isNavLight(actObj):	NAV_NAME.val = actObj.name
		ui_x, ui_y = __drawNAV(ui_x, ui_y, actObj)
		#Draw.EndAlign()
		
		# MARKERS
		Draw.BeginAlign()
		SHOW_MRKR = Draw.Toggle('MARKER (Shift+M)', EVENT_NONE, ui_x-140, ui_y, 280, 20, SHOW_MRKR.val, "Show/Hide Marker submenu.")
		if __isMarker(actObj):	MRKR_NAME.val = actObj.name
		ui_x, ui_y = __drawMRKR(ui_x, ui_y, actObj)
		Draw.EndAlign()
		
		# DOCKPATHS
		SHOW_DOCK = Draw.Toggle('DOCKPATHS (Shift+D)', EVENT_NONE, ui_x-140, ui_y, 280, 20, SHOW_DOCK.val, "Show/Hide Dockpath submenu.")
		ui_x, ui_y = __drawDOCK(ui_x, ui_y, actObj)
		
		# IMPORT/EXPORT HSC OPTIONS
		Draw.BeginAlign()
		SHOW_HSC_OPS = Draw.Toggle('HSC Import/Export', EVENT_NONE, ui_x-140, ui_y, 280, 20, SHOW_HSC_OPS.val, "Show/Hide HOD script options")
		ui_x, ui_y = __drawHSC(ui_x, ui_y)
		Draw.EndAlign()
		
		# MESHES
		Draw.BeginAlign()
		SHOW_MISC = Draw.Toggle('MISC', EVENT_NONE, ui_x-140, ui_y, 280, 20, SHOW_MISC.val, "Show/Hide Mesh options.")
		ui_x, ui_y = __drawMISC(ui_x, ui_y, actObj)
		Draw.EndAlign()
		
		# BUDGET display
		SHOW_BUDGET = Draw.Toggle('BUDGET', EVENT_NONE, ui_x-140, ui_y, 280, 20, SHOW_BUDGET.val, "Show/Hide poly budget diplay.")
		ui_x, ui_y = __drawBUDGET(ui_x, ui_y)
		
	def drawConfigMenu(x=0, y=0):	# [ Not Done ]
		'''Draw the configuration menu for the HOD Toolbox.'''
		def __writeConfigFile(filename): # [ Not Implemented ]
			global OPTION_orgGROUPS
			userCONFIGDIR = Blender.Get('udatadir')
			configFilename = 'HW2_HSC_GUI_config.ini'
			if not userCONFIGDIR:	userCONFIGDIR = Blender.Get('datadir')
			txtConfig = Blender.Text.Load( Blender.sys.join(userCONFIGDIR, configFilename) )
		global OPTION_GROUPS
		# Options to include:
		# Generate organizational groups; Method to of generating org groups for empty scenes: ['Prompt', 'Always', 'Never'] Menu
		# Use Organizational Groups - Y/N
		# Ask before renaming objects of a different type - Y/N (Toggle)
		# 
		# OPTION_orgGROUPS_label
		headers = ['Organization']
		YN = ['No', 'Yes']
		y -= 20
		glRasterPos2i(x+140, y); Draw.Text(headers[0]);
		l = len(headers[0])
		OPTION_GROUPS = Draw.Toggle('Use Groups '+YN[OPTION_GROUPS.val], EVENT_NONE, x+140, y, 340-l, 20, OPTION_GROUPS.val, 'Toggle the use of Blender groups to organize the various joints, navlights, markers and dockpaths.')
		if OPTION_GROUPS.val:
			y -= 20
			Draw.PushButton('Generate groups', EVENT_GENERATE_GROUPS, x+140, y, 120,	20, 'Generate organizational groups')
			
		y -= 30
		CONFIRM = Draw.PushButton('Save & Exit', EVENT_CONFIG_ACCEPT, x-140, y, 60, 20, 'Save changes and return to toolkit')
		CONFIRM_BUTSTAY = Draw.PushButton('Save', EVENT_CONFIG_SAVE, x-70, y, 60, 20, 'Save changes')
		CANCEL	= Draw.PushButton('Cancel & Exit', EVENT_CONFIG_CANCEL, x+80,	y, 60, 20, 'Ignore all changes and return to toolkit')
		
	glClearColor(0.0,0.0,0.25,1.0)                # define color used to clear buffers, also the background
	glClear(GL_COLOR_BUFFER_BIT)         					# use it to clear the color buffer
	# Get current selection
	sel = Object.GetSelected()
	
	if sel:
		actObj = sel[0]
		type = actObj.type
	else:
		type = None
		actObj = None
	#ui_x, ui_y = 0, GLOBALS['AREA_MAX'][1]
	isPath = __getSubPathType(actObj)
	# Set subheading
	DOCK_SUB = [' - Node', ' - Reference Curve', ' - Ipo Dummy', ''] # A value of -1 will return a blank subheading
	subhead = ''
	if isPath[0]: 				subhead = 'Path' + DOCK_SUB[isPath[1]]
	elif type == 'Mesh':	subhead = type
	
	# Initialize Option locations
	global MENU_LOC
	XCENTER = Blender.Window.GetAreaSize()
	XCENTER = XCENTER[0]/2, XCENTER[1]
	maxX, maxY = XCENTER
	
	ui_x, ui_y = drawHEADER(maxX, maxY, subhead)
	
	MENU_LOC = ui_x, ui_y
	
	# __LocBox__(x,y)
	drawMenu()
	
def menu():              # the function to draw the screen
	def writeConfigFile():											# [ Not Done ]
		configFilename = 'HW2_HSC_GUI_config.ini'
		userCONFIGDIR = Blender.Get('udatadir')
		if not userSCRIPTSDIR:	userCONFIGDIR = Blender.Get('datadir')
		
		try: 										txtConfig = Blender.Text.Load( Blender.sys.join(userSCRIPTSDIR, configFilename) )
		except AttributeError:	txtConfig = None
		
		if txtConfig:
			pass
	def loadConfigFile():												# [ Not Done ]
		configFilename = 'HW2_HSC_GUI_config.ini'
		userCONFIGDIR = Blender.Get('udatadir')
		if not userSCRIPTSDIR:	userCONFIGDIR = Blender.Get('datadir')
		configFilename = Blender.sys.join(userSCRIPTSDIR, configFilename)
		try: 										txtConfig = Blender.Text.Load( configFilename )
		except AttributeError:	txtConfig = Blender.Text.New( configFilename )
		
		if txtConfig:
			# Display toggles
			global SHOW_JOINT, SHOW_NAV, SHOW_MRKR, SHOW_DOCK, SHOW
	if True:
		global vIMPORT_HSC, vEXPORT_HSC, vEXPORT_OBJ, vCOLOR_MESH
		global SHOW_JOINT, SHOW_NAV, SHOW_MRKR, SHOW_DOCK, SHOW_HSC_OPS, SHOW_MISC, SHOW_BUDGET
		global BUDGET_TYPE, BUDGET_CUSTOM_BASE, BUDGET_CUSTOM_GOB, BUDGET_EXACT_FACES
		global ADD_JOINT
		global TYPE, SUBTYPE, SLAVE, POSITION
		global JOINT_TYPE, JOINT_SUB, JOINT_INDEX, JOINT_NAME, JOINT_SLAVE, JOINT_SINDEX, JOINT_POS
		global JOINT, JOINT_BASENAME, JOINT_BLENDNAME							# Holds the joint name info
		global NAV_NAME, NAV_COLOR, NAV_ALPHA, NAV_PHASE, NAV_FREQ, NAV_SIZE, NAV_ADD, NAV_VIS, NAV_LIT
		global NAV # holds the complete navlight name
		global MRKR_ADD, MRKR_NAME
		global DOCK_NAME, DOCK_ADD, DOCK_UPDATE_FROM, DOCK_SHOWFRAMES, DOCK_FRAMEOFFSET, DOCK_NODE_ADD_METHOD, DOCK_NODE_ADD, DOCK_UPDATE_METHOD
		global oldSel
		global DUMMY_EXIT, DUMMY_LATCH, DUMMY_LINKED, DUMMY_UDA, DUMMY_FAMILIES
		global NODE_USEROT, NODE_POINTTOL, NODE_DROPFOCUS, NODE_MAXSPEED, NODE_CHKROT, NODE_FCB, 	NODE_PIC, NODE_ORIGIN, NODE_UCP, NODE_ADVQ
		global XOff, YOff, ZOff
		global NAV_UPDATE_METHOD
		global ROOT_SIZE, ROOT_XRAY
		global OPTION_GROUPS
		global bDon_TReHide
		global families, links, familyMenu, linkMenu
		# global MENU_LOC 
		
		vIMPORT_HSC = Draw.Create(0)
		vEXPORT_HSC = Draw.Create(0)
		
		vEXPORT_OBJ = Draw.Create(0)
		vCOLOR_MESH = Draw.Create(0)
		
		# Display Toggles
		SHOW_JOINT 	= Draw.Create(1)
		SHOW_NAV 		= Draw.Create(1)
		SHOW_MRKR 	= Draw.Create(1)
		SHOW_DOCK 	= Draw.Create(1)
		SHOW_HSC_OPS = Draw.Create(0)
		SHOW_MISC		= Draw.Create(0)
		SHOW_BUDGET	= Draw.Create(1)
		
		BUDGET_TYPE = Draw.Create(0)
		BUDGET_CUSTOM_BASE = Draw.Create(100)
		BUDGET_CUSTOM_GOB	 = Draw.Create(50)
		BUDGET_EXACT_FACES = Draw.Create(0)
		
		ADD_JOINT = Draw.Create(0)
		
		TYPE = 'Joint Format%t|Weapon%x0|HardPoint%x1|Repair Point%x2|Capture Point%x3|Custom%x4'
		SUBTYPE = 'Hardpoint Type%t|Generic%x0|Production%x1|Sensor%x2|System%x3|Engine%x4|Resource%x5'
		SLAVE = ['','$SL'] # If isSlave is true then this will be $SL
		POSITION = ['Weapon Positions%t|Position%x0|Latitude%x1|Muzzle%x2',\
								'Hardpoint Positions%t|Position%x0',\
								'Repair Position%t|Position%x0',\
								'Capture Position%t|Position%x0',\
								'Custom Positions%t|Position%x0|Latitude%x1|Muzzle%x2|None%x3']
		
		
		JOINT_TYPE = Draw.Create(0)
		JOINT_SUB = Draw.Create(0)
		JOINT_INDEX = Draw.Create(0)
		JOINT_NAME = Draw.Create('joint')
		JOINT_SLAVE = Draw.Create(0)
		JOINT_SINDEX = Draw.Create(0)
		JOINT_POS = Draw.Create(0)
		
		
		JOINT = JOINT_BASENAME = JOINT_BLENDNAME = '','',''
		

		NAV_NAME = Draw.Create('NavLightNew')
		#NAV_DEX = Draw.Create(0)
		NAV_COLOR = Draw.Create(1.0,0.25,0.0)
		NAV_ALPHA = Draw.Create(1.0)
		NAV_PHASE = Draw.Create(0.0)
		NAV_FREQ = Draw.Create(0.0)
		NAV_SIZE = Draw.Create(5.0)
		NAV_ADD = Draw.Create(0)
		NAV_VIS = Draw.Create(1)
		NAV_LIT = Draw.Create(0)
		
		NAV = NAV_NAME.val
		# if NAV_DEX.val >= 0:
			# NAV = NAV_NAME.val+str(NAV_DEX.val)
		# else:
			# NAV = NAV_NAME.val
		
		MRKR_NAME = Draw.Create('marker')
		MRKR_ADD	= Draw.Create(0)
		
		DOCK_NAME 						= Draw.Create('path1')
		DOCK_ADD 							= Draw.Create(0)
		DOCK_UPDATE_FROM 			= Draw.Create(0)
		
		sel = Object.GetSelected()
		if sel: b = sel[0].enableDupFrames; oldSel = sel[0]
		else:		b = False; oldSel = None
		DOCK_SHOWFRAMES				= Draw.Create( b )
		DOCK_FRAMEOFFSET			= Draw.Create(0)
		DOCK_NODE_ADD_METHOD	= Draw.Create(1)
		DOCK_NODE_ADD 				= Draw.Create(0)
		DOCK_UPDATE_METHOD 		= Draw.Create(0)
		
		DUMMY_EXIT			= Draw.Create(0)
		DUMMY_LATCH			= Draw.Create(0)
		DUMMY_LINKED		= Draw.Create(0)
		DUMMY_UDA 			= Draw.Create(0)
		DUMMY_FAMILIES	= Draw.Create(0)
		
		NODE_USEROT			= Draw.Create(0)
		NODE_POINTTOL		= Draw.Create(10)
		NODE_DROPFOCUS	= Draw.Create(0)
		NODE_MAXSPEED 	= Draw.Create(0)
		NODE_CHKROT			= Draw.Create(0)
		NODE_FCB				= Draw.Create(0)
		NODE_PIC				= Draw.Create(0)
		NODE_ORIGIN			= Draw.Create(0)
		NODE_UCP				= Draw.Create(0)
		NODE_ADVQ				= Draw.Create(0)
		
		XOff = Draw.Create(0.0)
		YOff = Draw.Create(0.0)
		ZOff = Draw.Create(0.0)
		
		NAV_UPDATE_METHOD = Draw.Create(0)
		
		ROOT_SIZE = Draw.Create(Object.Get('Root').drawSize)
		ROOT_XRAY = Draw.Create(0)
		
		OPTION_GROUPS = Draw.Create(0)
		
		bDon_TReHide = False
		families		= []
		links 			= []
		familyMenu	= []
		linkMenu		= []
		
		# MENU_LOC = 0, 0

	sel = Object.GetSelected()
	if sel:	actObj = sel[0]
	else:		actObj = None
	
	#__makeOptions__()		
	Draw.Register(draw_ui, ui_ev, button_ev)
	
if __name__ == '__main__':
	menu()