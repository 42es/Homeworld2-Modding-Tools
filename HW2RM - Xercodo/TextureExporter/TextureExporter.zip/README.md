# HW-Texture-Exporter
Exports GIMP layers as TGA with no RLE compression with naming convention [name]_[layer].tga

Installation: Place the .py in your C:\Program Files\GIMP 2\lib\gimp\2.0\plug-ins folder
