# HWRM-Texture-Processor
GIMP Plug-in. Takes a GLOW.dds or TEAM.dds (or both if loaded as layers) and breaks them apart into their 6 source maps.

Installation: Place the .py in your C:\Program Files\GIMP 2\lib\gimp\2.0\plug-ins folder
