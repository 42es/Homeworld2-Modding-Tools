This file will extract the 3D mesh out of homeworld .PEO file. 
You need to use the BIG viewer to get the PEO file.
Open the PEO file with PEON and press the process button.
You will find a shipfile.RAW file in your directory.
This file can then be converted into any 3D format using the 3D conversion
tool of your choice (eg:Wcvt2pov). You can then play with the mesh.
Design modified ships etc.

Later version of PEON will let you import a mesh into the PEO file
for NEW LOOK SHIPS.

Thanks go to Relic for excellent program, Lachesis_atatata for the BIG file
format and his helpful posts (btw: check out his amazing model viewer!).

My email is: wulfius@bigfoot.com you can email me to tell me 
how big my dick is. Before you email any questions check 
http://www.crosswinds.net/~wulfius/homeworld.
I will have any updates to PEON there.

If you find any bugs email me too.

Limitations:
At the moment, the program will only work with PEO files which contain
one object. This is a proof of concept program and it will evolve.

I play online as WULFIUS-KHAN
---

In Australia (where I live) as of 1,Jan 2000 Internet is under more regulation
that in Saudi Arabia, Burma and Singapore (traditionaly very consorous).
This happened because people are too apathetic.
If you think that this could not happen where you live (US,Europe) you are
wrong, thats what we thought in Australia. 
Stay informed visit WWW.EFA.ORG.AU