
This file contains the modifications done 
  to the homeworld .big file viewer.

bugs:
 -The viewer would try to uncompress a file even 
   when the file wasn't compressed.

added:
 -Ability to save all files in a directory structure.
   (only available in the menu).
 -Save will now save to the same directory structure 
   under the homeworld directory. (the directories 
   will be created if needed)
 -Menus 
 -Save will now confirm before overwriting a file. 
   (except when saving a directory structure).
 -About dialog
 -Hints on status bar