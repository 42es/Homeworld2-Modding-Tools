
This file contains the modifications done 
  to the homeworld .big file viewer.

added:
 -Ability to view .lif .jpg and .bmp graphics.
 -When saving recursively, the status bar displays the 
   current directory being saved.
