To all!

			This is NOT a BETA !!

  I have kept the name the same so that people's links won't have to change.

  You should uninstall any earlier copy of QE.

  This new version has thumb support..no real function but will add a personal touch to your modding as you can create thumbs of the units you are editing.

  Have fun and drop by the web sites for up to date info.

  PS the QE web site will be updated 04/18/00 late pm pacific time ...

  Same for the HWES site.

  Thanks !

  To beta testors.. thanks all and thanks to those in the forum who gave feed back. If I forgot your name in the credits let me know and what you did and I'll put you in. I had so much feedback it was hard to keep track.


							Yours truly:  Prime_8