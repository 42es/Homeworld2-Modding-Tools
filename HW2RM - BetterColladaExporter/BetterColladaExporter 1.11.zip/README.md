# HW Remastered Toolkit for Blender
Blender add-on for creating content for Homeworld: Remastered.

Contains a fork of the Godot Engine Better Collada Exporter for Blender that exports DAE files compatible with the HODOR tools, and automated creation tools for ship hardpoints and LOD nodes. 



Better Collada Exporter Originally Created and Copyright by Juan Linietsky (juan@codenix.com)

HW Edition fork created by David Lejeune (daffydlejeune42@hotmail.com). I claim no copyright to this version.

Joint Tools contributed by Dominic Cassidy (drache9335@gmail.com).
