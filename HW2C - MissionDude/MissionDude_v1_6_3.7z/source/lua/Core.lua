iStartPoints, iPoints, iSpheres, iCameras, iSquadrons, iAsteroids, iSalvage, iPebbles, iClouds, iDustClouds, iNebulas, iDirLights, iRvAsteroids, iRvSquadrons = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

function appendShape(tPos, i, tPar, j, tCoo, tRot)
	tCoo = vaddV(vrotate(tCoo, tRot), tPos)
	if (tPar[2] == "Point") then
		local name = tPar[3]
		if (tPar[1] > 1) then
			name = name .. "_" .. j
		end
		addPoint(name, vaddV(tCoo, tPar[4]), tPar[5])
		iPoints = iPoints + 1
	elseif (tPar[2] == "StartPoint") then
		local name = "StartPos" .. iStartPoints
		addPoint(name, vaddV(tCoo, tPar[4]), tPar[5])
		iStartPoints = iStartPoints + 1					
	elseif (tPar[2] == "Sphere") then
		local name = tPar[3]
		if (tPar[1] > 1) then
			name = name .. "_" .. j
		end
		addSphere(name, vaddV(tCoo, tPar[4]), tPar[5])
		iSpheres = iSpheres + 1
	elseif (tPar[2] == "Camera") then
		local name = tPar[3]
		if (tPar[1] > 1) then
			name = name .. "_" .. j
		end
		addCamera(name, tPar[5], vaddV(tCoo, tPar[4]))
		iCameras = iCameras + 1
	elseif (tPar[2] == "Squadron") then
		local name = tPar[3]
		if (tPar[1] > 1) then
			name = name .. "_" .. j
		end
		addSquadron(name, tPar[4], vaddV(tCoo, tPar[5]), tPar[6], tPar[7], tPar[8], tPar[9])
		iSquadrons = iSquadrons + 1
	elseif (tPar[2] == "Asteroid") then
		addAsteroid(tPar[3], vaddV(tCoo, tPar[4]), tPar[5], tPar[6], tPar[7], tPar[8], tPar[9])
		iAsteroids = iAsteroids + 1
	elseif (tPar[2] == "Salvage") then
		addSalvage(tPar[3], vaddV(tCoo, tPar[4]), tPar[5], tPar[6], tPar[7], tPar[8], tPar[9])
		iSalvage = iSalvage + 1
	elseif (tPar[2] == "Pebble") then
		addPebble(tPar[3], vaddV(tCoo, tPar[4]), tPar[5], tPar[6], tPar[7])
		iPebbles = iPebbles + 1
	elseif (tPar[2] == "Cloud") then
		local name = tPar[3]
		if (tPar[1] > 1) then
			name = name .. "_" .. j
		end
		addCloud(name, tPar[4], vaddV(tCoo, tPar[5]), tPar[6], tPar[7], tPar[8])
		iClouds = iClouds + 1
	elseif (tPar[2] == "DustCloud") then
		local name = tPar[3]
		if (tPar[1] > 1) then
			name = name .. "_" .. j
		end
		addDustCloud(name, tPar[4], vaddV(tCoo, tPar[5]), tPar[6], tPar[7], tPar[8])
		iDustClouds = iDustClouds + 1
	elseif (tPar[2] == "Nebula") then
		local name = tPar[3]
		if (tPar[1] > 1) then
			name = name .. "_" .. j
		end
		addNebula(name, tPar[4], vaddV(tCoo, tPar[5]), tPar[6], tPar[7], tPar[8])
		iNebulas = iNebulas + 1
	elseif (tPar[2] == "DirLight") then
		local name = tPar[3]
		if (tPar[1] > 1) then
			name = name .. "_" .. j
		end
		createDirLight(name, vaddV(tCoo, tPar[4]), tPar[5])
		setLightSpecular(name, tPar[6])
		iDirLights = iDirLights + 1
	elseif (tPar[2] == "RvSquadron") then
		addReactiveFleetSlot(tPar[5], tPar[6], tPar[7], vaddV(tCoo, tPar[4]), tPar[8], tPar[9], tPar[10], tPar[3])
		iRvSquadrons = iRvSquadrons + 1
	elseif (tPar[2] == "RvAsteroid") then
		addReactiveFleetResourceSlot(tPar[3], vaddV(tCoo, tPar[4]), tPar[5], tPar[6], tPar[7])
		iRvAsteroids = iRvAsteroids + 1
	elseif (tPar[2] == "Coordinate") then
		tinsert(tPar[3], tCoo)
	elseif (tPar[2] == "Function") then
		if (tPar[7] == nil) then
			tPar[7] = {0,0,0,}
		end
		local nfour = tPar[4]
		if tPar[3] ~= literalAdd then
			nfour = vaddV(tCoo, tPar[4])
		end
		tPar[3](nfour, tPar[5], tPar[6], vaddV(tRot, tPar[7]))
	end
end

function addSOBGroup(sSobName, ...)
	createSOBGroup(sSobName)
	for i = 1, getn(arg) do
		addToSOBGroup(arg[i], sSobName)
	end
end

function doAllSOBGroups(ttable)
	for sobgname, sobgarray in ttable do
		for j = 1, getn(sobgarray) do
			if sobgarray[j][4] == 0 then
				if sobgarray[j][2] == 1 then
					addToSOBGroup(sobgarray[j][1], sobgname)
				else
					for k = 1, sobgarray[j][2] do
						addToSOBGroup(sobgarray[j][1] .. "_" .. k, sobgname)
					end
				end
			end
		end
	end
end

function literalAdd(tDst)
	for i, tTab in tDst do
		for j = 1, tTab[1] do
			appendShape({0, 0, 0,}, i, tTab, j, {0, 0, 0,}, {0, 0, 0,})
		end
	end
end

function randomMusic(iMod, tTab, iLen, sDir)
	local ranNum, musDir, musTrk = 0, "", ""
	local musTab =
	{
		"amb_01", "amb_02", "amb_03", "amb_04", "amb_05", "amb_06", "amb_07", "amb_08", "amb_09", "amb_10", "amb_11", "amb_12", "amb_13", "amb_14",
		"battle_01", "battle_04", "battle_04_alt", "battle_06", "battle_keeper", "battle_movers", "battle_planetkillers", "battle_sajuuk", "bentus_arrival",
	}
	if ((iMod == 4) or (iMod == 5)) then
		for k = 1, iLen do
			musTab[k + 23] = tTab[k]
		end
	end
	if (iMod == 1) then
		ranNum = random(1, 14)
	elseif (iMod == 2) then
		ranNum = random(15, 23)
	elseif (iMod == 3) then
		ranNum = random(1, 23)
	elseif (iMod == 4) then
		ranNum = random(24, 23 + iLen)
	elseif (iMod == 5) then
		ranNum = random(1, 23 + iLen)
	end
	if (ranNum <= 14) then
		musDir = "data:sound\\music\\ambient\\"
	elseif (ranNum <= 23) then
		musDir = "data:sound\\music\\battle\\"
	elseif (ranNum <= (23 + iLen)) then
		musDir = sDir
	end
	if (iMod ~= 0) then
		setDefaultMusic(musDir .. musTab[ranNum])
	end
end

function randomBackground(iMod, tTab, iLen)
	local ranNum = 0
	local backgroundTable =
	{
		"m01", "m02", "m03", "m04", "m05", "m06", "m07", "m08", "m09", "m10", "m11", "m12", "m13", "m14", "m15",
		"planet", "quick", "singlesun", "tanis", "taniswstars", "black", "white",
	}
	if ((iMod == 4) or (iMod == 5)) then
		for k = 1, iLen do
			backgroundTable[k + 22] = tTab[k]
		end
	end
	if (iMod == 1) then
		ranNum = random(1, 15)
	elseif (iMod == 2) then
		ranNum = random(16, 22)
	elseif (iMod == 3) then
		ranNum = random(1, 22)
	elseif (iMod == 4) then
		ranNum = random(23, 22 + iLen)
	elseif (iMod == 5) then
		ranNum = random(1, 23 + iLen)
	end
	if (iMod ~= 0) then
		loadBackground(backgroundTable[ranNum])
	end
end

function randomSign()
	if (random() > 0.5) then
		return 1
	else
		return -1
	end
end

function randomBit()
	if (random() > 0.5) then
		return 1
	else
		return 0
	end
end

function random2(fVal1, fVal2)
	if (fVal2) then
		if ((fVal2 - fVal1) == 0) then
			return fVal2
		else
			return random(fVal1, fVal2)
		end
	elseif (fVal1) then
		if (fVal1 == 0) then
			return 0
		else
			return random(fVal1)
		end
	else
		return random()
	end
end

function random3(fVal1, fVal2)
	if (fVal2) then
		return fVal1 + random() * (fVal2 - fVal1)
	elseif (fVal1) then
		return random() * fVal1
	else
		return random()
	end
end

function vaddV(tVec1, tVec2)
	local tmpVec = {}
	for i, tTab in tVec2 do
		tmpVec[i] = tVec1[i] + tTab
	end
	return tmpVec
end

if not getn then
	function getn(tTable)
		local nCount = 0
		for i, iCount in tTable do
			if i ~= "n" then
				nCount = nCount + 1
			end
		end
		return nCount
	end
end

if not tinsert then
	function tinsert(tTable, Arg1, Arg2)
		if (Arg2) then
			local TempTable = {}
			for i = Arg1, getn(tTable) do
				TempTable[i + 1] = tTable[i]
			end
			for i = Arg1, getn(tTable) do
				tTable[i + 1] = TempTable[i + 1]
			end
			tTable[Arg1] = Arg2
		else
			tTable[getn(tTable) + 1] = Arg1
		end
	end
end

function vrotate(tVec, tAng)
	tVec =
	{
		tVec[1] * cos(tAng[3]) - tVec[2] * sin(tAng[3]),
		tVec[1] * sin(tAng[3]) + tVec[2] * cos(tAng[3]),
		tVec[3],
	}
	tVec =
	{
		tVec[1],
		tVec[2] * cos(tAng[1]) - tVec[3] * sin(tAng[1]),
		tVec[2] * sin(tAng[1]) + tVec[3] * cos(tAng[1]),
	}
	tVec =
	{
		tVec[1] * cos(tAng[2]) + tVec[3] * sin(tAng[2]),
		tVec[2],
		-1 * tVec[1] * sin(tAng[2]) + tVec[3] * cos(tAng[2]),
	}
	return tVec
end
