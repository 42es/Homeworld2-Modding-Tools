function branchAdd(tPos, tDst, tPar, tRot, lastRad, countDiv, countFrq, lastPos)
	local tCoo, thisPos, nextPos = {}, {}, tPos
	local tDiv, tInt, tFrq, tBeg, tEnd, tRad, tLen, tThk, tAng, iMod = tPar[1], tPar[2], tPar[3], tPar[4], tPar[5], tPar[6], tPar[7], tPar[8], tPar[9], tPar[10]
	local tiltDeg, spinDeg = tRot[3], tRot[2]
	local minRad, maxRad, minDist, maxDist, minThck, maxThck = tRad[1], tRad[2], tLen[1], tLen[2], 1 - tThk[1]/100, 1 - tThk[2]/100
	local minAng, maxAng, minBeg, maxBeg, minEnd, maxEnd = tAng[1], tAng[2], tBeg[1], tBeg[2], tEnd[1], tEnd[2]
	local minDiv, maxDiv, minInt, maxInt, minFrq, maxFrq = tDiv[1], tDiv[2], tInt[1], tInt[2], tFrq[1], tFrq[2]
	local numSeg, numInt, numDiv, numBeg, numEnd, numFrq = 0, 0, 0, 0, 0, 0
	if (lastRad == nil) then
		lastRad = maxRad
	end
	if (countDiv == nil) then
		countDiv = 1
	end
	if (countFrq == nil) then
		countFrq = maxFrq
	else
		countFrq = countFrq - 1
	end
	if (lastPos == nil) then
		lastPos = tPos
	end
	local thisRad = sqrt(lastRad^2/countDiv)
	if (iMod == 0) then
		numInt, numDiv, numBeg, numEnd, numFrq = maxInt, minDiv, maxBeg, maxEnd, maxFrq
	else
		numInt, numDiv, numBeg, numEnd, numFrq = random2(minInt, maxInt), random2(minDiv, maxDiv), random2(minBeg, maxBeg), random2(minEnd, maxEnd), random2(minFrq, maxFrq)
	end
	if (numBeg > 0) then
		numSeg = numBeg
	elseif (numFrq > 0) then
		numSeg = numInt
	elseif (numEnd > 0) then
		numSeg = numEnd
	end
	for k = 1, numSeg do
		local rad, len, thk, angY, angZ = 0, 0, 0, 0, 0
		if (iMod == 0) then
			local sign1, sign2 = randomSign(), randomSign()
			rad, len, angY, angZ = maxRad, maxDist, sign1 * maxAng, sign2 * maxAng
		elseif (iMod == 1) then
			local sign1, sign2, narrw = randomSign(), randomSign(), random3(0.9, 1)
			thisRad = thisRad * narrw
			thk, rad, len, angY, angZ = random3(minThck, maxThck) * narrw, thisRad, maxDist - (maxDist - minDist)/(numFrq + 1), random3(minAng, maxAng) * sign1, random3(minAng, maxAng) * sign2
		elseif (iMod == 2) then
			local sign1, sign2 = randomSign(), randomSign()
			thk, rad, len, angY, angZ = random3(minThck, maxThck), random3(minRad, maxRad), random3(minDist, maxDist), random3(minAng, maxAng) * sign1, random3(minAng, maxAng) * sign2
		end
		tiltDeg, spinDeg = tiltDeg + angZ, spinDeg + angY
		thisPos = nextPos
		nextPos = vaddV(thisPos, vrotate({len, 0, 0,}, {0, spinDeg, tiltDeg,}))
		for i, tTab in tDst do
			local Volume1, Volume2 = PI * maxRad^2 * maxDist, PI * len * (rad^2 - (rad * thk)^2)
			local Density = Volume2/Volume1
			local iNum, gradX = floor(tTab[1] * Density + 0.5), len
			for j = 1, iNum do
				if (iMod == 0) then
					tCoo = {gradX, 0, 0,}
					appendShape(thisPos, i, tTab, j, tCoo, {tRot[1], spinDeg, tiltDeg,})
				elseif (iMod == 3) then
					local t, thisCtl, nextCtl = random(), vaddV(thisPos, vsubtractV(thisPos, lastPos)), vsubtractV(nextPos, vsubtractV(nextPos, thisPos))
					local A1_x, A1_y, A1_z = thisPos[1], thisPos[2], thisPos[3]
					local A2_x, A2_y, A2_z = thisCtl[1], thisCtl[2], thisCtl[3]
					local B1_x, B1_y, B1_z = nextPos[1], nextPos[2], nextPos[3]
					local B2_x, B2_y, B2_z = nextCtl[1], nextCtl[2], nextCtl[3]
					tCoo[1] = (B1_x + 3 * A2_x - 3 * B2_x - A1_x) * t^3 + (3 * B2_x - 6 * A2_x + 3 * A1_x) * t^2 + (3 * A2_x - 3 * A1_x) * t + A1_x 
					tCoo[2] = (B1_y + 3 * A2_y - 3 * B2_y - A1_y) * t^3 + (3 * B2_y - 6 * A2_y + 3 * A1_y) * t^2 + (3 * A2_y - 3 * A1_y) * t + A1_y 
					tCoo[3] = (B1_z + 3 * A2_z - 3 * B2_z - A1_z) * t^3 + (3 * B2_z - 6 * A2_z + 3 * A1_z) * t^2 + (3 * A2_z - 3 * A1_z) * t + A1_z 
					appendShape(thisPos, i, tTab, j, tCoo, tRot)
				elseif (iMod == 2) then
					local r, v, h = random3(rad * thk, rad), random3(360), random3(len)
					tCoo = {h, r * cos(v), r * sin(v),}
					appendShape(thisPos, i, tTab, j, tCoo, {tRot[1], spinDeg, tiltDeg,})
				elseif (iMod == 1) then
					local r, v, h = random3(rad * thk, rad), random3(360), random3(len)
					tCoo = {h, r * cos(v), r * sin(v),}
					appendShape(thisPos, i, tTab, j, tCoo, {tRot[1], spinDeg, tiltDeg,})
				end
				gradX = gradX - len/iNum
			end
		end
		lastPos = thisPos
	end
	if (numBeg > 0) then
		tBeg = {0, 0,}
		branchAdd(nextPos, tDst, {tDiv, tInt, tFrq, tBeg, tEnd, tRad, tLen, tThk, tAng, iMod,}, tRot, nil, nil, nil, thisPos)
	elseif (numFrq > 0) then
		if (minFrq >= numFrq) then
			minFrq = numFrq - 1
		end
		tFrq = {minFrq, numFrq - 1,}
		for j = 1, numDiv do
			branchAdd(nextPos, tDst, {tDiv, tInt, tFrq, tBeg, tEnd, tRad, tLen, tThk, tAng, iMod,}, tRot, thisRad, numDiv, countFrq, thisPos)
		end
	elseif (numEnd > 0) then
		tDiv, tInt, tFrq, tEnd = {0, 0,}, {0, 0,}, {0, 0,}, {0, 0,}
		branchAdd(nextPos, tDst, {tDiv, tInt, tFrq, tBeg, tEnd, tRad, tLen, tThk, tAng, iMod,}, tRot, thisRad, numDiv, countFrq, thisPos)
	end
end

function vsubtractV(tVec1, tVec2)
	local tmpVec = {}
	for i, tTab in tVec2 do
		tmpVec[i] = tVec1[i] + tTab
	end
	return tmpVec
end
