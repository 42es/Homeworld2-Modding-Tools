Cataclysm Custom Map

====================
Creator: [Your Name]
E-Mail Address:  [your emai]

Map Name:  [Name of your Map]
File Name:  [Name of the zip file of your Map]
Version:  1.0 (18 March 2000) [update as needed]
Created With:  [whatever you used be it 'MissionMan' or 'Excel' and 'TextPad v.4.2.0' etc]
====================

Background Storyline and/or Comments:

[Whatever further info on the map you wish to impart here.]

[Name of the Backgroud/Lighting creator here]

*************

This map has been designed for [ie: 'a FFA bash for up to 8 players' or '2v2 Teams' etc.]

In order to play this may, unzip it into your SIERRA\Cataclysm\Multiplayer folder. It should
have [Number of folders here] folders named [the folder names] plus this text file. If you
have properly placed the folders, Cataclysm will automatically recognize this map on startup
when you select Multiplayer maps.
