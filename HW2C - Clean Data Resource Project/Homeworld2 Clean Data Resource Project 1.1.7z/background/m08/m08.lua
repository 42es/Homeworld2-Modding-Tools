-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:06:33
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
lensflares = 
{ 
    lensflare0 = 
    { 
        name = "M06_Flare", 
        position = 
            { 48.2699, 10.1222, -86.9917, }, 
        infinite = 1, }, }
