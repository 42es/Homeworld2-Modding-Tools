-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:06:13
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
fx = 
{ 
    style = "STYLE_COMBO", 
    properties = 
    { 
        property_06 = 
        { 
            name = "FX7", 
            type = "VARTYPE_STRING", 
            value = "super_beam_07_nis", }, 
        property_05 = 
        { 
            name = "FX6", 
            type = "VARTYPE_STRING", 
            value = "super_beam_06_nis", }, 
        property_07 = 
        { 
            name = "FX8", 
            type = "VARTYPE_STRING", 
            value = "super_beam_08_nis", }, 
        property_02 = 
        { 
            name = "FX3", 
            type = "VARTYPE_STRING", 
            value = "super_beam_03_nis", }, 
        property_01 = 
        { 
            name = "Fx2", 
            type = "VARTYPE_STRING", 
            value = "super_beam_02_nis", }, 
        property_04 = 
        { 
            name = "FX5", 
            type = "VARTYPE_STRING", 
            value = "super_beam_05_nis", }, 
        property_03 = 
        { 
            name = "FX4", 
            type = "VARTYPE_STRING", 
            value = "super_beam_04_nis", }, 
        property_00 = 
        { 
            name = "Fx1", 
            type = "VARTYPE_STRING", 
            value = "super_beam_01_nis", }, }, }
