-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:06:01
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
fx = 
{ 
    style = "STYLE_COMBO", 
    properties = 
    { 
        property_06 = 
        { 
            name = "FX7", 
            type = "VARTYPE_STRING", 
            value = "", }, 
        property_05 = 
        { 
            name = "FX6", 
            type = "VARTYPE_STRING", 
            value = "DMG_CAPITAL_EXPLOSION_COMBO_PLANET_KILLER", }, 
        property_07 = 
        { 
            name = "FX8", 
            type = "VARTYPE_STRING", 
            value = "", }, 
        property_02 = 
        { 
            name = "FX3", 
            type = "VARTYPE_STRING", 
            value = "PLANETKILLER_ABOMB_RING03", }, 
        property_01 = 
        { 
            name = "Fx2", 
            type = "VARTYPE_STRING", 
            value = "PLANETKILLER_ABOMB_RING02", }, 
        property_04 = 
        { 
            name = "FX5", 
            type = "VARTYPE_STRING", 
            value = "planetkiller_abomb_ring05", }, 
        property_03 = 
        { 
            name = "FX4", 
            type = "VARTYPE_STRING", 
            value = "planetkiller_abomb_ring04", }, 
        property_00 = 
        { 
            name = "Fx1", 
            type = "VARTYPE_STRING", 
            value = "PLANETKILLER_ABOMB_RING01", }, }, }
