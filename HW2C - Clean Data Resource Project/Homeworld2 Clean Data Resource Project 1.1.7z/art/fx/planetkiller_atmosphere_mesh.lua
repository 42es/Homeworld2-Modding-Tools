-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:06:01
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
fx = 
{ 
    style = "STYLE_RING", 
    properties = 
    { 
        property_28 = 
        { 
            name = "PointDistance", 
            type = "VARTYPE_FLOAT", 
            value = -1, }, 
        property_27 = 
        { 
            name = "DepthOffset", 
            type = "VARTYPE_FLOAT", 
            value = 0, }, 
        property_26 = 
        { 
            name = "SortOrder", 
            type = "VARTYPE_INT", 
            value = 0, }, 
        property_25 = 
        { 
            name = "RandomBitmap", 
            type = "VARTYPE_BOOL", 
            value = 0, }, 
        property_24 = 
        { 
            name = "BirthSpawn_Fx", 
            type = "VARTYPE_STRING", 
            value = "", }, 
        property_23 = 
        { 
            name = "Spawn_Fx", 
            type = "VARTYPE_STRING", 
            value = "", }, 
        property_22 = 
        { 
            name = "Mesh", 
            type = "VARTYPE_STRING", 
            value = "DATA:ART/FX/PLANETKILLER_ATMOSPHERE/PKM_BURN.HOD", }, 
        property_21 = 
        { 
            name = "Texture", 
            type = "VARTYPE_STRING", 
            value = "Data:art/fx/point.tga", }, 
        property_11 = 
        { 
            name = "SpinRandom", 
            type = "VARTYPE_BOOL", 
            value = 0, }, 
        property_15 = 
        { 
            name = "UseDepthSort", 
            type = "VARTYPE_BOOL", 
            value = 0, }, 
        property_18 = 
        { 
            name = "Billboard", 
            type = "VARTYPE_BOOL", 
            value = 0, }, 
        property_17 = 
        { 
            name = "AlternateFOV", 
            type = "VARTYPE_BOOL", 
            value = 0, }, 
        property_16 = 
        { 
            name = "Loop", 
            type = "VARTYPE_BOOL", 
            value = 1, }, 
        property_19 = 
        { 
            name = "SelfIlluminated", 
            type = "VARTYPE_BOOL", 
            value = 0, }, 
        property_09 = 
        { 
            name = "SpinEpsilonY", 
            type = "VARTYPE_FLOAT", 
            value = 0, }, 
        property_04 = 
        { 
            name = "SpinZ", 
            type = "VARTYPE_ARRAY_TIMEFLOAT", 
            value = 
                { 0, 0, 1, 0, }, }, 
        property_03 = 
        { 
            name = "SpinY", 
            type = "VARTYPE_ARRAY_TIMEFLOAT", 
            value = 
                { 0, 0, 1, 0, }, }, 
        property_06 = 
        { 
            name = "RadiusEpsilon", 
            type = "VARTYPE_FLOAT", 
            value = 0, }, 
        property_05 = 
        { 
            name = "Colour", 
            type = "VARTYPE_ARRAY_TIMECOLOUR", 
            value = 
            { 
                entry_00 = 
                    { 0, 0.29245, 0.29245, 0.29245, 1, }, 
                entry_01 = 
                    { 0.14328, 0.19811, 0.19811, 0.19811, 1, }, 
                entry_02 = 
                    { 0.1806, 0.39623, 0.39623, 0.39623, 1, }, 
                entry_03 = 
                    { 0.19701, 0.27358, 0.27358, 0.27358, 1, }, 
                entry_04 = 
                    { 0.52239, 0.42453, 0.42453, 0.42453, 1, }, 
                entry_05 = 
                    { 0.64925, 0.35938, 0.35938, 0.35938, 1, }, 
                entry_06 = 
                    { 0.6597, 0.24528, 0.24528, 0.24528, 1, }, 
                entry_07 = 
                    { 0.76716, 0.33019, 0.33019, 0.33019, 1, }, 
                entry_08 = 
                    { 1, 0.17925, 0.17925, 0.17925, 1, }, }, }, 
        property_08 = 
        { 
            name = "SpinEpsilonX", 
            type = "VARTYPE_FLOAT", 
            value = 0, }, 
        property_07 = 
        { 
            name = "RateEpsilon", 
            type = "VARTYPE_FLOAT", 
            value = 1, }, 
        property_02 = 
        { 
            name = "SpinX", 
            type = "VARTYPE_ARRAY_TIMEFLOAT", 
            value = 
                { 0, 0, 1, 0, }, }, 
        property_01 = 
        { 
            name = "Offset", 
            type = "VARTYPE_ARRAY_TIMEVECTOR3", 
            value = 
            { 
                entry_00 = 
                    { 0, 0, 0, 0, }, 
                entry_01 = 
                    { 1, 0, 0, 0, }, }, }, 
        property_13 = 
        { 
            name = "UseMesh", 
            type = "VARTYPE_BOOL", 
            value = 1, }, 
        property_14 = 
        { 
            name = "UseDepthTest", 
            type = "VARTYPE_BOOL", 
            value = 0, }, 
        property_20 = 
        { 
            name = "Blending", 
            type = "VARTYPE_INT", 
            value = 2, }, 
        property_12 = 
        { 
            name = "Duration", 
            type = "VARTYPE_FLOAT", 
            value = 0.5, }, 
        property_00 = 
        { 
            name = "Radius", 
            type = "VARTYPE_ARRAY_TIMEFLOAT", 
            value = 
                { 0, 1, 1, 1, }, }, 
        property_10 = 
        { 
            name = "SpinEpsilonZ", 
            type = "VARTYPE_FLOAT", 
            value = 0, }, }, }
