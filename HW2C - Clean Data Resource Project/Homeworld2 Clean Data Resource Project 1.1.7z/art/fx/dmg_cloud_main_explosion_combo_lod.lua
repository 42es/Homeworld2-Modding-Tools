-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:05:12
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
fx = 
{ 
    style = "STYLE_COMBO", 
    properties = 
    { 
        property_06 = 
        { 
            name = "FX7", 
            type = "VARTYPE_STRING", 
            value = "", }, 
        property_05 = 
        { 
            name = "FX6", 
            type = "VARTYPE_STRING", 
            value = "", }, 
        property_07 = 
        { 
            name = "FX8", 
            type = "VARTYPE_STRING", 
            value = "", }, 
        property_02 = 
        { 
            name = "FX3", 
            type = "VARTYPE_STRING", 
            value = "", }, 
        property_01 = 
        { 
            name = "Fx2", 
            type = "VARTYPE_STRING", 
            value = "dmg_ripers_ring_small", }, 
        property_04 = 
        { 
            name = "FX5", 
            type = "VARTYPE_STRING", 
            value = "DMG_SPHERE_HALO", }, 
        property_03 = 
        { 
            name = "FX4", 
            type = "VARTYPE_STRING", 
            value = "dmg_capital_flash_ring", }, 
        property_00 = 
        { 
            name = "Fx1", 
            type = "VARTYPE_STRING", 
            value = "DMG_CAPITAL_CLOUD_SPRAY_LOD", }, }, }
