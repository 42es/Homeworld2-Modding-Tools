-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:04:52
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
type = "TRAIL"
radius = 8
scarProbability = 1
shallowAngleDeg = 80
minScarDist = 5
minExtendDist = 10
maxExtendDist = 100
fxProbability = 0.05
batchRender = 1
dashOverDot = 1
dotTextures = 
    { "IonBeam/Ion_point.tga", "IonBeam/Ion_point2.tga", }
dashTextures = 
    { "IonBeam/Ion_length.tga", "IonBeam/Ion_length2.tga", "IonBeam/Ion_length3.tga", "IonBeam/Ion_length4.tga", }
fxs = {}
transitionFXs = {}
