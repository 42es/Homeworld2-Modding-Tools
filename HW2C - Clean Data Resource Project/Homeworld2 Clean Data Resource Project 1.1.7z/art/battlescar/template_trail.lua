-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:04:52
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
type = "TRAIL"
radius = 6
scarProbability = 1
shallowAngleDeg = 80
minScarDist = 9
minExtendDist = 6
maxExtendDist = 12
batchRender = 1
dashOverDot = 0
dotTextures = 
    { "burn_dot.tga", }
dashTextures = 
    { "burn_dash.tga", }
fxProbability = 0.05
fxs = 
    { "smoke_loop_spray", }
transitionFXs = {}
