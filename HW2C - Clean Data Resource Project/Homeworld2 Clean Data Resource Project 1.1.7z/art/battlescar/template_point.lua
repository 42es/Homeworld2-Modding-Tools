-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:04:52
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
TO_Random = 0
TO_ShipAligned = 1
type = "POINT"
version = 2
radius = 6
scarProbability = 1
shallowAngleDeg = 80
minScarDist = 5
textureOrient = TO_Random
textures = 
    { 
        { "hole1.tga", 1, }, 
        { "hole2.tga", 2, }, 
    }
fxProbability = 0.75
fxs = 
    { "smoke_loop_spray", "cloud_ring_combo", }
