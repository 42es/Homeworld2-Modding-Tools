-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:06:49
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
teamcolours = 
{ 
    0 = 
        { 
            { 0.365, 0.553, 0.667, }, 
            { 0.8, 0.8, 0.8, }, "DATA:Badges/Hiigaran.tga", 
            { 0.365, 0.553, 0.667, }, "data:/effect/trails/hgn_trail_clr.tga", }, 
    1 = 
        { 
            { 1, 0.494, 0, }, 
            { 1, 0.494, 0, }, "DATA:Badges/Hiigaran.tga", 
            { 0.365, 0.553, 0.667, }, "data:/effect/trails/hgn_trail_clr.tga", }, 
    2 = 
        { 
            { 0.752, 0.694, 0.556, }, 
            { 1, 1, 1, }, "DATA:Badges/Hiigaran.tga", 
            { 0.365, 0.553, 0.667, }, "data:/effect/trails/hgn_trail_clr.tga", }, 
    3 = 
        { 
            { 0.9, 0.9, 0.9, }, 
            { 0.1, 0.1, 0.1, }, "DATA:Badges/Vaygr.tga", 
            { 0.921, 0.75, 0.419, }, "data:/effect/trails/vgr_trail_clr.tga", }, }
