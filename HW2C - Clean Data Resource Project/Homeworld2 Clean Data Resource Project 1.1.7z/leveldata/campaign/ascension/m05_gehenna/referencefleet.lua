-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:07:47
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
Fleet = 
    { 
    { 
        Type = "Hgn_MotherShip", 
        Number = 1, }, 
    { 
        Type = "Hgn_Carrier", 
        Number = 1, }, 
    { 
        Type = "Hgn_ResourceCollector", 
        Number = 8, }, 
    { 
        Type = "Hgn_Interceptor", 
        Number = 5, }, 
    { 
        Type = "Hgn_AttackBomber", 
        Number = 1, }, 
    { 
        Type = "Hgn_AttackBomberElite", 
        Number = 1, }, 
    { 
        Type = "Hgn_AssaultCorvette", 
        Number = 2, }, 
    { 
        Type = "Hgn_PulsarCorvette", 
        Number = 2, }, 
    { 
        Type = "Hgn_ResourceController", 
        Number = 1, }, 
    { 
        Type = "Hgn_MarineFrigate", 
        Number = 1, }, 
    { 
        Type = "Hgn_MinelayerCorvette", 
        Number = 1, }, 
    { 
        Type = "Hgn_AssaultFrigate", 
        Number = 3, }, 
    { 
        Type = "Hgn_TorpedoFrigate", 
        Number = 2, }, 
    }
RUs = 2000
