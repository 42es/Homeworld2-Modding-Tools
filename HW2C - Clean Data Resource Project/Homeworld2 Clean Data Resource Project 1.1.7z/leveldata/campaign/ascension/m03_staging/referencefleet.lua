-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:07:13
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
Fleet = 
    { 
    { 
        Type = "Hgn_Mothership", 
        Number = 1, }, 
    { 
        Type = "Hgn_ResourceCollector", 
        Number = 3, }, 
    { 
        Type = "Hgn_Interceptor", 
        Number = 7, }, 
    { 
        Type = "Hgn_AttackBomber", 
        Number = 4, }, 
    { 
        Type = "Hgn_AttackBomberElite", 
        Number = 2, }, 
    { 
        Type = "Hgn_AssaultCorvette", 
        Number = 5, }, 
    }
RUs = 229
