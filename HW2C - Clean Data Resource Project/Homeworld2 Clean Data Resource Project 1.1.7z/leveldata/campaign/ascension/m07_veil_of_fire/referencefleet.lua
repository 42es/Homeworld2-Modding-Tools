-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:08:19
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
Fleet = 
    { 
    { 
        Type = "Hgn_Mothership", 
        Number = 1, }, 
    { 
        Type = "Hgn_ResourceCollector", 
        Number = 16, }, 
    { 
        Type = "Hgn_Interceptor", 
        Number = 4, }, 
    { 
        Type = "Hgn_AssaultCorvette", 
        Number = 1, }, 
    { 
        Type = "Hgn_PulsarCorvette", 
        Number = 1, }, 
    { 
        Type = "Hgn_TorpedoFrigate", 
        Number = 4, }, 
    { 
        Type = "Hgn_IonCannonFrigate", 
        Number = 4, }, 
    { 
        Type = "Hgn_Carrier", 
        Number = 1, }, 
    { 
        Type = "Hgn_ResourceController", 
        Number = 2, }, 
    }
RUs = 1000
