-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:07:47
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
Dictionaries = 
    { 
    { 
        name = "locale:leveldata/campaign/ascension/m06_karos.dat", }, 
    }
