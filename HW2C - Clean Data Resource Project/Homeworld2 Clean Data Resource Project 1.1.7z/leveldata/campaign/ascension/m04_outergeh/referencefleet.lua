-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:07:30
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
Fleet = 
    { 
    { 
        Type = "Hgn_Mothership", 
        Number = 1, }, 
    { 
        Type = "Hgn_Carrier", 
        Number = 1, }, 
    { 
        Type = "Hgn_ResourceCollector", 
        Number = 10, }, 
    { 
        Type = "Hgn_ResourceController", 
        Number = 1, }, 
    { 
        Type = "Hgn_Interceptor", 
        Number = 4, }, 
    { 
        Type = "Hgn_AttackBomber", 
        Number = 4, }, 
    { 
        Type = "Hgn_AttackBomberElite", 
        Number = 2, }, 
    { 
        Type = "Hgn_AssaultCorvette", 
        Number = 5, }, 
    { 
        Type = "Hgn_PulsarCorvette", 
        Number = 5, }, 
    { 
        Type = "Hgn_MarineFrigate", 
        Number = 1, }, 
    { 
        Type = "Hgn_AssaultFrigate", 
        Number = 5, }, 
    }
RUs = 2000
multiplierForExtraRU = 0.1
