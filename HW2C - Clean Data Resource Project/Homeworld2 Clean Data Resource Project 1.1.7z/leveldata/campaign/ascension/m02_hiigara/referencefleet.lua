-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:06:56
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
Fleet = 
    { 
    { 
        Type = "Sp_Tanker", 
        Number = 6, }, 
    { 
        Type = "Hgn_Mothership", 
        Number = 1, }, 
    { 
        Type = "Hgn_ResourceCollector", 
        Number = 1, }, 
    { 
        Type = "Hgn_Interceptor", 
        Number = 3, }, 
    { 
        Type = "Hgn_AttackBomber", 
        Number = 2, }, 
    }
RUs = 1300
