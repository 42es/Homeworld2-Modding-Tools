-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:08:37
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
Fleet = 
    { 
    { 
        Type = "Hgn_Mothership", 
        Number = 1, }, 
    { 
        Type = "Hgn_ResourceCollector", 
        Number = 15, }, 
    { 
        Type = "Hgn_Interceptor", 
        Number = 3, }, 
    { 
        Type = "Hgn_AttackBomber", 
        Number = 5, }, 
    { 
        Type = "Hgn_AssaultCorvette", 
        Number = 6, }, 
    { 
        Type = "Hgn_PulsarCorvette", 
        Number = 6, }, 
    { 
        Type = "Hgn_Carrier", 
        Number = 1, }, 
    { 
        Type = "Hgn_Destroyer", 
        Number = 2, }, 
    { 
        Type = "Hgn_ResourceController", 
        Number = 2, }, 
    { 
        Type = "Kpr_Mover", 
        Number = 10, }, 
    { 
        Type = "Hgn_Dreadnaught", 
        Number = 1, }, 
    }
RUs = 2000
