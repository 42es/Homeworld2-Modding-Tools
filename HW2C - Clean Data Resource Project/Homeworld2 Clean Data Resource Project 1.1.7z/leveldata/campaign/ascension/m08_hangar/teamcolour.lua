-- LuaDC version 0.9.20
-- 2006/10/20 �U�� 09:08:30
-- LuaDC by Age2uN
-- on error send source file (compiled lua) and this outputfile to Age2uN@gmx.net
--
teamcolours = 
{ 
    0 = 
        { 
            { 0.365, 0.553, 0.667, }, 
            { 0.8, 0.8, 0.8, }, "DATA:Badges/Hiigaran.tga", }, 
    1 = 
        { 
            { 0, 0.925, 0.521, }, 
            { 0.1, 0.1, 0.1, }, "DATA:Badges/Vaygr.tga", }, }
