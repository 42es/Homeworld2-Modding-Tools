--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopEnd = 62208 
envelope = {
	{distance = 0, volume = 0.43, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 104.166664, volume = 0.35, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.91, 0.81, 0.55, 0.4},},
	{distance = 222.916672, volume = 0.205, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.8, 0.79, 0.69, 0.62, 0},},
	{distance = 383.333344, volume = 0.125, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.91, 0.72, 0.55, 0.4, 0},},
	{distance = 1191.666626, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.46, 0.49, 0.54, 0.4, 0},},} 
randSampContainer = 0 

