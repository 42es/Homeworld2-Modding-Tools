--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 2048 
loopEnd = 103936 
envelope = {
	{distance = 0, volume = 0.87, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 925, volume = 0.88, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 0.79, 0.56, 0.37},},
	{distance = 2100, volume = 0.75, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.9, 0.61, 0.41, 0.32, 0},},
	{distance = 3783.333252, volume = 0.36, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.67, 0.47, 0.31, 0, 0},},
	{distance = 6075, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

