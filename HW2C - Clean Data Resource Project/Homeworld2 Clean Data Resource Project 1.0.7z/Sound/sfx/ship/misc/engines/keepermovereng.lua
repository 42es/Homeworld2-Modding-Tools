--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 29184 
loopEnd = 57856 
envelope = {
	{distance = 0, volume = 0.445, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 133.333328, volume = 0.395, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.75, 0.55, 0.86, 0.91},},
	{distance = 450, volume = 0.19, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.96, 0.95, 0.74, 0.36, 0.32},},
	{distance = 808.333313, volume = 0.14, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.61, 0.25, 0, 0, 0},},
	{distance = 1366.666626, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 0.77, 0.45, 0.16, 0, 0, 0},},} 
randSampContainer = 0 

