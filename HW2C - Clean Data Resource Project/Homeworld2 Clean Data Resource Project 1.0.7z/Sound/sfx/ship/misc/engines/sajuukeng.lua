--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 83712 
loopEnd = 143104 
envelope = {
	{distance = 0, volume = 0.905, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 1083.333374, volume = 0.865, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 0.79, 0.25},},
	{distance = 2466.666748, volume = 0.68, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.71, 0.61, 0.42, 0.26},},
	{distance = 3441.666748, volume = 0.47, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.72, 0.47, 0.32, 0.21, 0.1},},
	{distance = 4725, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 0.79, 0.66, 0.25, 0.02, 0, 0},},} 
randSampContainer = 0 

