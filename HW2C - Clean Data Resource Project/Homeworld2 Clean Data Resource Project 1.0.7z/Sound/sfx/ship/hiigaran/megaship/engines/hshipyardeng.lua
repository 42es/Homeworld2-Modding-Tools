--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
volume = 0.9 
loopStart = 215552 
loopEnd = 305152 
envelope = {
	{distance = 0, volume = 0.83, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 450, volume = 0.795, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 1083.333374, volume = 0.56, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.39, 0.45, 0.44, 0.4, 0.37},},
	{distance = 1658.333374, volume = 0.355, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.51, 0, 0, 0, 0},},
	{distance = 4008.333252, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.51, 0, 0, 0, 0},},} 
randSampContainer = 0 

