--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 157696 
loopEnd = 300544 
envelope = {
	{distance = 0, volume = 0.72, reverb = 1, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 1225, volume = 0.525, reverb = 1, duration = 0, equalizer = {1, 1, 1, 1, 1, 0.82, 0.62, 0.35},},
	{distance = 2291.666748, volume = 0.36, reverb = 0, duration = 0, equalizer = {0.44, 0.55, 0.62, 1, 0.59, 0.4, 0.25, 0.21},},
	{distance = 4333.333496, volume = 0.24, reverb = 0, duration = 0, equalizer = {0.5, 0.67, 0.72, 0.79, 0.4, 0.2, 0.09, 0},},
	{distance = 5825, volume = 0, reverb = 0, duration = 0, equalizer = {0.55, 0.67, 0.72, 0.32, 0.15, 0, 0, 0},},} 
randSampContainer = 0 

