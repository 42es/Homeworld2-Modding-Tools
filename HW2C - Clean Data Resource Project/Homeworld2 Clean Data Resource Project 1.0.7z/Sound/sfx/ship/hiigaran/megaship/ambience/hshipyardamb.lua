--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 1536 
envelope = {
	{distance = 0, volume = 0.685, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 0.51, 0},},
	{distance = 691.666687, volume = 0.64, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.95, 1, 0.56, 0.1},},
	{distance = 1458.333374, volume = 0.265, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.91, 0.64, 0.09, 0, 0},},
	{distance = 2125, volume = 0.07, reverb = 0, duration = 0, equalizer = {1, 1, 0.75, 0.55, 0.17, 0, 0, 0},},
	{distance = 3591.666748, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 0.75, 0.55, 0.17, 0, 0, 0},},} 
randSampContainer = 0 

