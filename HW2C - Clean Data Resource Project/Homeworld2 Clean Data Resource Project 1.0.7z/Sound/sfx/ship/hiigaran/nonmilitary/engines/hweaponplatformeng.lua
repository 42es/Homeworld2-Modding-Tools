--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
envelope = {
	{distance = 0, volume = 0.505, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 110.416664, volume = 0.29, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.62, 0.26, 0.14, 0.1, 0},},
	{distance = 227.083328, volume = 0.18, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.56, 0.27, 0.05, 0},},
	{distance = 452.083344, volume = 0.125, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 0.6, 0.45, 0.14},},
	{distance = 725, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0, 0, 0, 0},},} 
randSampContainer = 0 

