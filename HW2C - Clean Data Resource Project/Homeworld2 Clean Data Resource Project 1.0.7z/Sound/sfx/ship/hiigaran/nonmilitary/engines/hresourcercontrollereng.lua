--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
volume = 0.89 
loopStart = 124416 
loopEnd = 226560 
envelope = {
	{distance = 0, volume = 0.375, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 175, volume = 0.355, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 283.333344, volume = 0.185, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.7, 0.46, 0.35, 0.12},},
	{distance = 600, volume = 0.085, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.42, 0, 0, 0, 0.12},},
	{distance = 1583.333374, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 0.72, 0.22, 0, 0, 0, 0},},} 
randSampContainer = 0 

