--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
envelope = {
	{distance = 0, volume = 0.58, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 38.541668, volume = 0.32, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 100, volume = 0.195, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.72, 0.55, 0.37, 0.29, 0},},
	{distance = 214.583328, volume = 0.1, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.32, 0, 0, 0, 0},},
	{distance = 711.458313, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 0.49, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

