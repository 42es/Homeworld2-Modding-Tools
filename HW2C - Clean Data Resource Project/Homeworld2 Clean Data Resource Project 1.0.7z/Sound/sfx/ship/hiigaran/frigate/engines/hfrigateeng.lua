--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
volume = 0.65 
maxPolyphony = 1 
loopStart = 198656 
loopEnd = 372736 
envelope = {
	{distance = 0, volume = 0.65, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 258.333344, volume = 0.635, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.79, 0.57, 0.52, 0.49},},
	{distance = 591.666687, volume = 0.325, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.87, 0.31, 0.39, 0.26, 0.26},},
	{distance = 1425, volume = 0.22, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.61, 0, 0, 0},},
	{distance = 1900, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.64, 0, 0, 0, 0},},} 
randSampContainer = 0 

