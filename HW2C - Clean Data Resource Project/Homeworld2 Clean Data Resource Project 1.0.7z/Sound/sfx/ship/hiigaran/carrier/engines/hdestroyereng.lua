--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 136192 
loopEnd = 224768 
envelope = {
	{distance = 0, volume = 0.495, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 441.666656, volume = 0.48, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.34, 0.25, 0.16, 0.1},},
	{distance = 841.666687, volume = 0.315, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.32, 0.16, 0, 0},},
	{distance = 1475, volume = 0.135, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.52, 0, 0, 0, 0},},
	{distance = 2658.333252, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.42, 0, 0, 0, 0},},} 
randSampContainer = 0 

