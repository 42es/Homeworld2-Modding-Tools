--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 2560 
loopEnd = 72704 
envelope = {
	{distance = 0, volume = 0.645, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 208.333328, volume = 0.535, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.34, 0.25, 0.16, 0.1},},
	{distance = 533.333313, volume = 0.235, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.8, 0.74, 0.7, 0.74},},
	{distance = 1125, volume = 0.13, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.52, 0.52, 0.45, 0.42, 0.4},},
	{distance = 2016.666626, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.42, 0, 0, 0, 0},},} 
randSampContainer = 0 

