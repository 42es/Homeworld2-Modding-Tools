--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
volume = 1 
envelope = {
	{distance = 0, volume = 0.54, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 250, volume = 0.4, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.76, 0.44, 0.47, 0.41, 0},},
	{distance = 466.666656, volume = 0.16, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.59, 0.4, 0.31, 0, 0},},
	{distance = 1991.666626, volume = 0.12, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.42, 0.28, 0, 0, 0},},
	{distance = 2450, volume = 0, reverb = 0, duration = 0, equalizer = {1, 0.82, 0.32, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

