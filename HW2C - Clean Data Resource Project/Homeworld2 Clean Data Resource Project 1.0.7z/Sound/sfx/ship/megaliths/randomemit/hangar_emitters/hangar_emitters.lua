--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
envelope = {
	{distance = 0, volume = 0.42, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 38.020832, volume = 0.34, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.87, 0.76, 0.41, 0},},
	{distance = 122.395836, volume = 0.205, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.7, 0.56, 0.31, 0},},
	{distance = 205.729172, volume = 0.14, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.5, 0.49, 0, 0},},
	{distance = 450, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0, 0, 0, 0},},} 
container = 0 
playlist = 1 
randContainer = 1 
loopingPlaylist = 1 
silenceBreak = 2 
silenceRandom = 8 
randSampContainer = 1 

