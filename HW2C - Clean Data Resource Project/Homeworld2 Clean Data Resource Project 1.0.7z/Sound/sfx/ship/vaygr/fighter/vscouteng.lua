--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 118784 
loopEnd = 197632 
envelope = {
	{distance = 0, volume = 0.425, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 183.333328, volume = 0.39, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.71, 0.61, 0.14, 0.1},},
	{distance = 325, volume = 0.23, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.52, 0.17, 0.06, 0, 0},},
	{distance = 733.333313, volume = 0.115, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.09, 0, 0, 0, 0},},
	{distance = 1200, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 0, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

