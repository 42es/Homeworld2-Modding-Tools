--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
volume = 0.8 
loopStart = 167424 
loopEnd = 310272 
envelope = {
	{distance = 0, volume = 0.91, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 241.666672, volume = 0.85, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.99, 1, 0.71, 0.37},},
	{distance = 850, volume = 0.525, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.91, 0.76, 0.71, 0.57, 0},},
	{distance = 1625, volume = 0.26, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.81, 0.64, 0.55, 0, 0},},
	{distance = 4941.666504, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 0.77, 0.4, 0, 0, 0, 0},},} 
randSampContainer = 0 

