--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
envelope = {
	{distance = 0, volume = 0.81, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 416.666656, volume = 0.395, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.79, 0.69, 0.41, 0.51},},
	{distance = 866.666687, volume = 0.28, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.49, 0.16, 0, 0},},
	{distance = 1700, volume = 0.125, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.55, 0.25, 0, 0, 0},},
	{distance = 3716.666748, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 0.61, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

