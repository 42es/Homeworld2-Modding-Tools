--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
volume = 0.4 
loopStart = 5632 
loopEnd = 155904 
envelope = {
	{distance = 0, volume = 0.18, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 57.291668, volume = 0.155, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.77, 0.54, 0.39, 0.27},},
	{distance = 172.916672, volume = 0.135, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.31, 0.19, 0.06, 0},},
	{distance = 312.5, volume = 0.09, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.44, 0.31, 0, 0, 0},},
	{distance = 512.5, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.49, 0.2, 0, 0, 0},},} 
randSampContainer = 0 

