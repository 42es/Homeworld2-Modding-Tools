--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 3 
loopStart = 0 
loopEnd = -1 
loopCount = 0 
envelope = {
	{distance = 0, volume = 0.505, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 316.666656, volume = 0.32, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 591.666687, volume = 0.295, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.3, 0.45, 0.26, 0.31},},
	{distance = 908.333313, volume = 0.145, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.62, 0.3, 0.19, 0.26, 0},},
	{distance = 1233.333374, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.49, 0.2, 0.12, 0, 0},},} 
randSampContainer = 0 

