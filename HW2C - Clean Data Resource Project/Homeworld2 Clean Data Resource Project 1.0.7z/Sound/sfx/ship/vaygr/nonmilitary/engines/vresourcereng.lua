--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 121344 
loopEnd = 211968 
envelope = {
	{distance = 0, volume = 0.725, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 26.041666, volume = 0.725, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.55, 0.65, 0.61, 0.45},},
	{distance = 76.041664, volume = 0.295, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.66, 0.55, 0.26, 0.17, 0.11},},
	{distance = 231.25, volume = 0.18, reverb = 0, duration = 0, equalizer = {1, 0.44, 0, 0, 0, 0, 0, 0},},
	{distance = 991.666687, volume = 0, reverb = 0, duration = 0, equalizer = {0, 0, 0, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

