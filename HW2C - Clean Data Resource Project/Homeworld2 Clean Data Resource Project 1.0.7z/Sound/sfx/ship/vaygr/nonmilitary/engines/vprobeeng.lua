--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 98816 
loopEnd = 147712 
envelope = {
	{distance = 0, volume = 0.77, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 22.916666, volume = 0.555, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.81, 0.76, 0.44, 0},},
	{distance = 65.625, volume = 0.395, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.42, 0.27, 0.07, 0},},
	{distance = 175, volume = 0.205, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.22, 0.2, 0.02, 0},},
	{distance = 586.458313, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.22, 0, 0, 0, 0},},} 
randSampContainer = 0 

