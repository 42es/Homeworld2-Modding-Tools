--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 118272 
loopEnd = 205312 
envelope = {
	{distance = 0, volume = 0.87, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 108.333336, volume = 0.835, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.49, 0.45, 0.32, 0.2, 0},},
	{distance = 316.666656, volume = 0.515, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.47, 0.42, 0.16, 0.04, 0},},
	{distance = 566.666687, volume = 0.24, reverb = 0, duration = 0, equalizer = {1, 1, 0.64, 0.28, 0.06, 0, 0, 0},},
	{distance = 941.666687, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 0.61, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

