--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 3 
envelope = {
	{distance = 0, volume = 0.61, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 408.333344, volume = 0.58, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 741.666687, volume = 0.415, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.52, 0.41, 0.46, 0.34},},
	{distance = 1433.333374, volume = 0.18, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.62, 0.2, 0, 0, 0},},
	{distance = 2191.666748, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

