--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 100096 
loopEnd = 143104 
envelope = {
	{distance = 0, volume = 0.61, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 416.666656, volume = 0.435, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 666.666687, volume = 0.22, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.52, 0.41, 0.46, 0.34},},
	{distance = 1125, volume = 0.105, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.62, 0.2, 0, 0, 0},},
	{distance = 1941.666626, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

