--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 3 
envelope = {
	{distance = 0, volume = 0.505, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 283.333344, volume = 0.45, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.81, 0.76, 0.44, 0},},
	{distance = 675, volume = 0.255, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.81, 0.76, 0.44, 0},},
	{distance = 1066.666626, volume = 0.13, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.62, 0.34, 0.02, 0},},
	{distance = 1416.666626, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.22, 0, 0, 0, 0},},} 
randSampContainer = 0 

