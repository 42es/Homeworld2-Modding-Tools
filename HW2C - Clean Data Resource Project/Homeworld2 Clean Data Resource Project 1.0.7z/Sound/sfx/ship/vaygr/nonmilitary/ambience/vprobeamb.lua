--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 9472 
loopEnd = 132096 
envelope = {
	{distance = 0, volume = 0.77, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 8.072917, volume = 0.58, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.81, 0.76, 0.44, 0},},
	{distance = 25.520834, volume = 0.16, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.81, 0.76, 0.44, 0},},
	{distance = 51.5625, volume = 0.12, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.22, 0.2, 0.02, 0},},
	{distance = 125, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.22, 0, 0, 0, 0},},} 
randSampContainer = 0 

