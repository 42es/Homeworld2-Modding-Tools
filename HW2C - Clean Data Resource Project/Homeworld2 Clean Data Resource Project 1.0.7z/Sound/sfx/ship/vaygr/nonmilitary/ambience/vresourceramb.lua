--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopEnd = 79104 
envelope = {
	{distance = 0, volume = 0.51, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 39.583332, volume = 0.295, reverb = 0, duration = 0, equalizer = {1, 1, 0.8, 0.42, 0.25, 0.09, 0, 0},},
	{distance = 97.916664, volume = 0.145, reverb = 0, duration = 0, equalizer = {1, 1, 0.42, 0.16, 0, 0, 0, 0},},
	{distance = 162.5, volume = 0.06, reverb = 0, duration = 0, equalizer = {1, 0.61, 0.26, 0.01, 0, 0, 0, 0},},
	{distance = 354.166656, volume = 0, reverb = 0, duration = 0, equalizer = {1, 0.29, 0, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

