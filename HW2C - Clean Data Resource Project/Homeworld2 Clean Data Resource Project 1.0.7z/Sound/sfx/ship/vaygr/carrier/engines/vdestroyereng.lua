--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
volume = 0.5 
loopStart = 144384 
loopEnd = 230912 
envelope = {
	{distance = 0, volume = 0.685, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 216.666672, volume = 0.65, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 0.97, 0.44, 0.34},},
	{distance = 475, volume = 0.285, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.55, 0.37, 0.31, 0.17},},
	{distance = 1141.666626, volume = 0.13, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0, 0, 0, 0, 0},},
	{distance = 2350, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

