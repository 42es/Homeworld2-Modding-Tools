--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 3328 
loopEnd = 163072 
envelope = {
	{distance = 0, volume = 0.845, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 183.333328, volume = 0.7, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 0.52, 0.61, 0.39},},
	{distance = 333.333344, volume = 0.305, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.77, 0.76, 0.52, 0.37, 0.36},},
	{distance = 725, volume = 0.2, reverb = 0, duration = 0, equalizer = {1, 1, 0.86, 0.74, 0, 0, 0, 0},},
	{distance = 1308.333374, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 0.7, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

