--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
loopStart = 1536 
loopEnd = 162816 
envelope = {
	{distance = 0, volume = 0.5, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 54.166668, volume = 0.49, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.76, 0.5, 0.47, 0.34},},
	{distance = 271.875, volume = 0.16, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.76, 0, 0, 0},},
	{distance = 486.458344, volume = 0.03, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.37, 0, 0, 0},},
	{distance = 800, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 0, 0, 0, 0, 0, 0},},} 
randSampContainer = 0 

