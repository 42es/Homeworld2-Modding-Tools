--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
envelope = {
	{distance = 0, volume = 0.475, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 233.333328, volume = 0.255, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 0.89, 0.8, 0.61},},
	{distance = 433.333344, volume = 0.115, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.7, 0.67, 0.69, 0.56},},
	{distance = 1016.666687, volume = 0.085, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.71, 0.56, 0.46, 0.29},},
	{distance = 1300, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.4, 0, 0, 0},},} 
randSampContainer = 1 

