--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
volume = 0.65 
maxPolyphony = 3 
envelope = {
	{distance = 0, volume = 0.385, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 716.666687, volume = 0.385, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.75, 0.59, 0.62, 0.62},},
	{distance = 1300, volume = 0.235, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.75, 0.59, 0.62, 0.62},},
	{distance = 2366.666748, volume = 0.13, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.6, 0.39, 0.4, 0.32},},
	{distance = 9016.666992, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0, 0, 0, 0, 0},},} 
randSampContainer = 1 

