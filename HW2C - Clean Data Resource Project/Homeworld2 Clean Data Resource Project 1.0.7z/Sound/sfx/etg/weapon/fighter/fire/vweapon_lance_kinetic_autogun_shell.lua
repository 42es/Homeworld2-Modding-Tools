--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
volume = 0.5 
envelope = {
	{distance = 0, volume = 0.285, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 683.333313, volume = 0.175, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 0.89, 0.8, 0.61},},
	{distance = 1308.333374, volume = 0.12, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.7, 0.67, 0.69, 0.56},},
	{distance = 1858.333374, volume = 0.08, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.71, 0.56, 0.46, 0.29},},
	{distance = 2383.333252, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.4, 0, 0, 0},},} 
randSampContainer = 0 

