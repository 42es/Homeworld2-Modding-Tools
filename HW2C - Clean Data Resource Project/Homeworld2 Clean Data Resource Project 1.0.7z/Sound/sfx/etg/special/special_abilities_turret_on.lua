--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
volume = 0.4 
maxPolyphony = 9 
envelope = {
	{distance = 0, volume = 0.76, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 40.625, volume = 0.56, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 0.89, 0.8, 0.61},},
	{distance = 81.770836, volume = 0.36, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 171.354172, volume = 0.275, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.96, 0.72, 0.52, 0.4, 0.62},},
	{distance = 220.3125, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.59, 0.31, 0, 0, 0},},} 
randSampContainer = 0 

