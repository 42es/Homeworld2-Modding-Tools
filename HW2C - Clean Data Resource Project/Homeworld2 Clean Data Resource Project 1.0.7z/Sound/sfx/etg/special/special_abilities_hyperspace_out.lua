--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
envelope = {
	{distance = 0, volume = 0.475, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 166.666672, volume = 0.47, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.75, 0.64, 0.45, 0.4},},
	{distance = 1566.666626, volume = 0.125, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.75, 0.64, 0.45, 0.4},},
	{distance = 9725, volume = 0.065, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.72, 0.55, 0.36, 0.28, 0.12},},
	{distance = 10000, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.74, 0.29, 0, 0, 0},},} 
randSampContainer = 0 

