--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
envelope = {
	{distance = 0, volume = 0.685, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 17.708334, volume = 0.67, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 0.89, 0.8, 0.61},},
	{distance = 48.958332, volume = 0.41, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.7, 0.67, 0.69, 0.56},},
	{distance = 70.833336, volume = 0.23, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.71, 0.56, 0.46, 0.29},},
	{distance = 83.854164, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.4, 0, 0, 0},},} 
container = 0 
playlist = 1 
randContainer = 1 
loopingPlaylist = 1 
silenceBreak = 2 
silenceRandom = 5 
randSampContainer = 1 

