--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
maxPolyphony = 3 
envelope = {
	{distance = 0, volume = 0.8, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 733.333313, volume = 0.405, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.86, 0.86, 0.85, 0.81, 0.87},},
	{distance = 3200, volume = 0.115, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.8, 0.61, 0.57, 0.64, 0},},
	{distance = 8333.333008, volume = 0.1, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.89, 0.64, 0.5, 0.06, 0},},
	{distance = 8766.666992, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0, 0, 0, 0, 0},},} 
randSampContainer = 1 

