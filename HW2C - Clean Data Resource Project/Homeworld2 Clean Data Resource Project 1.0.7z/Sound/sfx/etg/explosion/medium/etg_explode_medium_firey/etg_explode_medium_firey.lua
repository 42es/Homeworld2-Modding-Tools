--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
maxPolyphony = 3 
envelope = {
	{distance = 0, volume = 0.595, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 466.666656, volume = 0.36, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 2800, volume = 0.085, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 0.86, 0.76, 0.76},},
	{distance = 7033.333496, volume = 0.07, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.85, 0.64, 0.61, 0.31, 0.4},},
	{distance = 8466.666992, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 0.67, 0, 0, 0, 0, 0},},} 
randSampContainer = 1 

