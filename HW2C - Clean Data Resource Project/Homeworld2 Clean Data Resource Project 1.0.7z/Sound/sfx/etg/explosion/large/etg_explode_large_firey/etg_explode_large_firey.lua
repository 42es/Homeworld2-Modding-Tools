--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
volume = 0.85 
volumeRand = 1 
envelope = {
	{distance = 0, volume = 0.8, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 491.666656, volume = 0.48, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0.39, 0.49, 0.41, 0.26, 0.26},},
	{distance = 2900, volume = 0.095, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0, 0, 0, 0, 0},},
	{distance = 7933.333496, volume = 0.09, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0, 0, 0, 0, 0},},
	{distance = 8300, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 0, 0, 0, 0, 0},},} 
randSampContainer = 1 

