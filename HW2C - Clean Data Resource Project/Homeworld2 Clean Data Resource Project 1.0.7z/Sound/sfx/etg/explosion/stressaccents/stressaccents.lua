--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
envelope = {
	{distance = 0, volume = 0.845, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 691.666687, volume = 0.81, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 1933.333374, volume = 0.615, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.7, 0.67, 0.69, 0.56},},
	{distance = 2791.666748, volume = 0.3, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.71, 0.56, 0.46, 0.29},},
	{distance = 3983.333252, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 0.4, 0, 0, 0},},} 
randSampContainer = 1 

