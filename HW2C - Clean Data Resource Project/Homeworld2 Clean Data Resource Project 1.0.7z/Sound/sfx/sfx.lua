--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4 
compression = 2 
destination = 2 
patch = 2 
envelope = {
	{distance = 0, volume = 0.475, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 866.666626, volume = 0.475, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 2083.333252, volume = 0.475, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 3900, volume = 0.48, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},
	{distance = 6800, volume = 0, reverb = 0, duration = 0, equalizer = {1, 1, 1, 1, 1, 1, 1, 1},},} 
randSampContainer = 0 

