--  ============================================================================= 
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
--  =============================================================================

version = 4
compression = 3
volume = 1
effects = {filterMinFreq = 400,
filterMaxFreq = 2800,
toneMinFreq = -1,
toneMaxFreq = -1,
toneDuration = 0,
toneMute = 0,
toneCount = 0,
breakMaxRate = 0,
breakMaxDur = 0,
noiseMaxRate = 0,
noiseMaxDur = 0,
scaleLevel = 1,
noiseLevel = 1,
toneLevel = 0,
limiterLevel = 0.6,
pitchShift = 1,
distance = 0,
volume = 1,
reverb = 0.05,
duration = 500,
equalizer = {1, 1, 1, 1, 1, 1, 1, 1},}
randSampContainer = 0

