The .hod files are owned by Sierra / Relic Entertainment and cannot
be distributed in this repository.

See the toplevel README.md for instructions on how to extract
the .hod files from the Homeworld 2 game.

