/* DXGM patcher V1.0
   afto to programa ftiaxtike giati ithela na pexo ta video tou armed and dangerous me enan media player
   ta arxia apo oti anakaliya sto diadiktio ine apla divx arxia ke to mono pou xriazotan gia na pexoun ine
   na alaxoun dio egrafes mesa sto header apo DXGM se DX50 aftes i dio egrafes briskode sta offser1 ke offset2
   bori na ot di kapios afto me enan hex editor
   alexandros_elf@hotmail.com*/
#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include <string.h>

const int offset1=0x00000072;
const int offset2=0x000000be;

const char str[3]={'5','0','\0'};
const char strb[3]={'G','M','\0'};

int main(int argc,char *argv[])
{ 
	char string[3];
	string[2]='\0';
	cout<<"DXGMpatcher V1.0 alexandros_elf@hotmail.com"<<endl;
	if(argc!=2)
	{
		cout<<"Error number of arguments"<<endl;
		exit(1);
	}
	fstream file;
	file.open(argv[1],ios::in|ios::out|ios::nocreate|ios::noreplace);
	if(!file)
	{
		cout<<argv[1]<<" File could not be opend"<<endl;
		exit(1);
	}
	//diabazi an ine ena dxgm format arxio
	file.seekg(offset1,ios::beg);
	file.read(string,2);
	if(strcmp(string,strb))
	{
		cout<<"Patch failed file hase not a DXGM format";
		exit(0);
	}
	file.seekg(offset2,ios::beg);
	file.read(string,2);
	if(strcmp(string,strb))
	{
		cout<<"Patch failed file hase not a DXGM format";
		exit(0);
	}
	//alagi tou gm se 50
	file.seekg(offset1,ios::beg);
	file.write(str,2);
	file.seekg(offset2,ios::beg);
	file.write(str,2);
	cout<<"File patched successfully!!!!!!"<<endl;
	return 0;
}
