MissionBoy Special Edition

Thanks to IWAssasin for releasing the source code to the original MissionBoy
map maker.  Also thanks to Rob (Starfleet), Sps, Skeeter and the Relic forums
for the ideas.

Version 1.9
-----------
1. Fixed bug with deleting all objects on the map, and then re-adding causing program
   to crash with "Cannot load object" error
2. Fixed dropdown box resetting to "Pebbles" when saving a map
3. Added X Y Z boxes for finetuning of object positions
4. Added labels for front map view (same attributes as normal labels)
5. Released Source Code

Version 1.8
-----------
1. Added ability to specify RaceID for players
2. Added ability to specify starting resources for players
3. Added ability to change player name
4. Added SOBGroups window
5. Added detection of SP maps (if startPos = 0)
6. Added MapType dropdown in Globals
7. If SP don't check for all player start positions, since not all have them
8. Set all startPos to 0 when saving, or 1 if MP
9. Write addPoints as PlayerStartPosition, or StartPosx if MP
10. Fixed map not saving bug
11. Fixed bug with player assignments for ships not saving
12. Fixed bug with player assignments for ships not being reloaded after save
13. Fixed tab order on global options screen
14. Fixed bug with cloud attributes not updating when selecting from objects list
15. Clicking on labels now correctly shows you the objects attributes
16. Added setDustCloudAmbient to NonDetermChunk section
17. Fixed "Key is not unique" bug when loading large maps that appeared occasionally
18. Added drag selection box for top map view to select multiple objects from the map
    easily
19. Removed superflous message box when setting player id
20. Fixed zooming so that it zooms to the correct area on the map
21. Added ability to delete objects either selected in the map or on the list using
    the delete key on the keyboard
22. Added ability to place and edit Single Player Points (addPoint).  Please note that
    the first x number of addPoints in a map are assumed to be the player start
    positions
23. Added ability to place and edit Single Player Spheres (addSphere)
24. Added author field to Globals form
25. Changed around some fields on globals form
26. Added 2 new "Labels" menu options (Point and Sphere) to accomodate new objects
27. Added ability to assign ships to a particular group from the SOBGroups window
28. Updated label code so that group of ship, if any, is added below the ship name on the
    map view
29. Added warning about new mouse buttons for placing and selecting objects
30. Note: when adding ships, you can assign a default SOBGroup for new ships from the 
    File -> Set Groups screen
31. Labels now change colour to white showing which objects are currently selected

Version 1.7
-----------
1. Fixed bug where deleting items causes a crash
2. Fixed bug where selecting multiple objects to delete would only delete the last one
3. Fixed bug where deleting multiple objects didn't delete them all
4. Changed deleting objects routine to add a lot more checks
5. Fixed bug where hiding labels after deleting objects causes crash

Version 1.6
-----------
1. Removed ability to apply position/orientation settings when placing Player
   Start positions - now has to be done when editing.
2. Added back cross to denote center of map
3. Fixed zooming in inadvertently when in editing mode
4. Added Hide All labels option, allowing you to hide everything in one go
5. Increased size of the object type dropdown box
6. Added ability to specify custom asteroids, dust clouds, salvage and nebulae
7. Program now automatically picks up the HW2 directory and, if you've gotten all
   the data files extracted, also picks up all content from the relevant directories
8. Added ability to select multiple items from the objects list and delete them
9. Added ability to set multiple items from the objects list to a specific player
10. Added ability to edit specific objects just by clicking on thier label in the top map view
11. Zoom now ignores clicking on labels, so you can click anywhere and it'll zoom regardless
12. Speeding up loading times a bit by removing some debug code
13. Massively speeded up all map redrawing operations by removing redundant calls to the label
    redraw function
14. Fixed bug with delete item crashing the program
15. Renamed "Map Left View" to "Map Front View" since thats what it really is
16. Fixed vertical axis in Front View being upside down
17. Fixed bug with loaded levels having an extra space after the name
18. Fixed bug with saving level even though cancel was selected on save screen
19. Added ability to set font size for labels
20. Added saving of font size and grid size to registry
21. Added link to Mission Boy SE Website in Help menu
22. Fixed bug with salvage chunks crashing the game

Version 1.5
-----------
1. Added ability for any object to be placed at random height
2. Added new section in Globals: Grid Size.  Allows grid to be changed for larger
   maps
3. Added ability to specify custom music
4. Added ability to specify custom backgrounds
5. Fixed bug where "Select Type" would constantly popup

Version 1.4
-----------
1. Added zoom feature
2. Allowed zooming in any part of the process not just placement mode
3. Fixed resizing problem

Version 1.3
-----------
1. Fixed map scaling bug (size extents are now correct)
2. Fixed crash when trying to add more than one startpos for the same player
3. Decreased size of font in labels on the map view
4. Pebbles are now added to the NonDetermChunk section
5. Removed Pebble_3 type

Version 1.2
-----------
1. Fixed program not exiting bug
2. Fixed bug when removing last object from map
3. Added back in ability to place custom ships
4. Added ability to show only labels for specific objects (ie turn off
   pebbles but show everything else)
5. Turned off showing of pebble labels by default
6. Fixed green colour not saving properly
7. Added loading of maps
8. Removed "Type" and "ArrayID" columns as these where for debugging only
9. Resized Objects list
10. Added random height variance for asteroids and pebbles
11. Added New Map option
12. Added ability to click and drag when placing objects across the map, 
    meaning a trail can easily be drawn

Version 1.1
-----------
1. First release
2. Added grid
3. Added left hand map view
4. Added list of objects
5. Added ability to edit current objects
6. Fixed bug with saving when no filename specified
7. Added dropdown for players
8. Added dropdown for background
9. Added dropdown for music
10. Removed "Custom Ship" option
11. Added labels for objects on map
12. Added ability to move objects after placement
