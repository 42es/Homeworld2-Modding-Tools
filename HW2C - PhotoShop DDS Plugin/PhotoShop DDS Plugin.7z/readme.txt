Copy and paste the 8bi file into your photoshop plugins folder.
Try out photoshop opening a .dds file.

If it works thats ok
If it goes to error saying that needs a msvcr.dll file, use this one here.