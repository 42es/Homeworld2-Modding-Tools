Paint.NET Homeworld 2 ROT files Importer.

installation

put PNROTFile.dll to folder with Paint.NET [FileTypes] folder.
example "C:\Program Files\Paint.NET\FileTypes\PNROTFile.dll"  