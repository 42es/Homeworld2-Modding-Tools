------------------------------
Lathe of Sajuuk 1.0.9 Readme
------------------------------

INTRODUCTION

Lathe of Sajuuk (LoS) is a level generator for Homeworld 2.  Using LoS you can create levels with large dynamic asteroid and cloud formations.  Note that (LoS) is a level generator, not a level editor.  You probably won�t be able to everything you need to do to make your map in this tool. But LoS can be really useful in making those difficult to construct large-scale map features.  


SOFTWARE / HARDWARE REQUIREMENTS

LoS requires a Java VM  (prefereably 1.4.2) to run.  For your convenience, the VM we tested with is available from Sun at (http://java.sun.com/j2se/1.4.2/index.html).  
(For automatic launching of Homeworld 2, Windows XP,ME,2000 required).


KNOWN ISSUES

"Test Settings" menu item sometimes causes LoS to unexpectedly quit while attempting to launch Homeworld2.  Tends to happen if you've launched HW2 many times.  Avoid this feature if it worries you.


HISTORY

Version 1.0.9 - Initial Release.


DISCLAIMER 

A user of this Lathe Of Sajuuk software acknowledges that he or she is receiving this software on an "as is" basis and the user is not relying on the accuracy or functionality of the software for any purpose.  The user further acknowledges that any use of this software will be at the user's own risk and the authors accept no responsibility whatsoever arising from the use or application of the software.
