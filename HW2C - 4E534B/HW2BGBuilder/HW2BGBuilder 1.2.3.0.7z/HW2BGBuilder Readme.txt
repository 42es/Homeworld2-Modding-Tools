Homeworld2 Background Builder Readme.
-By 4E534B

Version 1.2.3
[Last update date: 2007 Nov 14]

Description:
Builds a Homeworld2 Background HOD file from a Truevision Targa (TGA) image.

Usage: HW2BGBuilder [/O] [/D:value] [/G:value] [/MD:value] [/EM:name] [/P:value] [/S] name
/O Overrides the default settings by asking user input
/D Sets the detail level. Ignored in presence of '/O'
/G Sets the grid size. Ignored in presence of '/O'
/MD Sets the mesh density. Ignored in presence of '/0'
/EM Sets the edge map from given TGA file
/P Sets the glue pixel count. Ignored in presence of '/O'
/S Enables stripification. This should improve rendering.
name Name of the TGA, to be used for the input. The name MUST
be quoted if it contains spaces.

Note that the switches are case-sensitive.

Options:
Detail Level: This specifies the contrast level, which would be used
for deciding where vertices\faces are to be created.
The lower this value, the more accurate mesh you will get.
However, you will get more faces (a face count of
100,000 should be kept as the maximum limit, though 75,000
should be permissible. Recommended value: 64. Range: 1 to 255
Type: Decimal value (Floating point number).

Grid Size: This option specifies the size of grid, where vertices will
be put, regardless of whether there is contrast in details,
or not. Usually this is needed so that the non-contrasting parts
(usually the 'background' of the image) are properly created.
This is also needed for consistency of the sphere mesh which is
outputted. Higher this value (to some extent), lesser the face count.
However it would take more time for the mesh to be built.
Major factor for determining number of parts into which mesh is partitioned.
Recommended value: 256. Range: Minimum 1. Type: Number (non-zero
and non-negative)

Mesh Density: Similar to grid size, but doesn't affect the total number of parts in the mesh.
This needs to be a submultiple of grid size or the mesh will appear broken.
Recommended Value: 128 (usually half of mesh density). Range: Minimum 1.
Type: Number (non-zero and non-negative)

Merge Distance: Specifies the distance with which nearby similar vertices are merged. This is to
prevent overcrowding of vertices, especially where it isn't needed. Recommended Value:
16. Range: 1 to Grid Size. Type: Decimal value (Floating point number).

Merge Colour Diff.: Specifies the colour difference for which vertices can be merged. A small value
will prevent visual artefacts. Recommended Value: 10. Range: 1 to 255. Type: Number
(non-zero and non-negative).

Edge Map: Specifies the external edge map which is to be used. Type: String.

Number of Glue
pixels: This value specifies the number of extra pixels, that are created
around EACH pixel. This is used, to prevent the edges from being
blended with other object(s) (which is usually the 'background')
Higher this value more denser the mesh is. Usually a value of 1 suffices.
If you still find the resultant HOD having problems related to edges, try
increasing this value to 2, or atmost 3. WARNING: This causes a steep
increase in face count. Increase in this value causes slowdowns in inital
processing. Recommended value: 1.

Stripify: This option 'stripifies' triangles; ie arranges them in strips. Although
this could slowen the export (considerably when overall face count for all
meshes parented under a single joint is more than !10,000), this does
improve rendering speed, and hence this should be enabled when you are
satisfied with the results. The strategy is -- first build the background
without stripifying, then when you get the optimum settings, re-make the
background with stripping enabled. This would give an optimized background
HOD.

Inputs:
- A TGA image, with dimensions of 512x256 or 1024x512. Larger images both cause
slowdowns and increase in face count.

Outputs:
- A TGA image, which shows the places where vertices were created. It is the
reference image which the application used to differentiate between 'edges'
in the original image (this is the Edge map, "_EdgeMap").

- A TGA image, summarizing all the points created in the mesh with colour (alpha for
points is 255). It is the reference image ("_RefPts").

- A wavefront object (OBJ) file, containing all the data in a consolidated manner.

- A HOD file, containing the data in an optimized manner (the vertices and faces are
partitioned into 32 parts; with almost no duplicate vertices; and triangles are
stripped on user request).

Since the face data are partitioned into 32 parts, those parts which are not visible, are not
rendered, effectively reducing the actual number of faces being rendered. With ~96,000 faces,
the number of faces being actually rendered drops to around 24,000, which isn't that high.
But it is around 140% more as compared to Relic backgrounds.

Notes:
For a
i) 512x256 image, grid size of 64 is recommened (32 is minimum; for a resonable mesh).
ii) 1024x512 image, grid size of 128 is recommened (64 is minimum; for a resonable mesh).
iii) 2048x1024 image, grid size of 256 is recommened (128 is minimum; for a resonable mesh).
iv) 4096x1024 image, grid size of 512 is recommended (256 is mimimum; for a resonable mesh).

Any smaller or larger image size may cause problems.

SPECIAL THANKS TO:
~~~~~~~~~~~~~~~~~~
Paul Bourke for the delaunay triangulation code which this program uses;
Gilles Dumoulin for C++ version of the code; and
evillejedi for suggesting many effective improvements in the main algorithim.

Without the work\help of these people, the newer versions (from 1.1) would have never been released.