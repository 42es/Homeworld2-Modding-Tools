
==================================================================================================================
HOMEWORLD� REMASTERED TOOLKIT -- README
==================================================================================================================

April 20, 2015:
- Fixed a bug with not reporting config.txt file problems properly.

March 31, 2015:
- Added support for 'cursors' mods.
- Added support for 'badges' mods.

March 26, 2015:
- Added support for 'locale only' mods that add a new -locale language to translate Training, Campaign and Multiplayer
  text into addtional languages (see below for some details).

March 24, 2015:
- Fixed a bug where the preview image file was locked after being uploaded.
- Fixed an issue with excluding the 'locale\localedat.lua' file (if it exists) from the .big file.
- Added support for mods that have a 'locale' folder containing language folders with localized text.


February 25, 2015:

- Initial release


==================================================================================================================

Localization:

For mods that support localization (have their own 'locale' folder with folders containing text for each language),
your mod folder structure should look something like this:

    MyMod
        Locale
            English
            French
            German
            Italian
            Russian
            Spanish
            <other custom languages here>

Each of the folders within the 'Locale' folder are optional.  In the 'Locale' folder, you should include a 'localedat.lua'
file with the Dictionaries entries for any custom localization index ranges that you've added for your mod (or you can
copy the engine's Data:locale/localedat.lua file if you haven't added any custom ranges but want to support additional
languages not already supported by the game).

Within each language folder inside the 'Locale' folder, you should include .dat or .usc files that have the translated
text strings specific to your mod.  In each language folder, you should also include a 'fontmap.lua' file with the .rcf
font file to be used for that specific language.

For mods that are 'locale only' (i.e. don't contain anything other than text translated to support a new language), the
folder structure should be the same as above, but your should only have ONE language folder.  For example, if I was to
create a mod for Homeworld Remastered that translated the text to piglatin, it would look like this:

    MyPigLatinMod
        Locale
            Piglatin
                LevelData
                    Campaign
                        Tutorial
                            <.dat files here>
                    Multiplayer
                        Lib
                            <.dat files here>
                Scripts
                    keybindings.lua
                ATI.dat
                buildresearch.dat
                engine.dat
                events.dat
                fontmap.lua
                HW1buildresearch.dat
                HW1ships.dat
                levelDesc.dat
                resource.dat
                ships.dat
                ui.dat
        config.txt
        preview.jpg

If you are also translating HW1 Campaign or HW2 Campaign text in a new language, you would also need to include the .dat
files from the HW1 campaign or HW2 campaign .big files.

When you use the WorkshopTool to create your mod (for either the 'mod with locale folders' or 'locale only mod'), the tool
will create separate .big files for each language and upload those to Steam Workshop along with the mod.  For mods that
are 'locale only' mods, the launcher for the game will run the game with "-locale <language>" automatically to specify
that new language included in the mod should be used when running the game.  For mods that contain any of the default
languages, the Steam language selection would be used to load the proper language .big file for that mod.  Mods that add
a new language that aren't included in the game, would have to instruct the user to use "-locale <language>" (without
the quotes) in the 'Commandline Arguments' field of the MOD screen before launching that mod with the new language.
            

Cursors mods:
To create a cursors mod, in your mod folder, create a UI folder.  In the UI folder, create a Cursors folder and copy
any of the game's UI\Cursors files into your mod's Cursors folder and modify as desired.  Then in the config.txt file
set the ModType to 'Cursors' (without the quotes) and create your mod.  The launcher will recongnise this and will load
the mod as a "client side only" mod which means that you can use these cursors in multiplayer if you wish.


Badges mods:
You can now create Workshop mods that only contain badges files (*.tga) and upload them to Workshop.  When someone selects
your mod in the launcher and launches the game with it, the badges in that .big file will be available in game (no need
to extract these out as loose files and no need to copy the .big file anywhere else).  These mods are also treated as
"client side only" which means you can use them in multiplayer whether other players have them loaded or not.

