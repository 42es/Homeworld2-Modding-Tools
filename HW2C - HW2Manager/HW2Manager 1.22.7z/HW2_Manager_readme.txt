=== HW2 Manager v1.2.2
=== Created: 02/20/05 by Mikail
=== Last updated: 04/07/08
=== Homepage: http://www.geocities.com/Area51/Quadrant/3864/homeworld.htm
=== Discussion: http://forums.relicnews.com/showthread.php?t=57235
=== Download: http://www.geocities.com/Area51/Quadrant/3864/homeworld.htm


================================================================


INTRODUCTION
HW2 Manager is a front-end program for Homeworld 2. It allows 
you to setup and configure Homeworld 2's command-line options 
before running the game. You can save your configurations to 
disk, and even save shortcuts to the Desktop.

INSTALLATION
Extract the contents of this archive into a folder on your 
harddrive. To run HW2 Manager, execute the file named 
"HW2_Manager.hta". This program requires that Windows Scripting 
Host v5.6 or greater be installed.

INSTRUCTIONS
� To create a new config file, click the "New" button and enter 
  a name for your new config file when asked to.
� To load a saved config file, select the file you want to load 
  in the "Saved .CFG files" field. Then, click the "Load" 
  button.
� Click the "Test" button to test the validity of your 
  settings.
� Click the "Create Shortcut" button to create a shortcut on 
  your Desktop with your new settings. 
� Click the "Run Homeworld 2" button to run HW2 with the 
  current settings.

If you have set up the %HW2_ROOT% environmental variable as 
instructed by the RDN docs, you can use it within the "HW2 
Directory" dialogue.


================================================================


RELEASE NOTES
CHANGES IN 1.2.2
� Switched to WSH-style prompts wherever possible.

CHANGES IN 1.2.1
� Now fully compatible with the Windows XP theme.

CHANGES IN 1.2.0
� Too many changes to list. Almost completely redone.
� Have attempted a workaround so that it will work in Windows 
  98 again, but I no longer have a computer with this operating 
  system to test it on. Need feedback.

CHANGES IN 1.1.2
� Probably some changes I can't remember.
� The contents of the application window now grow and shrink 
  along with the window as it changes size.
� Fixed a problem causing the "Run Homeworld 2" button not to 
  work in Windows XP. As a result, the button may no longer 
  work in Windows 98. Sorry!

CHANGES IN 1.1.1
� Fixed the capitalization of some flags for case-sensitive 
  systems.

CHANGES IN 1.1.0
� Changed the sizes and positions of some of the panes.

CHANGES IN 1.0.9
� Variable keynames have been shortened to two characters plus 
  a number. This means that config files made using older 
  versions of the program are no longer compatible.
� A slight speed optimization when retrieving data from 
  ConfigTable.
� Switches are now printed to the screen dynamically, instead 
  of being stored in the file (decreases filesize).

CHANGES IN 1.0.8
� The program now works properly if it is not installed on the 
  same drive as Homeworld 2.

CHANGES IN 1.0.7
� Updated the program to include SnakeChiken's newly-found 
  command-line switches.
� Fixed a bug.

CHANGES IN 1.0.6
� Fixed the bug where the program would crash if the last-
  loaded Config File no longer existed.
� Fixed the bug where the program didn't check/save the proper 
  extension for Config Files.
� Removed the "<new>" option from the Config File list.
� Added the "New" button to the main window.

CHANGES IN 1.0.5
� Fixed the bug where Config Files with spaces in their 
  filenames would cause errors.

CHANGES IN 1.0.4
� The name of the Config File being overwritten is now 
  displayed in the confirmation message.

CHANGES IN 1.0.3
� The most recently used Config File is now automatically 
  loaded when the application starts.

CHANGES IN 1.0.2
� Settings are no longer cleared when saving new config files.
� The correct file extension is automatically added to new 
  config files if it is not already present.
� The %HW2_ROOT% environmental variable is now properly taken 
  into account before displaying the Game-Type and Mod .big 
  file directories.
  Note, that you will not be able to create shortcuts if you 
  are using the %HW2_ROOT% environmental variable.
� Instances of the batch file used to run HW2 now close 
  automatically.
� Now asks for confirmation when saving over old Config Files.

CHANGES IN 1.0.1
� Minor fixes.

CHANGES IN 1.0.0
� Initial release.
