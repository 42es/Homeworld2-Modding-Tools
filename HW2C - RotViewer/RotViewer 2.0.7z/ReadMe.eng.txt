RotViewer 2.0b 

Requirements 

1. NetFramework 4, ManagedSquish.dll, Squish.dll.
2. Windows - on idea any (on Xp and Vista precisely works)
3. About hardware I will not tell since, the drawing is used GDI. DirectX did not use(Like ROTTool).

Installation

 1. If not installed NetFramework 4 - that install.
 2. Unpack in any folder

That the program can

1. Reads ROT  files from a command line (x:\RotViewer.exe [x:\xxxxx\somename.rot]) only ROT.    
2. Support Drag and Drop files operation.(to pull a file *.rot, *.tga, *.dds on the program and it opens it.)
3. Probably to make RotViever a browser for ROT files on [DubleClick]
    find a ROT  file, to cause its properties 
         The general    
         Application to Change - - to specify a way to RotViewer.exe 

4. Reads Rot files written down both in TGA and in DXT1, DXT3, DXT5 formats.
5. Reads TGA (24 and 32 bits Raw, RLE) and DDS-only in DXT1, DXT3, DXT5 formats.
6. Converts TGA and DDS in ROT files. TGA with MipMaps if  Generated, DDS with MipMaps (if Contains or Generated)
7. Converts ROT in DDS and TGA files.
8. Review MipMaps.
9. Generate MipMaps.
10. Review with the Alpha channel and without.
11.Image copying in a clipboard.

Bonus 
PNRotFile.dll - ROT File read Plugin for PAINT.NET . 
 

  

  
    